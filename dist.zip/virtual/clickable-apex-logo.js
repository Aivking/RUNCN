import { applyCssRule } from "./refined-prun-css.js";
import { C } from "./prun-css.js";
import { subscribe } from "./subscribe-async-generator.js";
import { $$ } from "./select-dom.js";
import features from "./feature-registry.js";
import $style from "./clickable-apex-logo.module.css.js";
import { companyStore } from "./company.js";
import { showBuffer } from "./buffers.js";
function init() {
  applyCssRule(`.${C.Frame.logo}`, $style.logo);
  subscribe($$(document, C.Frame.logo), (logo) => {
    logo.addEventListener("click", (e) => {
      void showBuffer(`CO ${companyStore.value?.code}`);
      e.preventDefault();
      e.stopPropagation();
    });
  });
}
features.add(import.meta.url, init, "使 APEX 徽标可点击并跳转到用户公司信息页面。");
