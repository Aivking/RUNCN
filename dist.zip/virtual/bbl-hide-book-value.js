import { applyCssRule } from "./refined-prun-css.js";
import { C } from "./prun-css.js";
import features from "./feature-registry.js";
import css from "./css-utils.module.css.js";
function init() {
  applyCssRule(
    "BBL",
    `.${C.SectionList.section} .${C.SectionList.table} tr:nth-child(5)`,
    css.hidden
  );
}
features.add(import.meta.url, init, 'BBL：隐藏"账面价值"行。');
