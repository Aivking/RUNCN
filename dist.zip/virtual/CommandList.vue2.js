import { C } from "./prun-css.js";
import _sfc_main$2 from "./ActionBar.vue.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import { createId } from "./create-id.js";
import PrunLink from "./PrunLink.vue.js";
import _sfc_main$3 from "./TextInput.vue.js";
import { vDraggable as so } from "./vue-draggable-plus.js";
import { grip } from "./index17.js";
import GripCell from "./GripCell.vue.js";
import GripHeaderCell from "./GripHeaderCell.vue.js";
import { defineComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList, createVNode, withCtx, createTextVNode, withDirectives } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CommandList",
  props: {
    list: {}
  },
  setup(__props) {
    const edit = ref(false);
    function addCommand() {
      __props.list.commands.push({
        id: createId(),
        label: "帮助",
        command: "XIT HELP"
      });
    }
    function deleteCommand(command) {
      __props.list.commands = __props.list.commands.filter((x) => x !== command);
    }
    return (_ctx, _cache) => {
      return !unref(edit) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
        createBaseVNode("table", null, [
          _cache[3] || (_cache[3] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "命令")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            _ctx.list.commands.length === 0 ? (openBlock(), createElementBlock("tr", _hoisted_1, [..._cache[2] || (_cache[2] = [
              createBaseVNode("td", null, "没有命令。", -1)
            ])])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(_ctx.list.commands, (command) => {
              return openBlock(), createElementBlock("tr", {
                key: command.id
              }, [
                createBaseVNode("td", null, [
                  createVNode(PrunLink, {
                    command: command.command
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(command.label), 1)
                    ]),
                    _: 2
                  }, 1032, ["command"])
                ])
              ]);
            }), 128))
          ])
        ]),
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: _cache[0] || (_cache[0] = ($event) => edit.value = true)
            }, {
              default: withCtx(() => [..._cache[4] || (_cache[4] = [
                createTextVNode("编辑", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[5] || (_cache[5] = createBaseVNode("th", null, "标签", -1)),
              _cache[6] || (_cache[6] = createBaseVNode("th", null, "命令", -1)),
              _cache[7] || (_cache[7] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          _ctx.list.commands.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_2, [..._cache[8] || (_cache[8] = [
            createBaseVNode("tr", null, [
              createBaseVNode("td", null, "没有命令。")
            ], -1)
          ])])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_3, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.list.commands, (command) => {
              return openBlock(), createElementBlock("tr", {
                key: command.id
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).forms.input, _ctx.$style.inline])
                  }, [
                    createVNode(_sfc_main$3, {
                      modelValue: command.label,
                      "onUpdate:modelValue": ($event) => command.label = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ]),
                createBaseVNode("td", null, [
                  createBaseVNode("div", {
                    class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).forms.input)
                  }, [
                    createVNode(_sfc_main$3, {
                      modelValue: command.command,
                      "onUpdate:modelValue": ($event) => command.command = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    danger: "",
                    onClick: ($event) => deleteCommand(command)
                  }, {
                    default: withCtx(() => [..._cache[9] || (_cache[9] = [
                      createTextVNode("删除", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [_ctx.list.commands, unref(grip).draggable]]
          ])
        ]),
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: addCommand
            }, {
              default: withCtx(() => [..._cache[10] || (_cache[10] = [
                createTextVNode("添加命令", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: _cache[1] || (_cache[1] = ($event) => edit.value = false)
            }, {
              default: withCtx(() => [..._cache[11] || (_cache[11] = [
                createTextVNode("完成", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ], 64));
    };
  }
});
export {
  _sfc_main as default
};
