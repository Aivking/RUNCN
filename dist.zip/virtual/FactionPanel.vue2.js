import _sfc_main from "./FactionPanel.vue.js";
export {
  _sfc_main as default
};
