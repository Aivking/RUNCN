import _sfc_main from "./GenerateHQUCActDialog.vue.js";
export {
  _sfc_main as default
};
