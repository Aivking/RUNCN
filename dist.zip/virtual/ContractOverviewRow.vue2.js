import { useCssModule } from "./runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./ContractLink.vue.js";
import PartnerLink from "./PartnerLink.vue.js";
import MaterialIcon from "./MaterialIcon.vue.js";
import ShipmentIcon from "./ShipmentIcon.vue.js";
import { isSelfCondition } from "./utils4.js";
import { objectId } from "./object-id.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, Fragment, renderList, createBlock, createCommentVNode } from "./runtime-core.esm-bundler.js";
import { normalizeClass, toDisplayString, normalizeStyle } from "./shared.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ContractOverviewRow",
  props: {
    contract: {}
  },
  setup(__props) {
    const $style = useCssModule();
    const icons = computed(() => {
      const result = [];
      for (const condition of __props.contract.conditions) {
        switch (condition.type) {
          case "DELIVERY_SHIPMENT": {
            if (isSelfCondition(__props.contract, condition)) {
              result.push({ type: "SHIPMENT", shipmentId: condition.shipmentItemId, fulfilled: condition.status === "FULFILLED" });
              continue;
            }
            break;
          }
          case "PROVISION":
          case "PICKUP_SHIPMENT": {
            continue;
          }
        }
        const quantity = condition.quantity;
        if (!quantity?.material) {
          continue;
        }
        result.push({ type: "MATERIAL", ticker: quantity.material.ticker, amount: quantity.amount, fulfilled: condition.status === "FULFILLED" });
      }
      return result;
    });
    const receivable = computed(() => {
      let total = 0;
      let currency = "";
      for (const cond of __props.contract.conditions) {
        if (cond.type === "PAYMENT" && cond.amount && cond.status !== "FULFILLED") {
          if (cond.party !== __props.contract.party) {
            total += cond.amount.amount;
            if (!currency) currency = cond.amount.currency;
          }
        }
      }
      return { total, currency };
    });
    const payable = computed(() => {
      let total = 0;
      let currency = "";
      for (const cond of __props.contract.conditions) {
        if (cond.type === "PAYMENT" && cond.amount && cond.status !== "FULFILLED") {
          if (cond.party === __props.contract.party) {
            total += cond.amount.amount;
            if (!currency) currency = cond.amount.currency;
          }
        }
      }
      return { total, currency };
    });
    function formatAmount(amount, currency) {
      if (!currency || amount === 0) return "-";
      return `${amount.toLocaleString()} ${currency}`;
    }
    const fulfilledCount = computed(
      () => __props.contract.conditions.filter((c) => c.status === "FULFILLED").length
    );
    const totalCount = computed(() => __props.contract.conditions.length);
    const progress = computed(() => {
      if (totalCount.value === 0) return 0;
      return Math.round(fulfilledCount.value / totalCount.value * 100);
    });
    const statusText = computed(() => {
      switch (__props.contract.status) {
        case "OPEN":
          return "待接受";
        case "CLOSED":
          return "进行中";
        case "FULFILLED":
          return "已完成";
        case "PARTIALLY_FULFILLED":
          return "部分完成";
        case "BREACHED":
          return "已违约";
        case "TERMINATED":
          return "已终止";
        case "CANCELLED":
          return "已取消";
        case "REJECTED":
          return "已拒绝";
        case "DEADLINE_EXCEEDED":
          return "已逾期";
        default:
          return __props.contract.status;
      }
    });
    const statusClass = computed(() => {
      switch (__props.contract.status) {
        case "FULFILLED":
          return $style.fulfilled;
        case "CLOSED":
        case "PARTIALLY_FULFILLED":
          return $style.active;
        case "BREACHED":
        case "TERMINATED":
        case "DEADLINE_EXCEEDED":
          return $style.failed;
        case "OPEN":
          return $style.pending;
        default:
          return "";
      }
    });
    const progressClass = computed(() => {
      if (progress.value >= 100) return $style.fulfilled;
      if (progress.value > 50) return $style.active;
      return $style.pending;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("tr", null, [
        createBaseVNode("td", null, [
          createVNode(_sfc_main$1, { contract: _ctx.contract }, null, 8, ["contract"])
        ]),
        createBaseVNode("td", null, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).iconGrid)
          }, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(icons), (icon) => {
              return openBlock(), createElementBlock("div", {
                key: unref(objectId)(icon),
                class: normalizeClass([icon.fulfilled && unref($style).dimmed])
              }, [
                icon.type === "SHIPMENT" ? (openBlock(), createBlock(ShipmentIcon, {
                  key: 0,
                  size: "small",
                  "shipment-id": icon.shipmentId
                }, null, 8, ["shipment-id"])) : createCommentVNode("", true),
                icon.type === "MATERIAL" ? (openBlock(), createBlock(MaterialIcon, {
                  key: 1,
                  size: "small",
                  compact: "",
                  ticker: icon.ticker,
                  amount: icon.amount
                }, null, 8, ["ticker", "amount"])) : createCommentVNode("", true)
              ], 2);
            }), 128))
          ], 2)
        ]),
        createBaseVNode("td", null, [
          createVNode(PartnerLink, { contract: _ctx.contract }, null, 8, ["contract"])
        ]),
        createBaseVNode("td", {
          class: normalizeClass(unref($style).receivable)
        }, toDisplayString(formatAmount(unref(receivable).total, unref(receivable).currency)), 3),
        createBaseVNode("td", {
          class: normalizeClass(unref($style).payable)
        }, toDisplayString(formatAmount(unref(payable).total, unref(payable).currency)), 3),
        createBaseVNode("td", null, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).progressContainer)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).progressBar)
            }, [
              createBaseVNode("div", {
                class: normalizeClass([unref($style).progressFill, unref(progressClass)]),
                style: normalizeStyle({ width: unref(progress) + "%" })
              }, null, 6)
            ], 2),
            createBaseVNode("span", {
              class: normalizeClass(unref($style).progressText)
            }, toDisplayString(unref(fulfilledCount)) + "/" + toDisplayString(unref(totalCount)), 3)
          ], 2)
        ]),
        createBaseVNode("td", {
          class: normalizeClass(unref(statusClass))
        }, toDisplayString(unref(statusText)), 3)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
