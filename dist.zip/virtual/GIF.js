import xit from "./xit-registry.js";
import GIF from "./GIF.vue.js";
xit.add({
  command: "GIF",
  name: "随机 GIF",
  description: "显示随机 GIF 图片。",
  optionalParameters: "GIF 类别",
  component: () => GIF
});
