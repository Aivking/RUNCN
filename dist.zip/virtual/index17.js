import gripCss from "./grip.module.css.js";
import { ref } from "./reactivity.esm-bundler.js";
import { watch } from "./runtime-core.esm-bundler.js";
const dragging = ref(false);
const draggable = {
  animation: 150,
  handle: `.${gripCss.grip}`,
  onStart: () => dragging.value = true,
  onEnd: () => dragging.value = false
};
watch(dragging, () => {
  document.documentElement.classList.toggle(gripCss.gripRoot, dragging.value);
});
const grip = {
  class: gripCss.grip,
  draggable
};
export {
  grip
};
