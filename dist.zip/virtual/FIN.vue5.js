import { withKeys } from "./runtime-dom.esm-bundler.js";
import SectionHeader from "./SectionHeader.vue.js";
import _sfc_main$6 from "./Tooltip.vue.js";
import _sfc_main$5 from "./Commands.vue.js";
import _sfc_main$4 from "./PrunButton.vue.js";
import { hhmm, ddmmyyyy, fixed0 } from "./format.js";
import { userData, clearBalanceHistory } from "./user-data.js";
import { calcEquity } from "./balance-sheet-summary.js";
import { showConfirmationOverlay } from "./tile-overlay.js";
import { balanceHistory, collectFinDataPoint, canCollectFinDataPoint } from "./user-data-balance.js";
import _sfc_main$2 from "./Active.vue.js";
import _sfc_main$3 from "./TextInput.vue.js";
import { objectId } from "./object-id.js";
import _sfc_main$1 from "./RadioItem.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FIN",
  setup(__props) {
    const sortedData = computed(() => balanceHistory.value.slice().reverse());
    function confirmDataPointDelete(ev, index) {
      index = balanceHistory.value.length - index - 1;
      showConfirmationOverlay(ev, () => deleteBalanceHistoryDataPoint(index), {
        message: `你即将删除一个历史数据点。是否继续？`
      });
    }
    function deleteBalanceHistoryDataPoint(index) {
      const history = userData.balanceHistory;
      if (index < history.v1.length) {
        history.v1.splice(index, 1);
      } else {
        history.v2.splice(index - history.v1.length, 1);
      }
    }
    function confirmAllDataDelete(ev) {
      showConfirmationOverlay(ev, clearBalanceHistory, {
        message: `你即将清除所有历史财务数据。是否继续？`
      });
    }
    function formatValue(number) {
      return number !== void 0 ? fixed0(number) : "--";
    }
    const mmMaterials = ref(userData.settings.financial.mmMaterials);
    function onMMMaterialsSubmit() {
      const formatted = (mmMaterials.value ?? "").replaceAll(" ", "").toUpperCase();
      userData.settings.financial.mmMaterials = formatted;
      mmMaterials.value = formatted;
    }
    const ignoredMaterials = ref(userData.settings.financial.ignoredMaterials);
    function onIgnoredMaterialsSubmit() {
      const formatted = (ignoredMaterials.value ?? "").replaceAll(" ", "").toUpperCase();
      userData.settings.financial.ignoredMaterials = formatted;
      ignoredMaterials.value = formatted;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[3] || (_cache[3] = [
            createTextVNode("权益模式", -1)
          ])]),
          _: 1
        }),
        createVNode(_sfc_main$2, {
          label: "权益模式",
          tooltip: "在此模式下，权益包括所有资产的市场价值，包括船舶、总部升级和 ARC。\n     不建议新手使用，因为初始船舶的价值与初始资源不成比例。\n     请注意，即使禁用此模式，你的财务数据历史仍会完整收集，\n     因此你可以随时切换到完整权益模式。",
          "tooltip-position": "bottom"
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              modelValue: unref(userData).fullEquityMode,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => unref(userData).fullEquityMode = $event)
            }, {
              default: withCtx(() => [..._cache[4] || (_cache[4] = [
                createTextVNode("完整权益", -1)
              ])]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[5] || (_cache[5] = [
            createTextVNode("价格设置", -1)
          ])]),
          _: 1
        }),
        createVNode(_sfc_main$2, {
          label: "MM 材料",
          tooltip: "逗号分隔的做市商材料列表。这些材料的价格将等于 MM 买入价。"
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$3, {
              modelValue: unref(mmMaterials),
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(mmMaterials) ? mmMaterials.value = $event : null),
              onKeyup: withKeys(onMMMaterialsSubmit, ["enter"]),
              onFocusout: onMMMaterialsSubmit
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$2, {
          label: "忽略材料",
          tooltip: "逗号分隔的忽略材料列表。这些材料的价格被视为零。"
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$3, {
              modelValue: unref(ignoredMaterials),
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(ignoredMaterials) ? ignoredMaterials.value = $event : null),
              onKeyup: withKeys(onIgnoredMaterialsSubmit, ["enter"]),
              onFocusout: onIgnoredMaterialsSubmit
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[6] || (_cache[6] = [
            createTextVNode("已收集的数据点", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$5, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                primary: "",
                disabled: !unref(canCollectFinDataPoint)(),
                onClick: unref(collectFinDataPoint)
              }, {
                default: withCtx(() => [..._cache[7] || (_cache[7] = [
                  createTextVNode(" 收集数据点 ", -1)
                ])]),
                _: 1
              }, 8, ["disabled", "onClick"])
            ]),
            _: 1
          })
        ]),
        createBaseVNode("table", null, [
          _cache[9] || (_cache[9] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "日期"),
              createBaseVNode("th", null, "权益"),
              createBaseVNode("th", null, "命令")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(sortedData), (balance, i) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(balance)
              }, [
                createBaseVNode("td", null, toDisplayString(unref(hhmm)(balance.timestamp)) + " " + toDisplayString(unref(ddmmyyyy)(balance.timestamp)), 1),
                createBaseVNode("td", null, toDisplayString(formatValue(unref(calcEquity)(balance))), 1),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$4, {
                    dark: "",
                    inline: "",
                    onClick: ($event) => confirmDataPointDelete($event, i)
                  }, {
                    default: withCtx(() => [..._cache[8] || (_cache[8] = [
                      createTextVNode("删除", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            _cache[10] || (_cache[10] = createTextVNode(" 危险区域 ", -1)),
            createVNode(_sfc_main$6, {
              class: normalizeClass(_ctx.$style.tooltip),
              tooltip: "清除所有历史财务数据"
            }, null, 8, ["class"])
          ]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$5, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                danger: "",
                onClick: confirmAllDataDelete
              }, {
                default: withCtx(() => [..._cache[11] || (_cache[11] = [
                  createTextVNode("清除财务数据", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
