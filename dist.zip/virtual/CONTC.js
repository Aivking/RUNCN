import xit from "./xit-registry.js";
import _sfc_main from "./CONTC.vue.js";
xit.add({
  command: ["CONTC"],
  name: "待处理合同条件",
  description: "显示待处理的合同条件。",
  contextItems: () => [{ cmd: "XIT CONTS" }, { cmd: "CONTS" }, { cmd: "CONTD" }],
  component: () => _sfc_main
});
