import LoadingSpinner from "./LoadingSpinner.vue.js";
import { contractsStore } from "./contracts.js";
import LoanRow from "./LoanRow.vue.js";
import { isEmpty } from "./is-empty.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList, createCommentVNode, createTextVNode } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const _hoisted_1 = ["onClick"];
const _hoisted_2 = { key: 0 };
const _hoisted_3 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "LOAN",
  setup(__props) {
    const STATUS_FILTERS = [
      { key: "OPEN", label: "公开", colorClass: "neutral" },
      { key: "CLOSED", label: "进行中", colorClass: "good" },
      { key: "FULFILLED", label: "已完成", colorClass: "good" },
      { key: "PARTIALLY_FULFILLED", label: "部分完成", colorClass: "partial" },
      { key: "BREACHED", label: "已违约", colorClass: "bad" },
      { key: "TERMINATED", label: "已终止", colorClass: "bad" },
      { key: "CANCELLED", label: "已取消", colorClass: "bad" },
      { key: "REJECTED", label: "已拒绝", colorClass: "bad" },
      { key: "DEADLINE_EXCEEDED", label: "已逾期", colorClass: "bad" }
    ];
    const activeFilters = ref(
      /* @__PURE__ */ new Set(["OPEN", "CLOSED", "PARTIALLY_FULFILLED", "DEADLINE_EXCEEDED"])
    );
    const showFilters = ref(true);
    function toggleFilter(key) {
      const newSet = new Set(activeFilters.value);
      if (newSet.has(key)) {
        newSet.delete(key);
      } else {
        newSet.add(key);
      }
      activeFilters.value = newSet;
    }
    function selectAll() {
      activeFilters.value = new Set(STATUS_FILTERS.map((f) => f.key));
    }
    function selectNone() {
      activeFilters.value = /* @__PURE__ */ new Set();
    }
    function isLoanContract(contract) {
      return contract.conditions.some((c) => c.type === "LOAN_PAYOUT" || c.type === "LOAN_INSTALLMENT");
    }
    function isBorrowing(contract) {
      const payout = contract.conditions.find((c) => c.type === "LOAN_PAYOUT");
      if (!payout) return false;
      return payout.party !== contract.party;
    }
    const loanContracts = computed(
      () => (contractsStore.all.value ?? []).filter(
        (c) => isLoanContract(c) && activeFilters.value.has(c.status)
      )
    );
    const borrowed = computed(
      () => loanContracts.value.filter(isBorrowing).sort((a, b) => (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0))
    );
    const lent = computed(
      () => loanContracts.value.filter((c) => !isBorrowing(c)).sort((a, b) => (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0))
    );
    function getLoanSummary(contracts) {
      let totalPrincipal = 0;
      let totalPaid = 0;
      let totalInstallments = 0;
      let fulfilledInstallments = 0;
      let currency = "";
      for (const contract of contracts) {
        for (const cond of contract.conditions) {
          if (cond.type === "LOAN_PAYOUT" && cond.amount) {
            totalPrincipal += cond.amount.amount;
            if (!currency) currency = cond.amount.currency;
          }
          if (cond.type === "LOAN_INSTALLMENT") {
            totalInstallments++;
            if (cond.status === "FULFILLED") {
              fulfilledInstallments++;
              if (cond.repayment) {
                totalPaid += cond.repayment.amount;
              }
            }
          }
        }
      }
      return { totalPrincipal, totalPaid, totalInstallments, fulfilledInstallments, currency };
    }
    const borrowedSummary = computed(() => getLoanSummary(borrowed.value));
    const lentSummary = computed(() => getLoanSummary(lent.value));
    function formatAmount(amount, currency) {
      if (!currency) return "0";
      return `${amount.toLocaleString()} ${currency}`;
    }
    return (_ctx, _cache) => {
      return !unref(contractsStore).fetched ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.container)
      }, [
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.filterBar)
        }, [
          createBaseVNode("span", {
            class: normalizeClass(_ctx.$style.filterIcon)
          }, "⚙", 2),
          createBaseVNode("button", {
            class: normalizeClass(_ctx.$style.filterAction),
            onClick: selectAll
          }, "全部", 2),
          createBaseVNode("button", {
            class: normalizeClass(_ctx.$style.filterAction),
            onClick: selectNone
          }, "无", 2),
          createBaseVNode("button", {
            class: normalizeClass(_ctx.$style.filterAction),
            onClick: _cache[0] || (_cache[0] = ($event) => showFilters.value = !unref(showFilters))
          }, toDisplayString(unref(showFilters) ? "隐藏过滤器" : "显示过滤器"), 3)
        ], 2),
        unref(showFilters) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(_ctx.$style.statusFilters)
        }, [
          (openBlock(), createElementBlock(Fragment, null, renderList(STATUS_FILTERS, (f) => {
            return createBaseVNode("button", {
              key: f.key,
              class: normalizeClass([
                _ctx.$style.statusBtn,
                _ctx.$style[f.colorClass],
                !unref(activeFilters).has(f.key) && _ctx.$style.inactive
              ]),
              onClick: ($event) => toggleFilter(f.key)
            }, toDisplayString(f.label), 11, _hoisted_1);
          }), 64))
        ], 2)) : createCommentVNode("", true),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", {
                colspan: "6",
                class: normalizeClass(_ctx.$style.sectionHeader)
              }, [
                _cache[1] || (_cache[1] = createTextVNode(" 📥 借入贷款 ", -1)),
                !unref(isEmpty)(unref(borrowed)) ? (openBlock(), createElementBlock("span", {
                  key: 0,
                  class: normalizeClass(_ctx.$style.summary)
                }, " 本金合计: " + toDisplayString(formatAmount(unref(borrowedSummary).totalPrincipal, unref(borrowedSummary).currency)) + " | 已还: " + toDisplayString(unref(borrowedSummary).fulfilledInstallments) + "/" + toDisplayString(unref(borrowedSummary).totalInstallments) + " 期 ", 3)) : createCommentVNode("", true)
              ], 2)
            ]),
            _cache[2] || (_cache[2] = createBaseVNode("tr", null, [
              createBaseVNode("th", null, "合同"),
              createBaseVNode("th", null, "对方"),
              createBaseVNode("th", null, "本金"),
              createBaseVNode("th", null, "利息"),
              createBaseVNode("th", null, "还款进度"),
              createBaseVNode("th", null, "状态")
            ], -1))
          ]),
          createBaseVNode("tbody", null, [
            unref(isEmpty)(unref(borrowed)) ? (openBlock(), createElementBlock("tr", _hoisted_2, [
              createBaseVNode("td", {
                colspan: "6",
                class: normalizeClass(_ctx.$style.empty)
              }, "暂无借入贷款", 2)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(borrowed), (contract) => {
              return openBlock(), createBlock(LoanRow, {
                key: contract.id,
                contract,
                type: "borrow"
              }, null, 8, ["contract"]);
            }), 128))
          ])
        ]),
        createBaseVNode("table", {
          class: normalizeClass(_ctx.$style.secondTable)
        }, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", {
                colspan: "6",
                class: normalizeClass(_ctx.$style.sectionHeader)
              }, [
                _cache[3] || (_cache[3] = createTextVNode(" 📤 放出贷款 ", -1)),
                !unref(isEmpty)(unref(lent)) ? (openBlock(), createElementBlock("span", {
                  key: 0,
                  class: normalizeClass(_ctx.$style.summary)
                }, " 本金合计: " + toDisplayString(formatAmount(unref(lentSummary).totalPrincipal, unref(lentSummary).currency)) + " | 已收: " + toDisplayString(unref(lentSummary).fulfilledInstallments) + "/" + toDisplayString(unref(lentSummary).totalInstallments) + " 期 ", 3)) : createCommentVNode("", true)
              ], 2)
            ]),
            _cache[4] || (_cache[4] = createBaseVNode("tr", null, [
              createBaseVNode("th", null, "合同"),
              createBaseVNode("th", null, "对方"),
              createBaseVNode("th", null, "本金"),
              createBaseVNode("th", null, "利息"),
              createBaseVNode("th", null, "回收进度"),
              createBaseVNode("th", null, "状态")
            ], -1))
          ]),
          createBaseVNode("tbody", null, [
            unref(isEmpty)(unref(lent)) ? (openBlock(), createElementBlock("tr", _hoisted_3, [
              createBaseVNode("td", {
                colspan: "6",
                class: normalizeClass(_ctx.$style.empty)
              }, "暂无放出贷款", 2)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(lent), (contract) => {
              return openBlock(), createBlock(LoanRow, {
                key: contract.id,
                contract,
                type: "lend"
              }, null, 8, ["contract"]);
            }), 128))
          ])
        ], 2)
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
