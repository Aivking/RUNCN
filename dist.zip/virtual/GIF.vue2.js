import { useCssModule } from "./runtime-dom.esm-bundler.js";
import LoadingSpinner from "./LoadingSpinner.vue.js";
import { useXitParameters } from "./use-xit-parameters.js";
import { getGifUrl } from "./gif-provider.js";
import { defineComponent, computed, useTemplateRef, onMounted, watchEffect, openBlock, createElementBlock, createBlock, createCommentVNode, createElementVNode as createBaseVNode, Fragment } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { normalizeClass } from "./shared.esm-bundler.js";
const _hoisted_1 = ["src"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GIF",
  setup(__props) {
    const $style = useCssModule();
    const parameters = useXitParameters();
    const tag = parameters.join(" ");
    const isLoading = ref(false);
    const url = ref();
    const containerClass = computed(() => ({
      [$style.containerClickable]: !isLoading.value
    }));
    async function load() {
      if (isLoading.value) {
        return;
      }
      isLoading.value = true;
      url.value = await getGifUrl(tag) ?? "";
    }
    function onLoad() {
      isLoading.value = false;
    }
    const container = useTemplateRef("container");
    const wrap = useTemplateRef("wrap");
    const image = useTemplateRef("image");
    onMounted(() => void load());
    watchEffect(() => image.value?.addEventListener("load", layout));
    watchEffect(() => {
      if (container.value) {
        new ResizeObserver(layout).observe(container.value);
      }
    });
    function layout() {
      if (!container.value || !wrap.value || !image.value) {
        return;
      }
      const maxW = container.value.clientWidth;
      const maxH = container.value.clientHeight;
      let nw = image.value.naturalWidth;
      if (nw === 0) {
        nw = 1;
      }
      let nh = image.value.naturalHeight;
      if (nh === 0) {
        nh = 1;
      }
      const ar = nw / nh;
      let w = maxW;
      let h = w / ar;
      if (h > maxH) {
        h = maxH;
        w = h * ar;
      }
      wrap.value.style.width = `${w}px`;
      wrap.value.style.height = `${h}px`;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        unref(isLoading) ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : createCommentVNode("", true),
        createBaseVNode("div", {
          ref_key: "container",
          ref: container,
          class: normalizeClass([unref($style).container, unref(containerClass)]),
          onClick: load
        }, [
          createBaseVNode("div", {
            ref_key: "wrap",
            ref: wrap,
            class: normalizeClass(unref($style).wrap)
          }, [
            createBaseVNode("img", {
              ref_key: "image",
              ref: image,
              class: normalizeClass(unref($style).image),
              src: unref(url),
              alt: "gif",
              onLoad,
              onError: onLoad
            }, null, 42, _hoisted_1),
            createBaseVNode("img", {
              src: "https://refined-prun.github.io/assets/klipy.png",
              alt: "Klipy",
              class: normalizeClass(unref($style).watermark)
            }, null, 2)
          ], 2)
        ], 2)
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
