const grip = "rp-grip__grip___8f6617d";
const gripRoot = "rp-grip__gripRoot___4a54ae0";
const gripCss = {
  grip,
  gripRoot
};
export {
  gripCss as default,
  grip,
  gripRoot
};
