import LoadingSpinner from "./LoadingSpinner.vue.js";
import { contractsStore } from "./contracts.js";
import HaulRow from "./HaulRow.vue.js";
import { isEmpty } from "./is-empty.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList, createCommentVNode, createTextVNode } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const _hoisted_1 = ["onClick"];
const _hoisted_2 = { key: 0 };
const _hoisted_3 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "HAUL",
  setup(__props) {
    const TRANSPORT_TYPES = [
      "DELIVERY_SHIPMENT",
      "PICKUP_SHIPMENT",
      "PROVISION_SHIPMENT"
    ];
    const STATUS_FILTERS = [
      { key: "OPEN", label: "公开", colorClass: "neutral" },
      { key: "CLOSED", label: "进行中", colorClass: "good" },
      { key: "FULFILLED", label: "已完成", colorClass: "good" },
      { key: "PARTIALLY_FULFILLED", label: "部分完成", colorClass: "partial" },
      { key: "BREACHED", label: "已违约", colorClass: "bad" },
      { key: "TERMINATED", label: "已终止", colorClass: "bad" },
      { key: "CANCELLED", label: "已取消", colorClass: "bad" },
      { key: "REJECTED", label: "已拒绝", colorClass: "bad" },
      { key: "DEADLINE_EXCEEDED", label: "已逾期", colorClass: "bad" }
    ];
    const activeFilters = ref(
      /* @__PURE__ */ new Set(["OPEN", "CLOSED", "PARTIALLY_FULFILLED", "DEADLINE_EXCEEDED"])
    );
    const showFilters = ref(true);
    function toggleFilter(key) {
      const newSet = new Set(activeFilters.value);
      if (newSet.has(key)) {
        newSet.delete(key);
      } else {
        newSet.add(key);
      }
      activeFilters.value = newSet;
    }
    function selectAll() {
      activeFilters.value = new Set(STATUS_FILTERS.map((f) => f.key));
    }
    function selectNone() {
      activeFilters.value = /* @__PURE__ */ new Set();
    }
    function isTransportContract(contract) {
      return contract.conditions.some((c) => TRANSPORT_TYPES.includes(c.type));
    }
    function isCarrier(contract) {
      const pickup = contract.conditions.find((c) => c.type === "PICKUP_SHIPMENT");
      if (pickup) return pickup.party === contract.party;
      const delivery = contract.conditions.find((c) => c.type === "DELIVERY_SHIPMENT");
      if (delivery) return delivery.party === contract.party;
      return false;
    }
    const transportContracts = computed(
      () => (contractsStore.all.value ?? []).filter(
        (c) => isTransportContract(c) && activeFilters.value.has(c.status)
      )
    );
    const carrying = computed(
      () => transportContracts.value.filter(isCarrier).sort((a, b) => (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0))
    );
    const shipping = computed(
      () => transportContracts.value.filter((c) => !isCarrier(c)).sort((a, b) => (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0))
    );
    function getTransportSummary(contracts) {
      let totalPayment = 0;
      let currency = "";
      let totalContracts = contracts.length;
      let completedContracts = 0;
      for (const contract of contracts) {
        if (contract.status === "FULFILLED") completedContracts++;
        for (const cond of contract.conditions) {
          if (cond.type === "PAYMENT" && cond.amount) {
            totalPayment += cond.amount.amount;
            if (!currency) currency = cond.amount.currency;
          }
        }
      }
      return { totalPayment, currency, totalContracts, completedContracts };
    }
    const carryingSummary = computed(() => getTransportSummary(carrying.value));
    const shippingSummary = computed(() => getTransportSummary(shipping.value));
    function formatAmount(amount, currency) {
      if (!currency) return "0";
      return `${amount.toLocaleString()} ${currency}`;
    }
    return (_ctx, _cache) => {
      return !unref(contractsStore).fetched ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.container)
      }, [
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.filterBar)
        }, [
          createBaseVNode("span", {
            class: normalizeClass(_ctx.$style.filterIcon)
          }, "⚙", 2),
          createBaseVNode("button", {
            class: normalizeClass(_ctx.$style.filterAction),
            onClick: selectAll
          }, "全部", 2),
          createBaseVNode("button", {
            class: normalizeClass(_ctx.$style.filterAction),
            onClick: selectNone
          }, "无", 2),
          createBaseVNode("button", {
            class: normalizeClass(_ctx.$style.filterAction),
            onClick: _cache[0] || (_cache[0] = ($event) => showFilters.value = !unref(showFilters))
          }, toDisplayString(unref(showFilters) ? "隐藏过滤器" : "显示过滤器"), 3)
        ], 2),
        unref(showFilters) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(_ctx.$style.statusFilters)
        }, [
          (openBlock(), createElementBlock(Fragment, null, renderList(STATUS_FILTERS, (f) => {
            return createBaseVNode("button", {
              key: f.key,
              class: normalizeClass([
                _ctx.$style.statusBtn,
                _ctx.$style[f.colorClass],
                !unref(activeFilters).has(f.key) && _ctx.$style.inactive
              ]),
              onClick: ($event) => toggleFilter(f.key)
            }, toDisplayString(f.label), 11, _hoisted_1);
          }), 64))
        ], 2)) : createCommentVNode("", true),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", {
                colspan: "8",
                class: normalizeClass(_ctx.$style.sectionHeader)
              }, [
                _cache[1] || (_cache[1] = createTextVNode(" 🚀 承运合同 ", -1)),
                !unref(isEmpty)(unref(carrying)) ? (openBlock(), createElementBlock("span", {
                  key: 0,
                  class: normalizeClass(_ctx.$style.summary)
                }, " 共 " + toDisplayString(unref(carryingSummary).totalContracts) + " 单 | 已完成 " + toDisplayString(unref(carryingSummary).completedContracts) + " 单 | 运费合计: " + toDisplayString(formatAmount(unref(carryingSummary).totalPayment, unref(carryingSummary).currency)), 3)) : createCommentVNode("", true)
              ], 2)
            ]),
            _cache[2] || (_cache[2] = createBaseVNode("tr", null, [
              createBaseVNode("th", null, "合同"),
              createBaseVNode("th", null, "对方"),
              createBaseVNode("th", null, "起点"),
              createBaseVNode("th", null, "终点"),
              createBaseVNode("th", null, "货物"),
              createBaseVNode("th", null, "运费"),
              createBaseVNode("th", null, "进度"),
              createBaseVNode("th", null, "状态")
            ], -1))
          ]),
          createBaseVNode("tbody", null, [
            unref(isEmpty)(unref(carrying)) ? (openBlock(), createElementBlock("tr", _hoisted_2, [
              createBaseVNode("td", {
                colspan: "8",
                class: normalizeClass(_ctx.$style.empty)
              }, "暂无承运合同", 2)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(carrying), (contract) => {
              return openBlock(), createBlock(HaulRow, {
                key: contract.id,
                contract,
                type: "carrier"
              }, null, 8, ["contract"]);
            }), 128))
          ])
        ]),
        createBaseVNode("table", {
          class: normalizeClass(_ctx.$style.secondTable)
        }, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", {
                colspan: "8",
                class: normalizeClass(_ctx.$style.sectionHeader)
              }, [
                _cache[3] || (_cache[3] = createTextVNode(" 📦 委托运输 ", -1)),
                !unref(isEmpty)(unref(shipping)) ? (openBlock(), createElementBlock("span", {
                  key: 0,
                  class: normalizeClass(_ctx.$style.summary)
                }, " 共 " + toDisplayString(unref(shippingSummary).totalContracts) + " 单 | 已完成 " + toDisplayString(unref(shippingSummary).completedContracts) + " 单 | 运费合计: " + toDisplayString(formatAmount(unref(shippingSummary).totalPayment, unref(shippingSummary).currency)), 3)) : createCommentVNode("", true)
              ], 2)
            ]),
            _cache[4] || (_cache[4] = createBaseVNode("tr", null, [
              createBaseVNode("th", null, "合同"),
              createBaseVNode("th", null, "对方"),
              createBaseVNode("th", null, "起点"),
              createBaseVNode("th", null, "终点"),
              createBaseVNode("th", null, "货物"),
              createBaseVNode("th", null, "运费"),
              createBaseVNode("th", null, "进度"),
              createBaseVNode("th", null, "状态")
            ], -1))
          ]),
          createBaseVNode("tbody", null, [
            unref(isEmpty)(unref(shipping)) ? (openBlock(), createElementBlock("tr", _hoisted_3, [
              createBaseVNode("td", {
                colspan: "8",
                class: normalizeClass(_ctx.$style.empty)
              }, "暂无委托运输", 2)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(shipping), (contract) => {
              return openBlock(), createBlock(HaulRow, {
                key: contract.id,
                contract,
                type: "shipper"
              }, null, 8, ["contract"]);
            }), 128))
          ])
        ], 2)
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
