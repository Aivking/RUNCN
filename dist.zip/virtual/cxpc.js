import { createEntityStore } from "./create-entity-store.js";
import { onApiMessage } from "./api-messages.js";
const store = createEntityStore({ selectId: (x) => x.brokerId });
const state = store.state;
onApiMessage({
  COMEX_BROKER_PRICES(data) {
    store.setOne(data);
    store.setFetched();
  }
});
const cxpcStore = {
  ...state
};
export {
  cxpcStore
};
