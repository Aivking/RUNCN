import { vModelText, vModelCheckbox, withKeys } from "./runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import { shipsStore } from "./ships.js";
import { flightsStore } from "./flights.js";
import { storagesStore } from "./storage.js";
import { getEntityNameFromAddress } from "./addresses.js";
import { fetchTransportRoutes, fetchShipStatuses, FactionApiError, deleteTransportRoute, updateShipManualStatus, updateTripStatus, deleteBooking, fetchTripsForRoute, updateTransportRoute, createTransportRoute, reportShipStatuses, createTrip, createBooking } from "./use-faction-api.js";
import $style from "./FactionPanel.module.css.js";
import css from "./FactionTransport.module.css.js";
import { companyStore } from "./company.js";
import { defineComponent, computed, onUnmounted, watchEffect, onMounted, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, withDirectives, Fragment, renderList, createCommentVNode, createBlock } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString, normalizeStyle } from "./shared.esm-bundler.js";
const _hoisted_1 = { style: { "display": "flex", "gap": "4px", "align-items": "center" } };
const _hoisted_2 = { style: { "display": "flex", "gap": "4px" } };
const _hoisted_3 = ["value", "checked", "onChange"];
const _hoisted_4 = {
  key: 0,
  style: { "margin-top": "1px", "display": "flex", "align-items": "center", "gap": "4px", "font-size": "10px", "opacity": "0.7" }
};
const _hoisted_5 = ["value", "onBlur"];
const _hoisted_6 = { style: { "display": "flex", "gap": "4px", "margin-top": "4px" } };
const _hoisted_7 = { style: { "display": "flex", "gap": "4px", "margin-top": "4px" } };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FactionTransport",
  props: {
    myRole: {}
  },
  setup(__props) {
    const props = __props;
    const routes = ref([]);
    const shipStatuses = ref([]);
    const loading = ref(false);
    const error = ref("");
    const searchQuery = ref("");
    const myCompanyName = ref("");
    const showForm = ref(false);
    const editingId = ref(null);
    const formDeparture = ref("");
    const formDestination = ref("");
    const formRoundTrip = ref(false);
    const formFeePerTon = ref("");
    const formFeePerM3 = ref("");
    const formShipRegistrations = ref([]);
    const formNotes = ref("");
    const isExecutive = computed(() => props.myRole === "executive");
    function toggleShipRegistration(reg) {
      const idx = formShipRegistrations.value.indexOf(reg);
      if (idx >= 0) {
        formShipRegistrations.value.splice(idx, 1);
      } else {
        formShipRegistrations.value.push(reg);
      }
    }
    const myShips = computed(() => shipsStore.all.value ?? []);
    const filteredRoutes = computed(() => {
      const q = searchQuery.value.trim().toLowerCase();
      let list = routes.value;
      if (q) {
        list = list.filter(
          (r) => r.departure.toLowerCase().includes(q) || r.destination.toLowerCase().includes(q) || r.companyName.toLowerCase().includes(q) || r.username && r.username.toLowerCase().includes(q) || r.shipRegistrations.some((reg) => reg.toLowerCase().includes(q))
        );
      }
      return [...list].sort((a, b) => {
        const aTrips = getTrips(a.id).length;
        const bTrips = getTrips(b.id).length;
        if (aTrips > 0 && bTrips === 0) return -1;
        if (aTrips === 0 && bTrips > 0) return 1;
        return 0;
      });
    });
    function getShipStatus(registration) {
      if (!registration) return void 0;
      return shipStatuses.value.find((s) => s.shipRegistration === registration);
    }
    function conditionClass(condition) {
      if (condition === void 0) return "";
      if (condition >= 0.8) return css.conditionGood;
      if (condition >= 0.5) return css.conditionWarn;
      return css.conditionBad;
    }
    function formatCondition(condition) {
      if (condition === void 0) return "--";
      return `${Math.round(condition * 100)}%`;
    }
    function formatEtaFromNow(eta) {
      if (!eta) return "";
      const diff = new Date(eta).getTime() - Date.now();
      if (diff <= 0) return "即将到达";
      const hours = Math.floor(diff / 36e5);
      const minutes = Math.floor(diff % 36e5 / 6e4);
      if (hours > 0) return `${hours}h${minutes}m`;
      return `${minutes}m`;
    }
    function canEdit(route) {
      return route.companyName === myCompanyName.value;
    }
    function canDelete(route) {
      return route.companyName === myCompanyName.value || isExecutive.value;
    }
    async function loadData() {
      loading.value = true;
      error.value = "";
      try {
        const [routesResult, statusResult] = await Promise.all([
          fetchTransportRoutes(),
          fetchShipStatuses()
        ]);
        routes.value = routesResult.routes;
        shipStatuses.value = statusResult.reports;
        await loadAllTrips();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      } finally {
        loading.value = false;
      }
    }
    function startCreate() {
      editingId.value = null;
      formDeparture.value = "";
      formDestination.value = "";
      formRoundTrip.value = false;
      formFeePerTon.value = "";
      formFeePerM3.value = "";
      formShipRegistrations.value = [];
      formNotes.value = "";
      showForm.value = true;
    }
    function startEdit(route) {
      editingId.value = route.id;
      formDeparture.value = route.departure;
      formDestination.value = route.destination;
      formRoundTrip.value = route.roundTrip;
      formFeePerTon.value = String(route.feePerTon);
      formFeePerM3.value = String(route.feePerM3);
      formShipRegistrations.value = [...route.shipRegistrations];
      formNotes.value = route.notes ?? "";
      showForm.value = true;
    }
    function cancelForm() {
      showForm.value = false;
      editingId.value = null;
    }
    async function handleSubmit() {
      const feePerTon = parseFloat(formFeePerTon.value) || 0;
      const feePerM3 = parseFloat(formFeePerM3.value) || 0;
      if (!formDeparture.value || !formDestination.value) return;
      const data = {
        departure: formDeparture.value,
        destination: formDestination.value,
        roundTrip: formRoundTrip.value,
        feePerTon,
        feePerM3,
        shipRegistrations: formShipRegistrations.value,
        notes: formNotes.value || void 0
      };
      try {
        if (editingId.value) {
          await updateTransportRoute(editingId.value, data);
        } else {
          await createTransportRoute(data);
        }
        showForm.value = false;
        editingId.value = null;
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    async function handleDelete(id) {
      try {
        await deleteTransportRoute(id);
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    const reportingStatus = ref(false);
    async function handleReportShips() {
      const ships = shipsStore.all.value ?? [];
      if (ships.length === 0 || !myCompanyName.value) return;
      reportingStatus.value = true;
      try {
        const reports = ships.map((ship) => {
          const flight = ship.flightId ? flightsStore.getById(ship.flightId) : void 0;
          const cargoStores = storagesStore.getByAddressableId(ship.id);
          const cargoStore = cargoStores?.find((s) => s.type === "SHIP_STORE");
          return {
            companyName: myCompanyName.value,
            shipRegistration: ship.registration,
            shipName: ship.name,
            condition: ship.condition,
            location: getEntityNameFromAddress(ship.address ?? void 0) ?? void 0,
            isFlying: !!ship.flightId,
            flightDestination: flight ? getEntityNameFromAddress(flight.destination) ?? void 0 : void 0,
            flightEta: flight ? new Date(flight.arrival.timestamp).toISOString() : void 0,
            cargoVolume: cargoStore?.volumeCapacity,
            cargoWeight: cargoStore?.weightCapacity
          };
        });
        await reportShipStatuses(reports);
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      } finally {
        reportingStatus.value = false;
      }
    }
    async function handleManualStatusChange(shipRegistration, event) {
      const value = event.target.value.trim() || null;
      try {
        await updateShipManualStatus(shipRegistration, value);
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    const tripsByRoute = ref({});
    const showTripForm = ref(null);
    const tripDepartureMode = ref("countdown");
    const tripCountdownHours = ref("");
    const tripCountdownMinutes = ref("");
    const tripDepartureTime = ref("");
    const tripAvailableVolume = ref("");
    const tripAvailableWeight = ref("");
    const tripDescription = ref("");
    const showBookingForm = ref(null);
    const bookingVolume = ref("");
    const bookingWeight = ref("");
    const bookingCargoDesc = ref("");
    function getTrips(routeId) {
      return tripsByRoute.value[routeId] ?? [];
    }
    function remainingVolume(trip) {
      const used = trip.bookings.reduce((sum, b) => sum + b.volume, 0);
      return Math.max(0, trip.availableVolume - used);
    }
    function remainingWeight(trip) {
      const used = trip.bookings.reduce((sum, b) => sum + b.weight, 0);
      return Math.max(0, trip.availableWeight - used);
    }
    function capacityPercent(used, total) {
      if (total <= 0) return 0;
      return Math.min(100, Math.round(used / total * 100));
    }
    function formatDepartureTime(iso) {
      const d = new Date(iso);
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      const hh = String(d.getHours()).padStart(2, "0");
      const min = String(d.getMinutes()).padStart(2, "0");
      return `${mm}/${dd} ${hh}:${min}`;
    }
    const now = ref(Date.now());
    let countdownTimer = null;
    function startCountdownTimer() {
      countdownTimer = setInterval(() => {
        now.value = Date.now();
      }, 1e3);
    }
    onUnmounted(() => {
      if (countdownTimer) {
        clearInterval(countdownTimer);
      }
    });
    function formatCountdown(iso) {
      const diff = new Date(iso).getTime() - now.value;
      if (diff <= 0) {
        return "已出发";
      }
      const h = Math.floor(diff / 36e5);
      const m = Math.floor(diff % 36e5 / 6e4);
      const s = Math.floor(diff % 6e4 / 1e3);
      if (h > 0) {
        return `${h}h ${m}m ${s}s`;
      }
      return `${m}m ${s}s`;
    }
    function isDeparted(iso) {
      return new Date(iso).getTime() <= now.value;
    }
    async function loadTripsForRoute(routeId) {
      try {
        const result = await fetchTripsForRoute(routeId);
        tripsByRoute.value[routeId] = result.trips;
      } catch {
      }
    }
    async function loadAllTrips() {
      await Promise.all(routes.value.map((r) => loadTripsForRoute(r.id)));
    }
    function startTripCreate(routeId, ship) {
      showTripForm.value = routeId;
      tripDepartureMode.value = "countdown";
      tripCountdownHours.value = "";
      tripCountdownMinutes.value = "";
      tripDepartureTime.value = "";
      tripAvailableVolume.value = ship?.cargoVolume ? String(ship.cargoVolume) : "";
      tripAvailableWeight.value = ship?.cargoWeight ? String(ship.cargoWeight) : "";
      tripDescription.value = "";
    }
    function cancelTripForm() {
      showTripForm.value = null;
    }
    function computedDepartureISO() {
      if (tripDepartureMode.value === "countdown") {
        const h = parseInt(tripCountdownHours.value) || 0;
        const m = parseInt(tripCountdownMinutes.value) || 0;
        if (h <= 0 && m <= 0) {
          return null;
        }
        return new Date(Date.now() + h * 36e5 + m * 6e4).toISOString();
      }
      if (!tripDepartureTime.value) {
        return null;
      }
      return new Date(tripDepartureTime.value).toISOString();
    }
    const canSubmitTrip = computed(() => {
      if (tripDepartureMode.value === "countdown") {
        const h = parseInt(tripCountdownHours.value) || 0;
        const m = parseInt(tripCountdownMinutes.value) || 0;
        return h > 0 || m > 0;
      }
      return !!tripDepartureTime.value;
    });
    async function handleCreateTrip(routeId) {
      const volume = parseFloat(tripAvailableVolume.value) || 0;
      const weight = parseFloat(tripAvailableWeight.value) || 0;
      const departureISO = computedDepartureISO();
      if (!departureISO || volume <= 0 || weight <= 0) {
        return;
      }
      try {
        await createTrip(routeId, {
          departureTime: departureISO,
          availableVolume: volume,
          availableWeight: weight,
          description: tripDescription.value || void 0
        });
        showTripForm.value = null;
        await loadTripsForRoute(routeId);
      } catch (e) {
        if (e instanceof FactionApiError) error.value = e.response.message;
      }
    }
    async function handleCloseTripStatus(tripId, routeId, status) {
      try {
        await updateTripStatus(tripId, status);
        await loadTripsForRoute(routeId);
      } catch (e) {
        if (e instanceof FactionApiError) error.value = e.response.message;
      }
    }
    function startBooking(tripId) {
      showBookingForm.value = tripId;
      bookingVolume.value = "";
      bookingWeight.value = "";
      bookingCargoDesc.value = "";
    }
    function cancelBookingForm() {
      showBookingForm.value = null;
    }
    async function handleCreateBooking(tripId, routeId) {
      const volume = parseFloat(bookingVolume.value) || 0;
      const weight = parseFloat(bookingWeight.value) || 0;
      if (volume <= 0 && weight <= 0) return;
      try {
        await createBooking(tripId, {
          volume,
          weight,
          cargoDescription: bookingCargoDesc.value || void 0
        });
        showBookingForm.value = null;
        await loadTripsForRoute(routeId);
      } catch (e) {
        if (e instanceof FactionApiError) error.value = e.response.message;
      }
    }
    async function handleDeleteBooking(bookingId, routeId) {
      try {
        await deleteBooking(bookingId);
        await loadTripsForRoute(routeId);
      } catch (e) {
        if (e instanceof FactionApiError) error.value = e.response.message;
      }
    }
    watchEffect(() => {
      const company = companyStore.value;
      if (company) {
        myCompanyName.value = company.name;
      }
    });
    onMounted(() => {
      loadData();
      startCountdownTimer();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass(unref($style).membersToolbar)
        }, [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_sfc_main$1, {
              dark: "",
              onClick: loadData
            }, {
              default: withCtx(() => [..._cache[19] || (_cache[19] = [
                createTextVNode("刷新", -1)
              ])]),
              _: 1
            }),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(searchQuery) ? searchQuery.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "text",
              placeholder: "搜索路线...",
              style: { "width": "140px" }
            }, null, 2), [
              [vModelText, unref(searchQuery)]
            ])
          ]),
          createBaseVNode("div", _hoisted_2, [
            createVNode(_sfc_main$1, {
              dark: "",
              disabled: unref(reportingStatus),
              onClick: handleReportShips
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(reportingStatus) ? "上报中..." : "上报状态"), 1)
              ]),
              _: 1
            }, 8, ["disabled"]),
            createVNode(_sfc_main$1, {
              dark: "",
              onClick: startCreate
            }, {
              default: withCtx(() => [..._cache[20] || (_cache[20] = [
                createTextVNode("发布路线 +", -1)
              ])]),
              _: 1
            })
          ])
        ], 2),
        unref(showForm) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref($style).loginContainer)
        }, [
          createBaseVNode("div", {
            class: normalizeClass(unref(css).formRow)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref(css).formHalf)
            }, [
              createBaseVNode("div", {
                class: normalizeClass(unref($style).field)
              }, [
                createBaseVNode("div", {
                  class: normalizeClass(unref($style).fieldLabel)
                }, "出发地", 2),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(formDeparture) ? formDeparture.value = $event : null),
                  class: normalizeClass(unref($style).fieldInput),
                  type: "text",
                  placeholder: "如 Montem"
                }, null, 2), [
                  [vModelText, unref(formDeparture)]
                ])
              ], 2)
            ], 2),
            createBaseVNode("div", {
              class: normalizeClass(unref(css).formHalf)
            }, [
              createBaseVNode("div", {
                class: normalizeClass(unref($style).field)
              }, [
                createBaseVNode("div", {
                  class: normalizeClass(unref($style).fieldLabel)
                }, "目的地", 2),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(formDestination) ? formDestination.value = $event : null),
                  class: normalizeClass(unref($style).fieldInput),
                  type: "text",
                  placeholder: "如 Promitor"
                }, null, 2), [
                  [vModelText, unref(formDestination)]
                ])
              ], 2)
            ], 2)
          ], 2),
          createBaseVNode("label", {
            class: normalizeClass(unref(css).checkboxRow)
          }, [
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(formRoundTrip) ? formRoundTrip.value = $event : null),
              type: "checkbox"
            }, null, 512), [
              [vModelCheckbox, unref(formRoundTrip)]
            ]),
            _cache[21] || (_cache[21] = createTextVNode(" 往返 ", -1))
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref(css).formRow)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref(css).formHalf)
            }, [
              createBaseVNode("div", {
                class: normalizeClass(unref($style).field)
              }, [
                createBaseVNode("div", {
                  class: normalizeClass(unref($style).fieldLabel)
                }, "每吨费用", 2),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(formFeePerTon) ? formFeePerTon.value = $event : null),
                  class: normalizeClass(unref($style).fieldInput),
                  type: "number",
                  min: "0",
                  step: "0.01"
                }, null, 2), [
                  [vModelText, unref(formFeePerTon)]
                ])
              ], 2)
            ], 2),
            createBaseVNode("div", {
              class: normalizeClass(unref(css).formHalf)
            }, [
              createBaseVNode("div", {
                class: normalizeClass(unref($style).field)
              }, [
                createBaseVNode("div", {
                  class: normalizeClass(unref($style).fieldLabel)
                }, "每m³费用", 2),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => isRef(formFeePerM3) ? formFeePerM3.value = $event : null),
                  class: normalizeClass(unref($style).fieldInput),
                  type: "number",
                  min: "0",
                  step: "0.01"
                }, null, 2), [
                  [vModelText, unref(formFeePerM3)]
                ])
              ], 2)
            ], 2)
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "绑定飞船（可选，可多选）", 2),
            createBaseVNode("div", {
              class: normalizeClass(unref(css).shipCheckboxList)
            }, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(myShips), (ship) => {
                return openBlock(), createElementBlock("label", {
                  key: ship.id,
                  class: normalizeClass(unref(css).shipCheckboxItem)
                }, [
                  createBaseVNode("input", {
                    type: "checkbox",
                    value: ship.registration,
                    checked: unref(formShipRegistrations).includes(ship.registration),
                    onChange: ($event) => toggleShipRegistration(ship.registration)
                  }, null, 40, _hoisted_3),
                  createTextVNode(" " + toDisplayString(ship.registration) + " - " + toDisplayString(ship.name), 1)
                ], 2);
              }), 128))
            ], 2)
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "备注（可选）", 2),
            withDirectives(createBaseVNode("textarea", {
              "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => isRef(formNotes) ? formNotes.value = $event : null),
              class: normalizeClass(unref(css).notesInput),
              rows: "2",
              placeholder: "运输备注信息..."
            }, null, 2), [
              [vModelText, unref(formNotes)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).buttonRow)
          }, [
            createVNode(_sfc_main$1, {
              dark: "",
              onClick: cancelForm
            }, {
              default: withCtx(() => [..._cache[22] || (_cache[22] = [
                createTextVNode("取消", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              disabled: !unref(formDeparture) || !unref(formDestination),
              onClick: handleSubmit
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(editingId) ? "更新" : "发布"), 1)
              ]),
              _: 1
            }, 8, ["disabled"])
          ], 2)
        ], 2)) : createCommentVNode("", true),
        unref(error) ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(unref($style).errorMessage)
        }, toDisplayString(unref(error)), 3)) : createCommentVNode("", true),
        unref(loading) ? (openBlock(), createElementBlock("div", {
          key: 2,
          class: normalizeClass(unref($style).loadingMessage)
        }, "加载中...", 2)) : (openBlock(), createElementBlock(Fragment, { key: 3 }, [
          unref(filteredRoutes).length === 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(unref($style).emptyMessage)
          }, "暂无运输路线", 2)) : createCommentVNode("", true),
          createBaseVNode("div", {
            class: normalizeClass(unref(css).routeGrid)
          }, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(filteredRoutes), (route) => {
              return openBlock(), createElementBlock("div", {
                key: route.id,
                class: normalizeClass(unref(css).routeCard)
              }, [
                createBaseVNode("div", {
                  class: normalizeClass(unref(css).cardHeader)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass(unref(css).cardOwner)
                  }, [
                    createBaseVNode("span", null, toDisplayString(route.companyName), 1),
                    route.username ? (openBlock(), createElementBlock("span", {
                      key: 0,
                      class: normalizeClass(unref(css).ownerUsername)
                    }, toDisplayString(route.username), 3)) : createCommentVNode("", true)
                  ], 2),
                  createBaseVNode("div", {
                    class: normalizeClass(unref(css).cardActions)
                  }, [
                    canEdit(route) ? (openBlock(), createBlock(_sfc_main$1, {
                      key: 0,
                      dark: "",
                      onClick: ($event) => startEdit(route)
                    }, {
                      default: withCtx(() => [..._cache[23] || (_cache[23] = [
                        createTextVNode("编辑", -1)
                      ])]),
                      _: 2
                    }, 1032, ["onClick"])) : createCommentVNode("", true),
                    canDelete(route) ? (openBlock(), createBlock(_sfc_main$1, {
                      key: 1,
                      danger: "",
                      onClick: ($event) => handleDelete(route.id)
                    }, {
                      default: withCtx(() => [..._cache[24] || (_cache[24] = [
                        createTextVNode("删除", -1)
                      ])]),
                      _: 2
                    }, 1032, ["onClick"])) : createCommentVNode("", true)
                  ], 2)
                ], 2),
                createBaseVNode("div", {
                  class: normalizeClass(unref(css).routeInfo)
                }, [
                  createBaseVNode("span", {
                    class: normalizeClass(unref(css).routeLocation)
                  }, toDisplayString(route.departure), 3),
                  createBaseVNode("span", {
                    class: normalizeClass(unref(css).routeArrow)
                  }, "→", 2),
                  createBaseVNode("span", {
                    class: normalizeClass(unref(css).routeLocation)
                  }, toDisplayString(route.destination), 3),
                  route.roundTrip ? (openBlock(), createElementBlock("span", {
                    key: 0,
                    class: normalizeClass(unref(css).roundTripBadge)
                  }, "往返", 2)) : createCommentVNode("", true)
                ], 2),
                createBaseVNode("div", {
                  class: normalizeClass(unref(css).feeInfo)
                }, toDisplayString(route.feePerTon) + "/t · " + toDisplayString(route.feePerM3) + "/m³ ", 3),
                route.notes ? (openBlock(), createElementBlock("div", {
                  key: 0,
                  class: normalizeClass(unref(css).routeNotes)
                }, toDisplayString(route.notes), 3)) : createCommentVNode("", true),
                (openBlock(true), createElementBlock(Fragment, null, renderList(route.shipRegistrations, (reg) => {
                  return openBlock(), createElementBlock("div", {
                    key: reg,
                    class: normalizeClass(unref(css).shipStatus)
                  }, [
                    getShipStatus(reg) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                      createBaseVNode("div", {
                        class: normalizeClass(unref(css).shipHeader)
                      }, [
                        createBaseVNode("span", {
                          class: normalizeClass(unref(css).shipReg)
                        }, toDisplayString(getShipStatus(reg).shipRegistration), 3),
                        getShipStatus(reg).shipName ? (openBlock(), createElementBlock("span", {
                          key: 0,
                          class: normalizeClass(unref(css).shipName)
                        }, toDisplayString(getShipStatus(reg).shipName), 3)) : createCommentVNode("", true),
                        createBaseVNode("span", {
                          class: normalizeClass([unref(css).shipCondition, conditionClass(getShipStatus(reg).condition)])
                        }, toDisplayString(formatCondition(getShipStatus(reg).condition)), 3),
                        getShipStatus(reg).location ? (openBlock(), createElementBlock("span", {
                          key: 1,
                          class: normalizeClass(unref(css).shipName)
                        }, toDisplayString(getShipStatus(reg).location), 3)) : createCommentVNode("", true)
                      ], 2),
                      createBaseVNode("div", {
                        class: normalizeClass(unref(css).shipFlight)
                      }, [
                        getShipStatus(reg).isFlying ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                          createBaseVNode("span", {
                            class: normalizeClass(unref(css).flyingBadge)
                          }, "飞行中", 2),
                          createTextVNode(" → " + toDisplayString(getShipStatus(reg).flightDestination) + " · ETA " + toDisplayString(formatEtaFromNow(getShipStatus(reg).flightEta)), 1)
                        ], 64)) : (openBlock(), createElementBlock("span", {
                          key: 1,
                          class: normalizeClass(unref(css).idleBadge)
                        }, "停靠中", 2)),
                        getShipStatus(reg).cargoVolume ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [
                          createTextVNode(" · " + toDisplayString(getShipStatus(reg).cargoVolume) + "m³ ", 1)
                        ], 64)) : createCommentVNode("", true),
                        getShipStatus(reg).cargoWeight ? (openBlock(), createElementBlock(Fragment, { key: 3 }, [
                          createTextVNode(" / " + toDisplayString(getShipStatus(reg).cargoWeight) + "t ", 1)
                        ], 64)) : createCommentVNode("", true),
                        getShipStatus(reg).manualStatus && !canEdit(route) ? (openBlock(), createElementBlock("span", {
                          key: 4,
                          class: normalizeClass(unref(css).manualStatusBadge)
                        }, toDisplayString(getShipStatus(reg).manualStatus), 3)) : createCommentVNode("", true)
                      ], 2),
                      canEdit(route) ? (openBlock(), createElementBlock("div", _hoisted_4, [
                        _cache[25] || (_cache[25] = createTextVNode(" 状态: ", -1)),
                        createBaseVNode("input", {
                          class: normalizeClass(unref(css).statusInput),
                          type: "text",
                          placeholder: "手动状态",
                          value: getShipStatus(reg).manualStatus ?? "",
                          onBlur: ($event) => handleManualStatusChange(reg, $event),
                          onKeyup: _cache[7] || (_cache[7] = withKeys(($event) => $event.target.blur(), ["enter"]))
                        }, null, 42, _hoisted_5)
                      ])) : createCommentVNode("", true)
                    ], 64)) : (openBlock(), createElementBlock("div", {
                      key: 1,
                      class: normalizeClass(unref(css).shipName)
                    }, toDisplayString(reg) + " · 等待状态上报... ", 3))
                  ], 2);
                }), 128)),
                createBaseVNode("div", {
                  class: normalizeClass(unref(css).tripSection)
                }, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(getTrips(route.id), (trip) => {
                    return openBlock(), createElementBlock("div", {
                      key: trip.id,
                      class: normalizeClass(unref(css).tripCard)
                    }, [
                      createBaseVNode("div", {
                        class: normalizeClass(unref(css).tripHeader)
                      }, [
                        createBaseVNode("span", {
                          class: normalizeClass([unref(css).tripCountdown, isDeparted(trip.departureTime) ? unref(css).departed : ""])
                        }, toDisplayString(formatCountdown(trip.departureTime)), 3),
                        createBaseVNode("span", {
                          class: normalizeClass(unref(css).tripTime)
                        }, toDisplayString(formatDepartureTime(trip.departureTime)), 3),
                        createBaseVNode("span", {
                          class: normalizeClass(unref(css).tripOwner)
                        }, toDisplayString(trip.companyName), 3),
                        trip.description ? (openBlock(), createElementBlock("span", {
                          key: 0,
                          class: normalizeClass(unref(css).tripDesc)
                        }, toDisplayString(trip.description), 3)) : createCommentVNode("", true)
                      ], 2),
                      createBaseVNode("div", {
                        class: normalizeClass(unref(css).capacityRow)
                      }, [
                        createBaseVNode("span", {
                          class: normalizeClass(unref(css).capacityLabel)
                        }, "体积", 2),
                        createBaseVNode("div", {
                          class: normalizeClass(unref(css).capacityBar)
                        }, [
                          createBaseVNode("div", {
                            class: normalizeClass(unref(css).capacityFill),
                            style: normalizeStyle({
                              width: capacityPercent(
                                trip.availableVolume - remainingVolume(trip),
                                trip.availableVolume
                              ) + "%",
                              backgroundColor: remainingVolume(trip) > 0 ? "rgb(146, 196, 125)" : "rgb(217, 83, 79)"
                            })
                          }, null, 6)
                        ], 2),
                        createBaseVNode("span", {
                          class: normalizeClass(unref(css).capacityText)
                        }, toDisplayString(Math.round(remainingVolume(trip))) + "/" + toDisplayString(trip.availableVolume) + "m³", 3)
                      ], 2),
                      createBaseVNode("div", {
                        class: normalizeClass(unref(css).capacityRow)
                      }, [
                        createBaseVNode("span", {
                          class: normalizeClass(unref(css).capacityLabel)
                        }, "重量", 2),
                        createBaseVNode("div", {
                          class: normalizeClass(unref(css).capacityBar)
                        }, [
                          createBaseVNode("div", {
                            class: normalizeClass(unref(css).capacityFill),
                            style: normalizeStyle({
                              width: capacityPercent(
                                trip.availableWeight - remainingWeight(trip),
                                trip.availableWeight
                              ) + "%",
                              backgroundColor: remainingWeight(trip) > 0 ? "rgb(146, 196, 125)" : "rgb(217, 83, 79)"
                            })
                          }, null, 6)
                        ], 2),
                        createBaseVNode("span", {
                          class: normalizeClass(unref(css).capacityText)
                        }, toDisplayString(Math.round(remainingWeight(trip))) + "/" + toDisplayString(trip.availableWeight) + "t", 3)
                      ], 2),
                      trip.bookings.length > 0 ? (openBlock(), createElementBlock("div", {
                        key: 0,
                        class: normalizeClass(unref(css).bookingList)
                      }, [
                        (openBlock(true), createElementBlock(Fragment, null, renderList(trip.bookings, (b) => {
                          return openBlock(), createElementBlock("div", {
                            key: b.id,
                            class: normalizeClass(unref(css).bookingRow)
                          }, [
                            createBaseVNode("span", {
                              class: normalizeClass(unref(css).bookingCompany)
                            }, toDisplayString(b.companyName), 3),
                            createBaseVNode("span", {
                              class: normalizeClass(unref(css).bookingAmount)
                            }, toDisplayString(b.volume) + "m³ " + toDisplayString(b.weight) + "t", 3),
                            b.cargoDescription ? (openBlock(), createElementBlock("span", {
                              key: 0,
                              class: normalizeClass(unref(css).bookingCargo)
                            }, toDisplayString(b.cargoDescription), 3)) : createCommentVNode("", true),
                            b.companyName === unref(myCompanyName) ? (openBlock(), createBlock(_sfc_main$1, {
                              key: 1,
                              danger: "",
                              style: { "font-size": "9px", "padding": "0 3px" },
                              onClick: ($event) => handleDeleteBooking(b.id, route.id)
                            }, {
                              default: withCtx(() => [..._cache[26] || (_cache[26] = [
                                createTextVNode(" 取消 ", -1)
                              ])]),
                              _: 2
                            }, 1032, ["onClick"])) : createCommentVNode("", true)
                          ], 2);
                        }), 128))
                      ], 2)) : createCommentVNode("", true),
                      unref(showBookingForm) === trip.id ? (openBlock(), createElementBlock("div", {
                        key: 1,
                        class: normalizeClass(unref(css).bookingForm)
                      }, [
                        createBaseVNode("div", {
                          class: normalizeClass(unref(css).formRow)
                        }, [
                          withDirectives(createBaseVNode("input", {
                            "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => isRef(bookingVolume) ? bookingVolume.value = $event : null),
                            class: normalizeClass(unref(css).statusInput),
                            type: "number",
                            min: "0",
                            placeholder: "m³",
                            style: { "width": "60px" }
                          }, null, 2), [
                            [vModelText, unref(bookingVolume)]
                          ]),
                          withDirectives(createBaseVNode("input", {
                            "onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => isRef(bookingWeight) ? bookingWeight.value = $event : null),
                            class: normalizeClass(unref(css).statusInput),
                            type: "number",
                            min: "0",
                            placeholder: "t",
                            style: { "width": "60px" }
                          }, null, 2), [
                            [vModelText, unref(bookingWeight)]
                          ]),
                          withDirectives(createBaseVNode("input", {
                            "onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => isRef(bookingCargoDesc) ? bookingCargoDesc.value = $event : null),
                            class: normalizeClass(unref(css).statusInput),
                            type: "text",
                            placeholder: "货物",
                            style: { "width": "60px" }
                          }, null, 2), [
                            [vModelText, unref(bookingCargoDesc)]
                          ])
                        ], 2),
                        createBaseVNode("div", _hoisted_6, [
                          createVNode(_sfc_main$1, {
                            dark: "",
                            onClick: cancelBookingForm
                          }, {
                            default: withCtx(() => [..._cache[27] || (_cache[27] = [
                              createTextVNode("取消", -1)
                            ])]),
                            _: 1
                          }),
                          createVNode(_sfc_main$1, {
                            primary: "",
                            onClick: ($event) => handleCreateBooking(trip.id, route.id)
                          }, {
                            default: withCtx(() => [..._cache[28] || (_cache[28] = [
                              createTextVNode("确认", -1)
                            ])]),
                            _: 2
                          }, 1032, ["onClick"])
                        ])
                      ], 2)) : createCommentVNode("", true),
                      createBaseVNode("div", {
                        class: normalizeClass(unref(css).tripActions)
                      }, [
                        unref(showBookingForm) !== trip.id && remainingVolume(trip) > 0 ? (openBlock(), createBlock(_sfc_main$1, {
                          key: 0,
                          dark: "",
                          onClick: ($event) => startBooking(trip.id)
                        }, {
                          default: withCtx(() => [..._cache[29] || (_cache[29] = [
                            createTextVNode(" 预订舱位 ", -1)
                          ])]),
                          _: 2
                        }, 1032, ["onClick"])) : createCommentVNode("", true),
                        trip.companyName === unref(myCompanyName) ? (openBlock(), createBlock(_sfc_main$1, {
                          key: 1,
                          danger: "",
                          onClick: ($event) => handleCloseTripStatus(trip.id, route.id, "closed")
                        }, {
                          default: withCtx(() => [..._cache[30] || (_cache[30] = [
                            createTextVNode(" 关闭航班 ", -1)
                          ])]),
                          _: 2
                        }, 1032, ["onClick"])) : createCommentVNode("", true)
                      ], 2)
                    ], 2);
                  }), 128)),
                  canEdit(route) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                    unref(showTripForm) === route.id ? (openBlock(), createElementBlock("div", {
                      key: 0,
                      class: normalizeClass(unref(css).tripFormContainer)
                    }, [
                      createBaseVNode("div", {
                        class: normalizeClass(unref(css).modeSwitch)
                      }, [
                        createBaseVNode("span", {
                          class: normalizeClass([
                            unref(css).modeOption,
                            unref(tripDepartureMode) === "countdown" ? unref(css).modeActive : ""
                          ]),
                          onClick: _cache[11] || (_cache[11] = ($event) => tripDepartureMode.value = "countdown")
                        }, " 倒计时 ", 2),
                        createBaseVNode("span", {
                          class: normalizeClass([
                            unref(css).modeOption,
                            unref(tripDepartureMode) === "schedule" ? unref(css).modeActive : ""
                          ]),
                          onClick: _cache[12] || (_cache[12] = ($event) => tripDepartureMode.value = "schedule")
                        }, " 预约时间 ", 2)
                      ], 2),
                      unref(tripDepartureMode) === "countdown" ? (openBlock(), createElementBlock("div", {
                        key: 0,
                        class: normalizeClass(unref(css).formRow)
                      }, [
                        createBaseVNode("div", {
                          class: normalizeClass(unref(css).formHalf)
                        }, [
                          createBaseVNode("div", {
                            class: normalizeClass(unref($style).field)
                          }, [
                            createBaseVNode("div", {
                              class: normalizeClass(unref($style).fieldLabel)
                            }, "小时", 2),
                            withDirectives(createBaseVNode("input", {
                              "onUpdate:modelValue": _cache[13] || (_cache[13] = ($event) => isRef(tripCountdownHours) ? tripCountdownHours.value = $event : null),
                              class: normalizeClass(unref($style).fieldInput),
                              type: "number",
                              min: "0",
                              placeholder: "0"
                            }, null, 2), [
                              [vModelText, unref(tripCountdownHours)]
                            ])
                          ], 2)
                        ], 2),
                        createBaseVNode("div", {
                          class: normalizeClass(unref(css).formHalf)
                        }, [
                          createBaseVNode("div", {
                            class: normalizeClass(unref($style).field)
                          }, [
                            createBaseVNode("div", {
                              class: normalizeClass(unref($style).fieldLabel)
                            }, "分钟", 2),
                            withDirectives(createBaseVNode("input", {
                              "onUpdate:modelValue": _cache[14] || (_cache[14] = ($event) => isRef(tripCountdownMinutes) ? tripCountdownMinutes.value = $event : null),
                              class: normalizeClass(unref($style).fieldInput),
                              type: "number",
                              min: "0",
                              max: "59",
                              placeholder: "0"
                            }, null, 2), [
                              [vModelText, unref(tripCountdownMinutes)]
                            ])
                          ], 2)
                        ], 2)
                      ], 2)) : (openBlock(), createElementBlock("div", {
                        key: 1,
                        class: normalizeClass(unref($style).field)
                      }, [
                        createBaseVNode("div", {
                          class: normalizeClass(unref($style).fieldLabel)
                        }, "出发时间", 2),
                        withDirectives(createBaseVNode("input", {
                          "onUpdate:modelValue": _cache[15] || (_cache[15] = ($event) => isRef(tripDepartureTime) ? tripDepartureTime.value = $event : null),
                          class: normalizeClass(unref($style).fieldInput),
                          type: "datetime-local"
                        }, null, 2), [
                          [vModelText, unref(tripDepartureTime)]
                        ])
                      ], 2)),
                      createBaseVNode("div", {
                        class: normalizeClass(unref(css).formRow)
                      }, [
                        createBaseVNode("div", {
                          class: normalizeClass(unref(css).formHalf)
                        }, [
                          createBaseVNode("div", {
                            class: normalizeClass(unref($style).field)
                          }, [
                            createBaseVNode("div", {
                              class: normalizeClass(unref($style).fieldLabel)
                            }, "可用体积 (m³)", 2),
                            withDirectives(createBaseVNode("input", {
                              "onUpdate:modelValue": _cache[16] || (_cache[16] = ($event) => isRef(tripAvailableVolume) ? tripAvailableVolume.value = $event : null),
                              class: normalizeClass(unref($style).fieldInput),
                              type: "number",
                              min: "0"
                            }, null, 2), [
                              [vModelText, unref(tripAvailableVolume)]
                            ])
                          ], 2)
                        ], 2),
                        createBaseVNode("div", {
                          class: normalizeClass(unref(css).formHalf)
                        }, [
                          createBaseVNode("div", {
                            class: normalizeClass(unref($style).field)
                          }, [
                            createBaseVNode("div", {
                              class: normalizeClass(unref($style).fieldLabel)
                            }, "可用重量 (t)", 2),
                            withDirectives(createBaseVNode("input", {
                              "onUpdate:modelValue": _cache[17] || (_cache[17] = ($event) => isRef(tripAvailableWeight) ? tripAvailableWeight.value = $event : null),
                              class: normalizeClass(unref($style).fieldInput),
                              type: "number",
                              min: "0"
                            }, null, 2), [
                              [vModelText, unref(tripAvailableWeight)]
                            ])
                          ], 2)
                        ], 2)
                      ], 2),
                      createBaseVNode("div", {
                        class: normalizeClass(unref($style).field)
                      }, [
                        createBaseVNode("div", {
                          class: normalizeClass(unref($style).fieldLabel)
                        }, "说明（可选）", 2),
                        withDirectives(createBaseVNode("input", {
                          "onUpdate:modelValue": _cache[18] || (_cache[18] = ($event) => isRef(tripDescription) ? tripDescription.value = $event : null),
                          class: normalizeClass(unref($style).fieldInput),
                          type: "text",
                          placeholder: "如：空船前往"
                        }, null, 2), [
                          [vModelText, unref(tripDescription)]
                        ])
                      ], 2),
                      createBaseVNode("div", _hoisted_7, [
                        createVNode(_sfc_main$1, {
                          dark: "",
                          onClick: cancelTripForm
                        }, {
                          default: withCtx(() => [..._cache[31] || (_cache[31] = [
                            createTextVNode("取消", -1)
                          ])]),
                          _: 1
                        }),
                        createVNode(_sfc_main$1, {
                          primary: "",
                          disabled: !unref(canSubmitTrip),
                          onClick: ($event) => handleCreateTrip(route.id)
                        }, {
                          default: withCtx(() => [..._cache[32] || (_cache[32] = [
                            createTextVNode("发布", -1)
                          ])]),
                          _: 2
                        }, 1032, ["disabled", "onClick"])
                      ])
                    ], 2)) : (openBlock(), createBlock(_sfc_main$1, {
                      key: 1,
                      dark: "",
                      style: { "margin-top": "4px", "font-size": "11px", "width": "100%" },
                      onClick: ($event) => startTripCreate(
                        route.id,
                        route.shipRegistrations.length > 0 ? getShipStatus(route.shipRegistrations[0]) : void 0
                      )
                    }, {
                      default: withCtx(() => [..._cache[33] || (_cache[33] = [
                        createTextVNode(" + 发布航班 ", -1)
                      ])]),
                      _: 2
                    }, 1032, ["onClick"]))
                  ], 64)) : createCommentVNode("", true)
                ], 2)
              ], 2);
            }), 128))
          ], 2)
        ], 64))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
