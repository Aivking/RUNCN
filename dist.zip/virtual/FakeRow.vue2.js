import IconCell from "./IconCell.vue.js";
import BuildingIcon from "./BuildingIcon.vue.js";
import InlineFlex from "./InlineFlex.vue.js";
import _sfc_main$1 from "./Tooltip.vue.js";
import _sfc_main$2 from "./PrunButton.vue.js";
import { defineComponent, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode } from "./runtime-core.esm-bundler.js";
import { normalizeClass } from "./shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FakeRow",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("tbody", {
        class: normalizeClass(_ctx.$style.fakeRow)
      }, [
        createBaseVNode("tr", null, [
          createVNode(IconCell, null, {
            default: withCtx(() => [
              createVNode(BuildingIcon, {
                size: "inline-table",
                ticker: "RIG"
              })
            ]),
            _: 1
          }),
          _cache[3] || (_cache[3] = createBaseVNode("td", null, "▶ INFO", -1)),
          createBaseVNode("td", null, [
            createVNode(InlineFlex, null, {
              default: withCtx(() => [
                _cache[0] || (_cache[0] = createTextVNode(" 100% ", -1)),
                createVNode(_sfc_main$1, {
                  position: "bottom",
                  tooltip: ""
                })
              ]),
              _: 1
            })
          ]),
          _cache[4] || (_cache[4] = createBaseVNode("td", null, "00/00", -1)),
          createBaseVNode("td", null, [
            createBaseVNode("div", {
              class: normalizeClass(_ctx.$style.buttons)
            }, [
              createVNode(_sfc_main$2, {
                dark: "",
                inline: ""
              }, {
                default: withCtx(() => [..._cache[1] || (_cache[1] = [
                  createTextVNode("CO", -1)
                ])]),
                _: 1
              }),
              createVNode(_sfc_main$2, {
                dark: "",
                inline: ""
              }, {
                default: withCtx(() => [..._cache[2] || (_cache[2] = [
                  createTextVNode("Q", -1)
                ])]),
                _: 1
              })
            ], 2)
          ])
        ])
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
