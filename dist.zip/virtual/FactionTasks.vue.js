import { vModelText, withModifiers, withKeys } from "./runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import { fetchTasks, FactionApiError, claimTask, updateTaskStatus, addTaskComment, deleteTask, createTask } from "./use-faction-api.js";
import { TASK_STATUS_LABELS } from "./types.js";
import $style from "./FactionPanel.module.css.js";
import { defineComponent, computed, onMounted, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createBlock, createCommentVNode, withDirectives, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass, normalizeStyle } from "./shared.esm-bundler.js";
const _hoisted_1 = ["onClick"];
const _hoisted_2 = { style: { "display": "flex", "justify-content": "space-between", "align-items": "center" } };
const _hoisted_3 = { style: { "font-size": "13px", "color": "rgb(230, 200, 80)", "font-weight": "bold" } };
const _hoisted_4 = { style: { "display": "flex", "align-items": "center", "gap": "4px" } };
const _hoisted_5 = {
  key: 0,
  style: { "opacity": "0.5", "font-size": "11px" }
};
const _hoisted_6 = {
  key: 0,
  style: { "color": "rgb(220, 220, 220)", "font-size": "12px", "margin": "4px 0" }
};
const _hoisted_7 = { style: { "font-size": "11px", "opacity": "0.5", "margin-bottom": "2px" } };
const _hoisted_8 = {
  key: 1,
  style: { "font-size": "11px", "margin-bottom": "2px" }
};
const _hoisted_9 = { style: { "color": "rgb(100, 180, 230)" } };
const _hoisted_10 = {
  key: 2,
  style: { "font-size": "11px", "margin-bottom": "4px" }
};
const _hoisted_11 = { style: { "color": "rgb(146, 196, 125)" } };
const _hoisted_12 = { style: { "display": "flex", "gap": "4px", "flex-wrap": "wrap", "margin": "4px 0" } };
const _hoisted_13 = {
  key: 3,
  style: { "margin-top": "4px", "border-top": "1px solid rgba(255, 255, 255, 0.06)", "padding-top": "4px" }
};
const _hoisted_14 = { style: { "opacity": "0.7" } };
const _hoisted_15 = { style: { "margin-left": "4px" } };
const _hoisted_16 = { style: { "opacity": "0.3", "margin-left": "4px" } };
const _hoisted_17 = { style: { "display": "flex", "gap": "4px", "margin-top": "4px" } };
const _hoisted_18 = ["onKeyup"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FactionTasks",
  props: {
    myRole: {}
  },
  setup(__props) {
    const props = __props;
    const tasks = ref([]);
    const loading = ref(false);
    const error = ref("");
    const collapsedTasks = ref(/* @__PURE__ */ new Set());
    const commentText = ref("");
    const showForm = ref(false);
    const formTitle = ref("");
    const formDescription = ref("");
    const formDueDate = ref("");
    const isExecutive = computed(() => props.myRole === "executive");
    const canClaim = computed(() => props.myRole !== "member");
    async function loadData() {
      loading.value = true;
      error.value = "";
      try {
        const result = await fetchTasks();
        tasks.value = result.tasks;
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      } finally {
        loading.value = false;
      }
    }
    async function handleCreate() {
      if (!formTitle.value) {
        return;
      }
      try {
        await createTask(
          formTitle.value,
          formDescription.value || void 0,
          formDueDate.value || void 0
        );
        showForm.value = false;
        formTitle.value = "";
        formDescription.value = "";
        formDueDate.value = "";
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    async function handleClaim(taskId) {
      try {
        await claimTask(taskId);
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    async function handleStatusChange(taskId, status) {
      try {
        await updateTaskStatus(taskId, status);
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    async function handleComment(taskId) {
      if (!commentText.value) {
        return;
      }
      try {
        await addTaskComment(taskId, commentText.value);
        commentText.value = "";
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    function isExpanded(taskId) {
      return !collapsedTasks.value.has(taskId);
    }
    function toggleExpand(taskId) {
      const next = new Set(collapsedTasks.value);
      if (next.has(taskId)) {
        next.delete(taskId);
      } else {
        next.add(taskId);
        commentText.value = "";
      }
      collapsedTasks.value = next;
    }
    async function handleDelete(taskId) {
      try {
        await deleteTask(taskId);
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    function statusColor(status) {
      switch (status) {
        case "done":
          return "rgb(146, 196, 125)";
        case "review":
          return "rgb(79, 163, 217)";
        case "in_progress":
          return "rgb(217, 163, 79)";
        default:
          return "rgba(255, 255, 255, 0.5)";
      }
    }
    const nextStatuses = {
      open: ["in_progress"],
      in_progress: ["review", "done"],
      review: ["done", "in_progress"],
      done: ["open"]
    };
    function formatDate(iso) {
      const d = new Date(iso);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    }
    onMounted(loadData);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass(unref($style).membersToolbar)
        }, [
          createVNode(_sfc_main$1, {
            dark: "",
            onClick: loadData
          }, {
            default: withCtx(() => [..._cache[7] || (_cache[7] = [
              createTextVNode("刷新", -1)
            ])]),
            _: 1
          }),
          unref(isExecutive) ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            dark: "",
            onClick: _cache[0] || (_cache[0] = ($event) => showForm.value = !unref(showForm))
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(unref(showForm) ? "取消" : "创建任务"), 1)
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ], 2),
        unref(showForm) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref($style).loginContainer)
        }, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "标题", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(formTitle) ? formTitle.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "text"
            }, null, 2), [
              [vModelText, unref(formTitle)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "描述", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(formDescription) ? formDescription.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "text"
            }, null, 2), [
              [vModelText, unref(formDescription)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "截止日期（可选）", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(formDueDate) ? formDueDate.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "date"
            }, null, 2), [
              [vModelText, unref(formDueDate)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).buttonRow)
          }, [
            createVNode(_sfc_main$1, {
              primary: "",
              disabled: !unref(formTitle),
              onClick: handleCreate
            }, {
              default: withCtx(() => [..._cache[8] || (_cache[8] = [
                createTextVNode("创建", -1)
              ])]),
              _: 1
            }, 8, ["disabled"])
          ], 2)
        ], 2)) : createCommentVNode("", true),
        unref(error) ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(unref($style).errorMessage)
        }, toDisplayString(unref(error)), 3)) : createCommentVNode("", true),
        unref(loading) ? (openBlock(), createElementBlock("div", {
          key: 2,
          class: normalizeClass(unref($style).loadingMessage)
        }, "加载中...", 2)) : (openBlock(), createElementBlock(Fragment, { key: 3 }, [
          unref(tasks).length === 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(unref($style).emptyMessage)
          }, "暂无任务", 2)) : createCommentVNode("", true),
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(tasks), (task) => {
            return openBlock(), createElementBlock("div", {
              key: task.id,
              class: normalizeClass(unref($style).memberRow),
              style: { "flex-direction": "column", "align-items": "stretch", "cursor": "pointer" },
              onClick: ($event) => toggleExpand(task.id)
            }, [
              createBaseVNode("div", _hoisted_2, [
                createBaseVNode("div", {
                  class: normalizeClass(unref($style).memberInfo)
                }, [
                  createBaseVNode("span", _hoisted_3, toDisplayString(task.title), 1),
                  createBaseVNode("span", {
                    class: normalizeClass([unref($style).roleBadge]),
                    style: normalizeStyle({
                      color: statusColor(task.status),
                      backgroundColor: statusColor(task.status).replace("rgb", "rgba").replace(")", ", 0.15)")
                    })
                  }, toDisplayString(unref(TASK_STATUS_LABELS)[task.status]), 7)
                ], 2),
                createBaseVNode("div", _hoisted_4, [
                  task.dueDate ? (openBlock(), createElementBlock("span", _hoisted_5, "截止 " + toDisplayString(task.dueDate), 1)) : createCommentVNode("", true),
                  createBaseVNode("span", {
                    class: normalizeClass(unref($style).memberJoined)
                  }, toDisplayString(formatDate(task.createdAt)), 3),
                  unref(isExecutive) ? (openBlock(), createBlock(_sfc_main$1, {
                    key: 1,
                    danger: "",
                    onClick: withModifiers(($event) => handleDelete(task.id), ["stop"])
                  }, {
                    default: withCtx(() => [..._cache[9] || (_cache[9] = [
                      createTextVNode("删除", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])) : createCommentVNode("", true)
                ])
              ]),
              isExpanded(task.id) ? (openBlock(), createElementBlock("div", {
                key: 0,
                style: { "cursor": "default" },
                onClick: _cache[6] || (_cache[6] = withModifiers(() => {
                }, ["stop"]))
              }, [
                task.description ? (openBlock(), createElementBlock("div", _hoisted_6, toDisplayString(task.description), 1)) : createCommentVNode("", true),
                createBaseVNode("div", _hoisted_7, "发布人：" + toDisplayString(task.createdBy), 1),
                task.assignee ? (openBlock(), createElementBlock("div", _hoisted_8, [
                  _cache[10] || (_cache[10] = createBaseVNode("span", { style: { "opacity": "0.5" } }, "认领人：", -1)),
                  createBaseVNode("span", _hoisted_9, toDisplayString(task.assignee), 1)
                ])) : createCommentVNode("", true),
                task.status === "done" && task.assignee ? (openBlock(), createElementBlock("div", _hoisted_10, [
                  _cache[11] || (_cache[11] = createBaseVNode("span", { style: { "opacity": "0.5" } }, "完成人：", -1)),
                  createBaseVNode("span", _hoisted_11, toDisplayString(task.assignee), 1)
                ])) : createCommentVNode("", true),
                createBaseVNode("div", _hoisted_12, [
                  unref(canClaim) && task.status === "open" && !task.assignee ? (openBlock(), createBlock(_sfc_main$1, {
                    key: 0,
                    dark: "",
                    onClick: withModifiers(($event) => handleClaim(task.id), ["stop"])
                  }, {
                    default: withCtx(() => [..._cache[12] || (_cache[12] = [
                      createTextVNode(" 认领 ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])) : createCommentVNode("", true),
                  (openBlock(true), createElementBlock(Fragment, null, renderList(nextStatuses[task.status] ?? [], (s) => {
                    return openBlock(), createBlock(_sfc_main$1, {
                      key: s,
                      dark: "",
                      onClick: withModifiers(($event) => handleStatusChange(task.id, s), ["stop"])
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" → " + toDisplayString(unref(TASK_STATUS_LABELS)[s]), 1)
                      ]),
                      _: 2
                    }, 1032, ["onClick"]);
                  }), 128))
                ]),
                task.comments.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_13, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(task.comments, (comment) => {
                    return openBlock(), createElementBlock("div", {
                      key: comment.id,
                      style: { "font-size": "11px", "margin-bottom": "2px" }
                    }, [
                      createBaseVNode("span", _hoisted_14, toDisplayString(comment.author) + ":", 1),
                      createBaseVNode("span", _hoisted_15, toDisplayString(comment.content), 1),
                      createBaseVNode("span", _hoisted_16, toDisplayString(formatDate(comment.createdAt)), 1)
                    ]);
                  }), 128))
                ])) : createCommentVNode("", true),
                createBaseVNode("div", _hoisted_17, [
                  withDirectives(createBaseVNode("input", {
                    "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(commentText) ? commentText.value = $event : null),
                    class: normalizeClass(unref($style).fieldInput),
                    type: "text",
                    placeholder: "添加备注...",
                    style: { "flex": "1", "font-size": "11px" },
                    onClick: _cache[5] || (_cache[5] = withModifiers(() => {
                    }, ["stop"])),
                    onKeyup: withKeys(($event) => handleComment(task.id), ["enter"])
                  }, null, 42, _hoisted_18), [
                    [vModelText, unref(commentText)]
                  ]),
                  createVNode(_sfc_main$1, {
                    dark: "",
                    disabled: !unref(commentText),
                    onClick: withModifiers(($event) => handleComment(task.id), ["stop"])
                  }, {
                    default: withCtx(() => [..._cache[13] || (_cache[13] = [
                      createTextVNode("发送", -1)
                    ])]),
                    _: 2
                  }, 1032, ["disabled", "onClick"])
                ])
              ])) : createCommentVNode("", true)
            ], 10, _hoisted_1);
          }), 128))
        ], 64))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
