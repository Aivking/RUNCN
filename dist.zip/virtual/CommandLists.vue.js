import { showTileOverlay, showConfirmationOverlay } from "./tile-overlay.js";
import _sfc_main$3 from "./CreateCommandListOverlay.vue.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import _sfc_main$2 from "./ActionBar.vue.js";
import { showBuffer } from "./buffers.js";
import { userData } from "./user-data.js";
import { vDraggable as so } from "./vue-draggable-plus.js";
import { grip } from "./index17.js";
import GripCell from "./GripCell.vue.js";
import GripHeaderCell from "./GripHeaderCell.vue.js";
import PrunLink from "./PrunLink.vue.js";
import { createId } from "./create-id.js";
import { defineComponent, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, withDirectives, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
import { toDisplayString } from "./shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CommandLists",
  setup(__props) {
    function createNew(ev) {
      showTileOverlay(ev, _sfc_main$3, {
        onCreate: (name) => {
          const id = createId();
          userData.commandLists.push({
            id,
            name,
            commands: []
          });
          return showBuffer(`XIT CMDL ${id.substring(0, 8)}`);
        }
      });
    }
    function confirmDelete(ev, list) {
      showConfirmationOverlay(
        ev,
        () => userData.commandLists = userData.commandLists.filter((x) => x !== list),
        {
          message: `确定要删除列表 "${list.name}" 吗？`
        }
      );
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: createNew
            }, {
              default: withCtx(() => [..._cache[0] || (_cache[0] = [
                createTextVNode("新建", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[1] || (_cache[1] = createBaseVNode("th", null, "名称", -1)),
              _cache[2] || (_cache[2] = createBaseVNode("th", null, "长度", -1)),
              _cache[3] || (_cache[3] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          withDirectives((openBlock(), createElementBlock("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(userData).commandLists, (list) => {
              return openBlock(), createElementBlock("tr", {
                key: list.id
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, [
                  createVNode(PrunLink, {
                    inline: "",
                    command: `XIT CMDL ${list.id.substring(0, 8)}`
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(list.name), 1)
                    ]),
                    _: 2
                  }, 1032, ["command"])
                ]),
                createBaseVNode("td", null, [
                  createBaseVNode("span", null, toDisplayString(list.commands.length) + " 个命令 ", 1)
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    danger: "",
                    onClick: ($event) => confirmDelete($event, list)
                  }, {
                    default: withCtx(() => [..._cache[4] || (_cache[4] = [
                      createTextVNode("删除", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [unref(userData).commandLists, unref(grip).draggable]]
          ])
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
