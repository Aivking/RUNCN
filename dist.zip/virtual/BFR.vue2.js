import { useCssModule } from "./runtime-dom.esm-bundler.js";
import { $, _$ } from "./select-dom.js";
import { C } from "./prun-css.js";
import _sfc_main$3 from "./ActionBar.vue.js";
import _sfc_main$2 from "./PrunButton.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import { userData } from "./user-data.js";
import removeArrayElement from "./remove-array-element.js";
import { vDraggable as so } from "./vue-draggable-plus.js";
import _sfc_main$4 from "./TextInput.vue.js";
import { grip } from "./index17.js";
import GripCell from "./GripCell.vue.js";
import GripHeaderCell from "./GripHeaderCell.vue.js";
import _sfc_main$1 from "./Tooltip.vue.js";
import _sfc_main$5 from "./NumberInput.vue.js";
import { objectId } from "./object-id.js";
import InlineFlex from "./InlineFlex.vue.js";
import { defineComponent, useTemplateRef, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createBlock, Fragment, createElementVNode as createBaseVNode, withDirectives, renderList, createCommentVNode, Teleport } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString, normalizeStyle } from "./shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "BFR",
  setup(__props) {
    const $style = useCssModule();
    const picking = ref(false);
    const overlay = useTemplateRef("overlay");
    const pickedBuffer = ref(null);
    const overlayCursor = computed(() => pickedBuffer.value ? "pointer" : "default");
    function onOverlayMouseMove(e) {
      if (!picking.value) {
        return;
      }
      const lastPickedBuffer = pickedBuffer.value;
      pickedBuffer.value = getBufferUnderCursor(e);
      lastPickedBuffer?.classList.remove($style.highlight);
      pickedBuffer.value?.classList.add($style.highlight);
    }
    async function onOverlayMouseClick(e) {
      const buffer = getBufferUnderCursor(e);
      pickedBuffer.value?.classList.remove($style.highlight);
      pickedBuffer.value = null;
      picking.value = false;
      if (!buffer) {
        return;
      }
      const cmd = await $(buffer, C.TileFrame.cmd);
      if (!cmd.textContent) {
        return;
      }
      const body = await $(buffer, C.Window.body);
      const width = parseInt(body.style.width.replace("px", ""), 10);
      const height = parseInt(body.style.height.replace("px", ""), 10);
      userData.settings.buffers.unshift([cmd.textContent, width, height]);
    }
    function getBufferUnderCursor(e) {
      const element = getElementUnderCursor(e);
      if (!element) {
        return void 0;
      }
      const window = element.closest(`.${C.Window.window}`);
      if (!window) {
        return void 0;
      }
      const cmd = _$(window, C.TileFrame.cmd);
      if (!cmd) {
        return void 0;
      }
      return window;
    }
    function getElementUnderCursor(e) {
      overlay.value.style.pointerEvents = "none";
      const element = document.elementFromPoint(e.clientX, e.clientY);
      overlay.value.style.pointerEvents = "all";
      return element;
    }
    function addNewRule() {
      userData.settings.buffers.unshift(["", 450, 300]);
    }
    function deleteRule(rule) {
      removeArrayElement(userData.settings.buffers, rule);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            _cache[1] || (_cache[1] = createTextVNode(" 覆盖默认缓冲区大小 ", -1)),
            createVNode(_sfc_main$1, {
              position: "bottom",
              class: normalizeClass(unref($style).tooltip),
              tooltip: "将使用第一个匹配的规则。如果没有规则匹配，将使用默认缓冲区大小。\n        你可以通过拖拽来重新组织规则顺序。"
            }, null, 8, ["class"])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$3, null, {
          default: withCtx(() => [
            unref(picking) ? (openBlock(), createBlock(_sfc_main$2, {
              key: 0,
              neutral: ""
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(pickedBuffer) ? "点击选择此缓冲区" : "点击任意位置取消"), 1)
              ]),
              _: 1
            })) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
              createVNode(_sfc_main$2, {
                primary: "",
                onClick: _cache[0] || (_cache[0] = ($event) => picking.value = true)
              }, {
                default: withCtx(() => [..._cache[2] || (_cache[2] = [
                  createTextVNode("选择缓冲区", -1)
                ])]),
                _: 1
              }),
              createVNode(_sfc_main$2, {
                primary: "",
                onClick: addNewRule
              }, {
                default: withCtx(() => [..._cache[3] || (_cache[3] = [
                  createTextVNode("添加新规则", -1)
                ])]),
                _: 1
              })
            ], 64))
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              createBaseVNode("th", null, [
                createVNode(InlineFlex, null, {
                  default: withCtx(() => [
                    _cache[4] || (_cache[4] = createTextVNode(" 命令 ", -1)),
                    createVNode(_sfc_main$1, {
                      position: "right",
                      tooltip: "可以是完整命令、部分命令或正则表达式。不区分大小写。"
                    })
                  ]),
                  _: 1
                })
              ]),
              _cache[5] || (_cache[5] = createBaseVNode("th", null, "宽度", -1)),
              _cache[6] || (_cache[6] = createBaseVNode("th", null, "高度", -1)),
              _cache[7] || (_cache[7] = createBaseVNode("th", null, null, -1))
            ])
          ]),
          unref(userData).settings.buffers.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_1, [..._cache[8] || (_cache[8] = [
            createBaseVNode("tr", null, [
              createBaseVNode("td", { colspan: "5" }, "还没有内容。")
            ], -1)
          ])])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_2, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(userData).settings.buffers, (rule) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(rule)
              }, [
                createVNode(GripCell),
                createBaseVNode("td", {
                  class: normalizeClass(unref($style).commandCell)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).forms.input, unref($style).inline])
                  }, [
                    createVNode(_sfc_main$4, {
                      modelValue: rule[0],
                      "onUpdate:modelValue": ($event) => rule[0] = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ], 2),
                createBaseVNode("td", {
                  class: normalizeClass(unref($style).sizeCell)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).forms.input, unref($style).inline])
                  }, [
                    createVNode(_sfc_main$5, {
                      modelValue: rule[1],
                      "onUpdate:modelValue": ($event) => rule[1] = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ], 2),
                createBaseVNode("td", {
                  class: normalizeClass(unref($style).sizeCell)
                }, [
                  createBaseVNode("div", {
                    class: normalizeClass([("C" in _ctx ? _ctx.C : unref(C)).forms.input, unref($style).inline])
                  }, [
                    createVNode(_sfc_main$5, {
                      modelValue: rule[2],
                      "onUpdate:modelValue": ($event) => rule[2] = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ], 2)
                ], 2),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$2, {
                    danger: "",
                    onClick: ($event) => deleteRule(rule)
                  }, {
                    default: withCtx(() => [..._cache[9] || (_cache[9] = [
                      createTextVNode("删除", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [unref(userData).settings.buffers, unref(grip).draggable]]
          ])
        ]),
        (openBlock(), createBlock(Teleport, { to: "body" }, [
          unref(picking) ? (openBlock(), createElementBlock("div", {
            key: 0,
            ref_key: "overlay",
            ref: overlay,
            class: normalizeClass(unref($style).overlay),
            style: normalizeStyle({ cursor: unref(overlayCursor) }),
            onClick: onOverlayMouseClick,
            onMousemove: onOverlayMouseMove
          }, null, 38)) : createCommentVNode("", true)
        ]))
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
