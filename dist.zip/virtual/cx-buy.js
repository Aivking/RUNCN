import { act } from "./act-registry.js";
import _sfc_main from "./Edit.vue.js";
import { CXPO_BUY } from "./CXPO_BUY.js";
import { fixed0, fixed02 } from "./format.js";
import { fillAmount } from "./utils2.js";
act.addAction({
  type: "CX Buy",
  description: (action) => {
    if (!action.group || !action.exchange) {
      return "--";
    }
    return "从 " + action.exchange + " 购买组 " + action.group;
  },
  editComponent: _sfc_main,
  generateSteps: async (ctx) => {
    const { data, state, log, fail, getMaterialGroup, emitStep } = ctx;
    const assert = ctx.assert;
    const allowUnfilled = data.allowUnfilled ?? false;
    const buyPartial = data.buyPartial ?? false;
    const materials = await getMaterialGroup(data.group);
    assert(materials, "无效的材料组");
    const exchange = data.exchange;
    assert(exchange, "缺少交易所");
    if ((data.useCXInv ?? true) && data.exchange) {
      for (const mat of Object.keys(materials)) {
        for (const CXMat of Object.keys(state.WAR[data.exchange])) {
          if (CXMat === mat) {
            const used = Math.min(materials[mat], state.WAR[data.exchange][CXMat]);
            materials[mat] -= used;
            state.WAR[data.exchange][CXMat] -= used;
            if (state.WAR[data.exchange][mat] <= 0) {
              delete state.WAR[data.exchange][CXMat];
            }
          }
        }
        if (materials[mat] <= 0) {
          delete materials[mat];
        }
      }
    }
    for (const ticker of Object.keys(materials)) {
      const amount = materials[ticker];
      const priceLimit = data.priceLimits?.[ticker] ?? Infinity;
      if (isNaN(priceLimit)) {
        log.error(ticker + " 的价格限制不是数字");
        continue;
      }
      const cxTicker = `${ticker}.${data.exchange}`;
      const filled = fillAmount(cxTicker, amount, priceLimit);
      let bidAmount = amount;
      if (filled && filled.amount < amount && !allowUnfilled) {
        if (ctx.globalOptions?.skipMissingMaterials) {
          log.warning(`${exchange} 上没有足够的材料购买 ${fixed0(amount)} ${ticker}，执行时将跳过`);
          bidAmount = amount;
        } else if (!buyPartial) {
          let message = `${exchange} 上没有足够的材料购买 ${fixed0(amount)} ${ticker}`;
          if (isFinite(priceLimit)) {
            message += ` with price limit ${fixed02(priceLimit)}/u`;
          }
          fail(message);
          return;
        } else {
          const leftover = amount - filled.amount;
          let message = `${fixed0(leftover)} ${ticker} 将不会在 ${exchange} 上购买 （${fixed0(filled.amount)}/${fixed0(amount)} 可用`;
          if (isFinite(priceLimit)) {
            message += ` with price limit ${fixed02(priceLimit)}/u`;
          }
          message += ")";
          log.warning(message);
          if (filled.amount === 0) {
            continue;
          }
          bidAmount = filled.amount;
        }
      }
      emitStep(
        CXPO_BUY({
          exchange,
          ticker,
          amount: bidAmount,
          priceLimit,
          buyPartial,
          allowUnfilled,
          skipMissing: ctx.globalOptions?.skipMissingMaterials
        })
      );
    }
  }
});
