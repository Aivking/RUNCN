import _sfc_main from "./FactionLogistics.vue.js";
export {
  _sfc_main as default
};
