import _sfc_main$2 from "./ActionBar.vue.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import { showBuffer } from "./buffers.js";
import { showTileOverlay, showConfirmationOverlay } from "./tile-overlay.js";
import _sfc_main$3 from "./CreateActionPackage.vue.js";
import _sfc_main$4 from "./ImportActionPackage.vue.js";
import Quickstart from "./Quickstart.vue.js";
import { userData } from "./user-data.js";
import PrunLink from "./PrunLink.vue.js";
import removeArrayElement from "./remove-array-element.js";
import { objectId } from "./object-id.js";
import { stripDeletedActions } from "./utils7.js";
import { vDraggable as so } from "./vue-draggable-plus.js";
import { grip } from "./index17.js";
import GripCell from "./GripCell.vue.js";
import GripHeaderCell from "./GripHeaderCell.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, createCommentVNode, createBlock, withDirectives, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
import { toDisplayString } from "./shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 1 };
const _hoisted_3 = { key: 0 };
const _hoisted_4 = { key: 1 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ActionPackageList",
  setup(__props) {
    const actionPackages = computed(() => userData.actionPackages);
    const showQuickstart = computed(() => userData.actionPackages.length === 0);
    function onQuickstartClick(ev) {
      showTileOverlay(ev, Quickstart);
    }
    function onCreateClick(ev) {
      showTileOverlay(ev, _sfc_main$3, {
        onCreate: (name) => {
          userData.actionPackages.push({
            global: { name },
            groups: [],
            actions: []
          });
          showBuffer("XIT ACT_EDIT_" + name.split(" ").join("_"));
        }
      });
    }
    function onImportClick(ev) {
      showTileOverlay(ev, _sfc_main$4, {
        onImport: (json) => {
          stripDeletedActions(json);
          const existing = userData.actionPackages.find((x) => x.global.name === json.global.name);
          if (existing) {
            const index = userData.actionPackages.indexOf(existing);
            userData.actionPackages[index] = json;
          } else {
            userData.actionPackages.push(json);
          }
        }
      });
    }
    function onDeleteClick(ev, pkg) {
      showConfirmationOverlay(ev, () => removeArrayElement(userData.actionPackages, pkg), {
        message: `确定要删除操作包 "${pkg.global.name}" 吗？`,
        confirmLabel: "删除"
      });
    }
    function onDeleteAllClick(ev) {
      showConfirmationOverlay(ev, () => userData.actionPackages.splice(0), {
        message: "确定要删除全部操作包吗？",
        confirmLabel: "删除全部"
      });
    }
    function friendlyName(pkg) {
      return (pkg.global.name ?? "").split("_").join(" ");
    }
    function paramName(pkg) {
      return (pkg.global.name ?? "").split(" ").join("_");
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$2, null, {
          default: withCtx(() => [
            unref(showQuickstart) ? (openBlock(), createElementBlock("div", _hoisted_1, [..._cache[0] || (_cache[0] = [
              createTextVNode("点击这里开始", -1),
              createBaseVNode("br", null, null, -1),
              createTextVNode("快速入门！", -1)
            ])])) : createCommentVNode("", true),
            unref(showQuickstart) ? (openBlock(), createElementBlock("div", _hoisted_2, "→")) : createCommentVNode("", true),
            unref(showQuickstart) ? (openBlock(), createBlock(_sfc_main$1, {
              key: 2,
              primary: "",
              onClick: onQuickstartClick
            }, {
              default: withCtx(() => [..._cache[1] || (_cache[1] = [
                createTextVNode("快速开始", -1)
              ])]),
              _: 1
            })) : createCommentVNode("", true),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: onCreateClick
            }, {
              default: withCtx(() => [..._cache[2] || (_cache[2] = [
                createTextVNode("新建", -1)
              ])]),
              _: 1
            }),
            createVNode(_sfc_main$1, {
              primary: "",
              onClick: onImportClick
            }, {
              default: withCtx(() => [..._cache[3] || (_cache[3] = [
                createTextVNode("导入", -1)
              ])]),
              _: 1
            }),
            unref(actionPackages).length > 0 ? (openBlock(), createBlock(_sfc_main$1, {
              key: 3,
              dark: "",
              onClick: onDeleteAllClick
            }, {
              default: withCtx(() => [..._cache[4] || (_cache[4] = [
                createTextVNode("删除全部", -1)
              ])]),
              _: 1
            })) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createVNode(GripHeaderCell),
              _cache[5] || (_cache[5] = createBaseVNode("th", null, "名称", -1)),
              _cache[6] || (_cache[6] = createBaseVNode("th", null, "执行", -1)),
              _cache[7] || (_cache[7] = createBaseVNode("th", null, "编辑", -1)),
              _cache[8] || (_cache[8] = createBaseVNode("th", null, "删除", -1))
            ])
          ]),
          unref(userData).actionPackages.length === 0 ? (openBlock(), createElementBlock("tbody", _hoisted_3, [..._cache[9] || (_cache[9] = [
            createBaseVNode("tr", null, [
              createBaseVNode("td", { colspan: "5" }, "没有操作包。")
            ], -1)
          ])])) : withDirectives((openBlock(), createElementBlock("tbody", _hoisted_4, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(actionPackages), (pkg) => {
              return openBlock(), createElementBlock("tr", {
                key: unref(objectId)(pkg)
              }, [
                createVNode(GripCell),
                createBaseVNode("td", null, [
                  createVNode(PrunLink, {
                    inline: "",
                    command: `XIT ACT_${paramName(pkg)}`
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(friendlyName(pkg)), 1)
                    ]),
                    _: 2
                  }, 1032, ["command"])
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    primary: "",
                    onClick: ($event) => unref(showBuffer)(`XIT ACT_${paramName(pkg)}`)
                  }, {
                    default: withCtx(() => [..._cache[10] || (_cache[10] = [
                      createTextVNode(" 执行 ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    primary: "",
                    onClick: ($event) => unref(showBuffer)(`XIT ACT_EDIT_${paramName(pkg)}`)
                  }, {
                    default: withCtx(() => [..._cache[11] || (_cache[11] = [
                      createTextVNode(" 编辑 ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ]),
                createBaseVNode("td", null, [
                  createVNode(_sfc_main$1, {
                    dark: "",
                    inline: "",
                    onClick: ($event) => onDeleteClick($event, pkg)
                  }, {
                    default: withCtx(() => [..._cache[12] || (_cache[12] = [
                      createTextVNode("删除", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]);
            }), 128))
          ])), [
            [unref(so), [unref(actionPackages), unref(grip).draggable]]
          ])
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
