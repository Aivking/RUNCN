import { useCssModule } from "./runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./ContractLink.vue.js";
import PartnerLink from "./PartnerLink.vue.js";
import ProgressBarWithText from "./ProgressBarWithText.vue.js";
import { formatAmount, calculateProgress, getStatusText, getStatusClass } from "./utils4.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode } from "./runtime-core.esm-bundler.js";
import { toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "HaulRow",
  props: {
    contract: {},
    type: {}
  },
  setup(__props) {
    const $style = useCssModule();
    function formatAddress(address) {
      if (!address?.lines) return "-";
      const parts = [];
      for (const line of address.lines) {
        if (line.entity) {
          parts.push(line.entity.name);
        }
      }
      return parts.join(" / ") || "-";
    }
    const origin = computed(() => {
      const pickup = __props.contract.conditions.find((c) => c.type === "PICKUP_SHIPMENT");
      if (pickup?.address) return formatAddress(pickup.address);
      const provision = __props.contract.conditions.find((c) => c.type === "PROVISION_SHIPMENT");
      if (provision?.address) return formatAddress(provision.address);
      return "-";
    });
    const destination = computed(() => {
      const delivery = __props.contract.conditions.find((c) => c.type === "DELIVERY_SHIPMENT");
      if (delivery?.destination) return formatAddress(delivery.destination);
      if (delivery?.address) return formatAddress(delivery.address);
      return "-";
    });
    const cargo = computed(() => {
      const types = ["PROVISION_SHIPMENT", "PICKUP_SHIPMENT", "DELIVERY_SHIPMENT"];
      for (const type of types) {
        const conds = __props.contract.conditions.filter(
          (c) => c.type === type && c.weight != null && c.volume != null
        );
        if (conds.length > 0) {
          let w = 0;
          let v = 0;
          for (const c of conds) {
            w += c.weight;
            v += c.volume;
          }
          return `${w.toFixed(2)}t / ${v.toFixed(2)}m³`;
        }
      }
      return "-";
    });
    const payment = computed(() => {
      const pay = __props.contract.conditions.find((c) => c.type === "PAYMENT");
      if (!pay?.amount) return "-";
      return formatAmount(pay.amount.amount, pay.amount.currency);
    });
    const progress = computed(() => calculateProgress(__props.contract));
    const statusText = computed(() => getStatusText(__props.contract.status));
    const statusClass = computed(() => $style[getStatusClass(__props.contract.status)]);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("tr", null, [
        createBaseVNode("td", null, [
          createVNode(_sfc_main$1, { contract: _ctx.contract }, null, 8, ["contract"])
        ]),
        createBaseVNode("td", null, [
          createVNode(PartnerLink, { contract: _ctx.contract }, null, 8, ["contract"])
        ]),
        createBaseVNode("td", null, toDisplayString(origin.value), 1),
        createBaseVNode("td", null, toDisplayString(destination.value), 1),
        createBaseVNode("td", null, toDisplayString(cargo.value), 1),
        createBaseVNode("td", null, toDisplayString(payment.value), 1),
        createBaseVNode("td", null, [
          createVNode(ProgressBarWithText, {
            current: progress.value.fulfilled,
            total: progress.value.total,
            "show-text": true
          }, null, 8, ["current", "total"])
        ]),
        createBaseVNode("td", {
          class: normalizeClass(statusClass.value)
        }, toDisplayString(statusText.value), 3)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
