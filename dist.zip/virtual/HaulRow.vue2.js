import { useCssModule } from "./runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./ContractLink.vue.js";
import PartnerLink from "./PartnerLink.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode } from "./runtime-core.esm-bundler.js";
import { toDisplayString, normalizeClass, normalizeStyle } from "./shared.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "HaulRow",
  props: {
    contract: {},
    type: {}
  },
  setup(__props) {
    const $style = useCssModule();
    function formatAddress(address) {
      if (!address?.lines) return "-";
      const parts = [];
      for (const line of address.lines) {
        if (line.entity) {
          parts.push(line.entity.name);
        }
      }
      return parts.join(" / ") || "-";
    }
    const origin = computed(() => {
      const pickup = __props.contract.conditions.find((c) => c.type === "PICKUP_SHIPMENT");
      if (pickup?.address) return formatAddress(pickup.address);
      const provision = __props.contract.conditions.find((c) => c.type === "PROVISION_SHIPMENT");
      if (provision?.address) return formatAddress(provision.address);
      return "-";
    });
    const destination = computed(() => {
      const delivery = __props.contract.conditions.find((c) => c.type === "DELIVERY_SHIPMENT");
      if (delivery?.destination) return formatAddress(delivery.destination);
      if (delivery?.address) return formatAddress(delivery.address);
      return "-";
    });
    const cargo = computed(() => {
      let totalWeight = 0;
      let totalVolume = 0;
      for (const cond of __props.contract.conditions) {
        if ((cond.type === "DELIVERY_SHIPMENT" || cond.type === "PROVISION_SHIPMENT") && cond.weight != null) {
          totalWeight += cond.weight;
          totalVolume += cond.volume;
        }
      }
      if (totalWeight === 0 && totalVolume === 0) return "-";
      const w = (totalWeight / 1e3).toFixed(1);
      const v = (totalVolume / 1e3).toFixed(1);
      return `${w}t / ${v}m³`;
    });
    const payment = computed(() => {
      const pay = __props.contract.conditions.find((c) => c.type === "PAYMENT");
      if (!pay?.amount) return "-";
      return `${pay.amount.amount.toLocaleString()} ${pay.amount.currency}`;
    });
    const fulfilledCount = computed(
      () => __props.contract.conditions.filter((c) => c.status === "FULFILLED").length
    );
    const totalCount = computed(() => __props.contract.conditions.length);
    const progress = computed(() => {
      if (totalCount.value === 0) return 0;
      return Math.round(fulfilledCount.value / totalCount.value * 100);
    });
    const statusText = computed(() => {
      switch (__props.contract.status) {
        case "OPEN":
          return "待接受";
        case "CLOSED":
          return "进行中";
        case "FULFILLED":
          return "已完成";
        case "PARTIALLY_FULFILLED":
          return "部分完成";
        case "BREACHED":
          return "已违约";
        case "TERMINATED":
          return "已终止";
        case "CANCELLED":
          return "已取消";
        case "REJECTED":
          return "已拒绝";
        case "DEADLINE_EXCEEDED":
          return "已逾期";
        default:
          return __props.contract.status;
      }
    });
    const statusClass = computed(() => {
      switch (__props.contract.status) {
        case "FULFILLED":
          return $style.fulfilled;
        case "CLOSED":
        case "PARTIALLY_FULFILLED":
          return $style.active;
        case "BREACHED":
        case "TERMINATED":
        case "DEADLINE_EXCEEDED":
          return $style.failed;
        case "OPEN":
          return $style.pending;
        default:
          return "";
      }
    });
    const progressClass = computed(() => {
      if (progress.value >= 100) return $style.fulfilled;
      if (progress.value > 50) return $style.active;
      return $style.pending;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("tr", null, [
        createBaseVNode("td", null, [
          createVNode(_sfc_main$1, { contract: _ctx.contract }, null, 8, ["contract"])
        ]),
        createBaseVNode("td", null, [
          createVNode(PartnerLink, { contract: _ctx.contract }, null, 8, ["contract"])
        ]),
        createBaseVNode("td", null, toDisplayString(unref(origin)), 1),
        createBaseVNode("td", null, toDisplayString(unref(destination)), 1),
        createBaseVNode("td", null, toDisplayString(unref(cargo)), 1),
        createBaseVNode("td", null, toDisplayString(unref(payment)), 1),
        createBaseVNode("td", null, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).progressContainer)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).progressBar)
            }, [
              createBaseVNode("div", {
                class: normalizeClass([unref($style).progressFill, unref(progressClass)]),
                style: normalizeStyle({ width: unref(progress) + "%" })
              }, null, 6)
            ], 2),
            createBaseVNode("span", {
              class: normalizeClass(unref($style).progressText)
            }, toDisplayString(unref(fulfilledCount)) + "/" + toDisplayString(unref(totalCount)), 3)
          ], 2)
        ]),
        createBaseVNode("td", {
          class: normalizeClass(unref(statusClass))
        }, toDisplayString(unref(statusText)), 3)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
