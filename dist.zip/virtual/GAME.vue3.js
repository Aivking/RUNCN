const tooltip = "rp-GAME__tooltip___74e4fdf";
const sidebarInputPair = "rp-GAME__sidebarInputPair___76840bf";
const sidebarInput = "rp-GAME__sidebarInput___41eca58";
const grip = "rp-GAME__grip___8355415";
const sidebarRow = "rp-GAME__sidebarRow___fb2552f";
const style0 = {
  tooltip,
  sidebarInputPair,
  sidebarInput,
  grip,
  sidebarRow
};
export {
  style0 as default,
  grip,
  sidebarInput,
  sidebarInputPair,
  sidebarRow,
  tooltip
};
