const notice = "rp-GenerateRepairActDialog__notice___f8af0b6";
const style0 = {
  notice
};
export {
  style0 as default,
  notice
};
