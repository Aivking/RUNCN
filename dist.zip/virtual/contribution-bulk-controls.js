import { subscribe } from "./subscribe-async-generator.js";
import { _$$, $$, $ } from "./select-dom.js";
import { C } from "./prun-css.js";
import { createFragmentApp } from "./vue-fragment-app.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import { clickElement } from "./util.js";
import { refAnimationFrame } from "./reactive-dom.js";
import _sfc_main from "./PrunButton.vue.js";
import { createVNode, createTextVNode } from "./runtime-core.esm-bundler.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.Contribution.contribute), (contribute) => {
    const table = contribute.previousElementSibling;
    if (!table) {
      return;
    }
    const sliders = _$$(table, "rc-slider");
    if (sliders.length === 0) {
      return;
    }
    const maxSliders = async () => {
      for (const slider of sliders) {
        if (slider.classList.contains("rc-slider-disabled")) {
          continue;
        }
        const mark = await $(slider, "rc-slider-mark");
        await clickElement(mark.lastElementChild);
      }
    };
    const minSliders = async () => {
      for (const slider of sliders) {
        if (slider.classList.contains("rc-slider-disabled")) {
          continue;
        }
        const mark = await $(slider, "rc-slider-mark");
        await clickElement(mark.firstElementChild);
      }
    };
    const allSliders = table.getElementsByClassName("rc-slider");
    const disabledSliders = table.getElementsByClassName("rc-slider-disabled");
    const disabled = refAnimationFrame(table, () => allSliders.length > 0 && allSliders.length === disabledSliders.length);
    createFragmentApp(() => createVNode(_sfc_main, {
      "primary": true,
      "disabled": disabled.value,
      "onClick": maxSliders
    }, {
      default: () => [createTextVNode("ALL")]
    })).prependTo(contribute);
    createFragmentApp(() => createVNode(_sfc_main, {
      "primary": true,
      "disabled": disabled.value,
      "onClick": minSliders
    }, {
      default: () => [createTextVNode("NONE")]
    })).prependTo(contribute);
  });
}
function init() {
  tiles.observe(["COGCU", "POPID"], onTileReady);
}
features.add(import.meta.url, init, "Adds bulk controls (NONE, ALL) to contribution menus in CoGC and population upkeep tiles.");
