import { alertsStore } from "./alerts.js";
import { userDataStore } from "./user-data2.js";
import { computed } from "./runtime-core.esm-bundler.js";
const reachableContextIds = computed(() => new Set(userDataStore.contexts.map((x) => x.id)));
const reachableAlerts = computed(
  () => alertsStore.all.value?.filter((x) => reachableContextIds.value.has(x.contextId))
);
export {
  reachableAlerts
};
