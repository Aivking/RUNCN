import { $$, _$$ } from "./select-dom.js";
import { C } from "./prun-css.js";
import { subscribe } from "./subscribe-async-generator.js";
import features from "./feature-registry.js";
import $style from "./close-all-buffers.module.css.js";
import { sleep } from "./sleep.js";
async function closeAllBuffers() {
  const minimizedIndicators = _$$(document.body, C.Dock.indicatorMinimized);
  for (const indicator of minimizedIndicators) {
    const dockItem = indicator.closest(`.${C.Dock.buffer}`);
    if (dockItem) {
      dockItem.click();
      await sleep(50);
    }
  }
  const windows = _$$(document.body, C.Window.window);
  for (const win of windows) {
    const closeBtn = _$$(win, C.Window.button).find((b) => b.textContent === "x");
    if (closeBtn) {
      closeBtn.click();
      await sleep(50);
    }
  }
}
async function onFooterReady(foot) {
  if (foot.querySelector(`.${$style.closeAllBtn}`)) {
    return;
  }
  const btn = document.createElement("div");
  btn.className = $style.closeAllBtn;
  btn.title = "关闭所有浮动窗口";
  btn.textContent = "一键关闭";
  btn.addEventListener("click", () => {
    void closeAllBuffers();
  });
  foot.prepend(btn);
}
function init() {
  subscribe($$(document, C.Frame.foot), onFooterReady);
}
features.add(import.meta.url, init, "在底栏左侧添加”一键关闭”按钮，关闭所有浮动窗口。");
