import _sfc_main$6 from "./PrunButton.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import _sfc_main$2 from "./Tooltip.vue.js";
import _sfc_main$3 from "./TextInput.vue.js";
import _sfc_main$1 from "./Active.vue.js";
import _sfc_main$4 from "./NumberInput.vue.js";
import _sfc_main$7 from "./Commands.vue.js";
import { showConfirmationOverlay } from "./tile-overlay.js";
import { userData, initialUserData } from "./user-data.js";
import { exportUserData, downloadBackup, importUserData, saveUserData, restoreBackup, resetUserData } from "./user-data-serializer.js";
import SelectInput from "./SelectInput.vue.js";
import { objectId } from "./object-id.js";
import { getUserDataBackups, deleteUserDataBackup } from "./user-data-backup.js";
import { hhForXitSet, ddmmyyyy, hhmm } from "./format.js";
import dayjs from "./dayjs.min.js";
import { vDraggable as so } from "./vue-draggable-plus.js";
import { grip } from "./index14.js";
import _sfc_main$5 from "./GripChar.vue.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, createBlock, createCommentVNode, withDirectives, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { unref, isRef } from "./reactivity.esm-bundler.js";
import { normalizeClass } from "./shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GAME",
  setup(__props) {
    const isDefault24 = computed(() => {
      return hhForXitSet.value(dayjs.duration(12, "hours").asMilliseconds()) === "13";
    });
    const timeFormats = computed(() => {
      return [
        {
          label: "24h",
          value: "24H"
        },
        {
          label: "12h",
          value: "12H"
        }
      ];
    });
    const timeFormat = computed({
      get: () => {
        const format = userData.settings.time;
        if (format === "DEFAULT") {
          return isDefault24.value ? "24H" : "12H";
        }
        return format;
      },
      set: (value) => userData.settings.time = value
    });
    const exchangeChartTypes = [
      {
        label: "平滑",
        value: "SMOOTH"
      },
      {
        label: "对齐",
        value: "ALIGNED"
      },
      {
        label: "原始",
        value: "RAW"
      }
    ];
    const currencySettings = computed(() => userData.settings.currency);
    const currencyPresets = [
      {
        label: "默认",
        value: "DEFAULT"
      },
      {
        label: "₳",
        value: "AIC"
      },
      {
        label: "₡",
        value: "CIS"
      },
      {
        label: "ǂ",
        value: "ICA"
      },
      {
        label: "₦",
        value: "NCC"
      },
      {
        label: "自定义",
        value: "CUSTOM"
      }
    ];
    const currencyPosition = [
      {
        label: "后置",
        value: "AFTER"
      },
      {
        label: "前置",
        value: "BEFORE"
      }
    ];
    const currencySpacing = [
      {
        label: "有空格",
        value: "HAS_SPACE"
      },
      {
        label: "无空格",
        value: "NO_SPACE"
      }
    ];
    const backups = computed(() => getUserDataBackups());
    function addSidebarButton() {
      userData.settings.sidebar.push(["SET", "XIT SET"]);
    }
    function deleteSidebarButton(index) {
      userData.settings.sidebar.splice(index, 1);
    }
    function confirmResetSidebar(ev) {
      showConfirmationOverlay(ev, () => {
        userData.settings.sidebar = structuredClone(initialUserData.settings.sidebar);
      });
    }
    function importUserDataAndReload() {
      importUserData(async () => {
        await saveUserData();
        window.location.reload();
      });
    }
    async function restoreBackupAndReload(ev, backup) {
      showConfirmationOverlay(
        ev,
        async () => {
          restoreBackup(backup);
          await saveUserData();
          window.location.reload();
        },
        {
          message: "确定要恢复此备份吗？这将覆盖你当前的数据。"
        }
      );
    }
    function confirmDeleteBackup(ev, backup) {
      showConfirmationOverlay(ev, () => deleteUserDataBackup(backup));
    }
    function confirmResetAllData(ev) {
      showConfirmationOverlay(ev, async () => {
        resetUserData();
        await saveUserData();
        window.location.reload();
      });
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[9] || (_cache[9] = [
            createTextVNode("外观", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, { label: "时间格式" }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(timeFormat),
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(timeFormat) ? timeFormat.value = $event : null),
                options: unref(timeFormats)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "默认 CX 图表类型" }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(userData).settings.defaultChartType,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => unref(userData).settings.defaultChartType = $event),
                options: exchangeChartTypes
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            _cache[10] || (_cache[10] = createTextVNode(" 货币符号 ", -1)),
            createVNode(_sfc_main$2, {
              class: normalizeClass(_ctx.$style.tooltip),
              tooltip: "显示货币值时使用的货币符号。仅在 Refined PrUn 添加的 UI 中显示。"
            }, null, 8, ["class"])
          ]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, { label: "符号" }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(currencySettings).preset,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => unref(currencySettings).preset = $event),
                options: currencyPresets
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          unref(currencySettings).preset === "CUSTOM" ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            label: "自定义符号"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$3, {
                modelValue: unref(currencySettings).custom,
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => unref(currencySettings).custom = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })) : createCommentVNode("", true),
          unref(currencySettings).preset !== "DEFAULT" ? (openBlock(), createBlock(_sfc_main$1, {
            key: 1,
            label: "位置"
          }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(currencySettings).position,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => unref(currencySettings).position = $event),
                options: currencyPosition
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })) : createCommentVNode("", true),
          unref(currencySettings).preset !== "DEFAULT" ? (openBlock(), createBlock(_sfc_main$1, {
            key: 2,
            label: "间距",
            tooltip: "符号和数值之间的空格。"
          }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(currencySettings).spacing,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => unref(currencySettings).spacing = $event),
                options: currencySpacing
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[11] || (_cache[11] = [
            createTextVNode("燃烧设置", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, {
            label: "红色",
            tooltip: "燃烧计算中红色消耗品等级的阈值（天数）。"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                modelValue: unref(userData).settings.burn.red,
                "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => unref(userData).settings.burn.red = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "黄色",
            tooltip: "燃烧计算中黄色消耗品等级的阈值（天数）。"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                modelValue: unref(userData).settings.burn.yellow,
                "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => unref(userData).settings.burn.yellow = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "补给",
            tooltip: "XIT BURN 中'需要'列的目标补给天数。"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                modelValue: unref(userData).settings.burn.resupply,
                "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => unref(userData).settings.burn.resupply = $event)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            _cache[12] || (_cache[12] = createTextVNode(" 左侧边栏按钮 ", -1)),
            createVNode(_sfc_main$2, {
              class: normalizeClass(_ctx.$style.tooltip),
              tooltip: "在左侧边栏创建快捷键。第一个值是显示内容，第二个是命令。"
            }, null, 8, ["class"])
          ]),
          _: 1
        }),
        withDirectives((openBlock(), createElementBlock("form", null, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(userData).settings.sidebar, (button, i) => {
            return openBlock(), createBlock(_sfc_main$1, {
              key: unref(objectId)(button),
              label: `Button ${i + 1}`,
              class: normalizeClass(_ctx.$style.sidebarRow)
            }, {
              default: withCtx(() => [
                createBaseVNode("div", {
                  class: normalizeClass(_ctx.$style.sidebarInputPair)
                }, [
                  createVNode(_sfc_main$5, {
                    class: normalizeClass([_ctx.$style.grip, unref(grip).class])
                  }, null, 8, ["class"]),
                  createVNode(_sfc_main$3, {
                    modelValue: button[0],
                    "onUpdate:modelValue": ($event) => button[0] = $event,
                    class: normalizeClass(_ctx.$style.sidebarInput)
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                  createVNode(_sfc_main$3, {
                    modelValue: button[1],
                    "onUpdate:modelValue": ($event) => button[1] = $event,
                    class: normalizeClass(_ctx.$style.sidebarInput)
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                  createVNode(_sfc_main$6, {
                    danger: "",
                    onClick: ($event) => deleteSidebarButton(i)
                  }, {
                    default: withCtx(() => [..._cache[13] || (_cache[13] = [
                      createTextVNode("x", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ], 2)
              ]),
              _: 2
            }, 1032, ["label", "class"]);
          }), 128))
        ])), [
          [unref(so), [unref(userData).settings.sidebar, unref(grip).draggable]]
        ]),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$7, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$6, {
                primary: "",
                onClick: confirmResetSidebar
              }, {
                default: withCtx(() => [..._cache[14] || (_cache[14] = [
                  createTextVNode("重置", -1)
                ])]),
                _: 1
              }),
              createVNode(_sfc_main$6, {
                primary: "",
                onClick: addSidebarButton
              }, {
                default: withCtx(() => [..._cache[15] || (_cache[15] = [
                  createTextVNode("添加", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[16] || (_cache[16] = [
            createTextVNode("导入/导出", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$7, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$6, {
                primary: "",
                onClick: importUserDataAndReload
              }, {
                default: withCtx(() => [..._cache[17] || (_cache[17] = [
                  createTextVNode("导入用户数据", -1)
                ])]),
                _: 1
              }),
              createVNode(_sfc_main$6, {
                primary: "",
                onClick: unref(exportUserData)
              }, {
                default: withCtx(() => [..._cache[18] || (_cache[18] = [
                  createTextVNode("导出用户数据", -1)
                ])]),
                _: 1
              }, 8, ["onClick"])
            ]),
            _: 1
          })
        ]),
        unref(backups).length > 0 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
          createVNode(SectionHeader, null, {
            default: withCtx(() => [..._cache[19] || (_cache[19] = [
              createTextVNode("备份", -1)
            ])]),
            _: 1
          }),
          createBaseVNode("form", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(backups), (backup) => {
              return openBlock(), createBlock(_sfc_main$7, {
                key: backup.timestamp,
                label: unref(ddmmyyyy)(backup.timestamp) + " " + unref(hhmm)(backup.timestamp)
              }, {
                default: withCtx(() => [
                  createVNode(_sfc_main$6, {
                    primary: "",
                    onClick: ($event) => unref(downloadBackup)(backup.data, backup.timestamp)
                  }, {
                    default: withCtx(() => [..._cache[20] || (_cache[20] = [
                      createTextVNode(" 导出 ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"]),
                  createVNode(_sfc_main$6, {
                    primary: "",
                    onClick: ($event) => restoreBackupAndReload($event, backup.data)
                  }, {
                    default: withCtx(() => [..._cache[21] || (_cache[21] = [
                      createTextVNode(" 恢复 ", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"]),
                  createVNode(_sfc_main$6, {
                    danger: "",
                    onClick: ($event) => confirmDeleteBackup($event, backup)
                  }, {
                    default: withCtx(() => [..._cache[22] || (_cache[22] = [
                      createTextVNode("删除", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ]),
                _: 2
              }, 1032, ["label"]);
            }), 128))
          ])
        ], 64)) : createCommentVNode("", true),
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[23] || (_cache[23] = [
            createTextVNode("危险区域", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$7, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$6, {
                danger: "",
                onClick: confirmResetAllData
              }, {
                default: withCtx(() => [..._cache[24] || (_cache[24] = [
                  createTextVNode("重置所有数据", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 64);
    };
  }
});
export {
  _sfc_main as default
};
