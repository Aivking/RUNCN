import { vModelText } from "./runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import { fetchTreasuryBalance, FactionApiError, fetchTreasuryRecords, createTreasuryRecord } from "./use-faction-api.js";
import $style from "./FactionPanel.module.css.js";
import { defineComponent, computed, onMounted, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createBlock, createCommentVNode, withDirectives, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { normalizeStyle, toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const _hoisted_1 = { style: { "display": "flex", "gap": "4px" } };
const _hoisted_2 = { style: { "display": "flex", "gap": "8px", "font-size": "12px" } };
const _hoisted_3 = ["checked"];
const _hoisted_4 = ["checked"];
const _hoisted_5 = { key: 2 };
const _hoisted_6 = { style: { "opacity": "0.6", "font-size": "12px" } };
const _hoisted_7 = {
  key: 0,
  style: { "opacity": "0.5", "font-size": "12px", "margin-left": "8px" }
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FactionTreasury",
  props: {
    myRole: {}
  },
  setup(__props) {
    const props = __props;
    const balance = ref(0);
    const records = ref([]);
    const loading = ref(false);
    const error = ref("");
    const showForm = ref(false);
    const formAmount = ref("");
    const formNote = ref("");
    const formIsExpense = ref(false);
    const isExecutive = computed(() => props.myRole === "executive");
    const canViewRecords = computed(() => props.myRole !== "member");
    async function loadBalance() {
      try {
        const result = await fetchTreasuryBalance();
        balance.value = result.balance;
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    async function loadRecords() {
      if (!canViewRecords.value) {
        return;
      }
      loading.value = true;
      try {
        const result = await fetchTreasuryRecords();
        records.value = result.records;
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      } finally {
        loading.value = false;
      }
    }
    async function handleSubmit() {
      const amt = parseFloat(formAmount.value);
      if (isNaN(amt) || amt === 0) {
        return;
      }
      const finalAmount = formIsExpense.value ? -Math.abs(amt) : Math.abs(amt);
      try {
        await createTreasuryRecord(finalAmount, formNote.value);
        showForm.value = false;
        formAmount.value = "";
        formNote.value = "";
        formIsExpense.value = false;
        await loadBalance();
        await loadRecords();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    function formatAmount(amount) {
      const sign = amount >= 0 ? "+" : "";
      return `${sign}${amount.toFixed(2)}`;
    }
    function formatDate(iso) {
      const d = new Date(iso);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    }
    onMounted(() => {
      loadBalance();
      loadRecords();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass(unref($style).membersToolbar)
        }, [
          createBaseVNode("div", null, [
            _cache[6] || (_cache[6] = createBaseVNode("span", { style: { "opacity": "0.6", "font-size": "11px" } }, "当前余额", -1)),
            createBaseVNode("span", {
              style: normalizeStyle([{ "font-size": "18px", "margin-left": "8px" }, { color: unref(balance) >= 0 ? "rgb(146, 196, 125)" : "rgb(217, 83, 79)" }])
            }, toDisplayString(unref(balance).toFixed(2)), 5)
          ]),
          createBaseVNode("div", _hoisted_1, [
            createVNode(_sfc_main$1, {
              dark: "",
              onClick: _cache[0] || (_cache[0] = ($event) => {
                loadBalance();
                loadRecords();
              })
            }, {
              default: withCtx(() => [..._cache[7] || (_cache[7] = [
                createTextVNode("刷新", -1)
              ])]),
              _: 1
            }),
            unref(isExecutive) ? (openBlock(), createBlock(_sfc_main$1, {
              key: 0,
              dark: "",
              onClick: _cache[1] || (_cache[1] = ($event) => showForm.value = !unref(showForm))
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(showForm) ? "取消" : "录入"), 1)
              ]),
              _: 1
            })) : createCommentVNode("", true)
          ])
        ], 2),
        unref(showForm) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref($style).loginContainer)
        }, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "类型", 2),
            createBaseVNode("div", _hoisted_2, [
              createBaseVNode("label", null, [
                createBaseVNode("input", {
                  type: "radio",
                  checked: !unref(formIsExpense),
                  onChange: _cache[2] || (_cache[2] = ($event) => formIsExpense.value = false)
                }, null, 40, _hoisted_3),
                _cache[8] || (_cache[8] = createTextVNode(" 收入", -1))
              ]),
              createBaseVNode("label", null, [
                createBaseVNode("input", {
                  type: "radio",
                  checked: unref(formIsExpense),
                  onChange: _cache[3] || (_cache[3] = ($event) => formIsExpense.value = true)
                }, null, 40, _hoisted_4),
                _cache[9] || (_cache[9] = createTextVNode(" 支出", -1))
              ])
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "金额", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(formAmount) ? formAmount.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "number",
              step: "0.01",
              min: "0.01"
            }, null, 2), [
              [vModelText, unref(formAmount)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "备注", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => isRef(formNote) ? formNote.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "text"
            }, null, 2), [
              [vModelText, unref(formNote)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).buttonRow)
          }, [
            createVNode(_sfc_main$1, {
              primary: "",
              disabled: !unref(formAmount),
              onClick: handleSubmit
            }, {
              default: withCtx(() => [..._cache[10] || (_cache[10] = [
                createTextVNode("提交", -1)
              ])]),
              _: 1
            }, 8, ["disabled"])
          ], 2)
        ], 2)) : createCommentVNode("", true),
        unref(error) ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(unref($style).errorMessage)
        }, toDisplayString(unref(error)), 3)) : createCommentVNode("", true),
        unref(canViewRecords) ? (openBlock(), createElementBlock("div", _hoisted_5, [
          unref(loading) ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(unref($style).loadingMessage)
          }, "加载中...", 2)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
            unref(records).length === 0 ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: normalizeClass(unref($style).emptyMessage)
            }, "暂无收支记录", 2)) : createCommentVNode("", true),
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(records), (record) => {
              return openBlock(), createElementBlock("div", {
                key: record.id,
                class: normalizeClass(unref($style).memberRow)
              }, [
                createBaseVNode("div", {
                  class: normalizeClass(unref($style).memberInfo)
                }, [
                  createBaseVNode("span", {
                    style: normalizeStyle({ color: record.amount >= 0 ? "rgb(146, 196, 125)" : "rgb(217, 83, 79)", minWidth: "80px", display: "inline-block" })
                  }, toDisplayString(formatAmount(record.amount)), 5),
                  createBaseVNode("span", _hoisted_6, toDisplayString(record.operator), 1),
                  record.note ? (openBlock(), createElementBlock("span", _hoisted_7, toDisplayString(record.note), 1)) : createCommentVNode("", true)
                ], 2),
                createBaseVNode("span", {
                  class: normalizeClass(unref($style).memberJoined)
                }, toDisplayString(formatDate(record.createdAt)), 3)
              ], 2);
            }), 128))
          ], 64))
        ])) : (openBlock(), createElementBlock("div", {
          key: 3,
          class: normalizeClass(unref($style).emptyMessage)
        }, "成员仅可查看余额", 2))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
