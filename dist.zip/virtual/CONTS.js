import xit from "./xit-registry.js";
import _sfc_main from "./CONTS.vue.js";
xit.add({
  command: ["CONTS", "CONTRACTS"],
  name: "合同总览",
  description: "显示活跃合同。",
  contextItems: () => [{ cmd: "XIT CONTC" }, { cmd: "CONTS" }, { cmd: "CONTD" }],
  component: () => _sfc_main
});
