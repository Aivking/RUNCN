import LoadingSpinner from "./LoadingSpinner.vue.js";
import { contractsStore } from "./contracts.js";
import ContractOverviewRow from "./ContractOverviewRow.vue.js";
import { canAcceptContract } from "./utils4.js";
import { isEmpty } from "./is-empty.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, renderList, createCommentVNode } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const _hoisted_1 = ["onClick"];
const _hoisted_2 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CONTSS",
  setup(__props) {
    const STATUS_FILTERS = [
      { key: "OPEN", label: "公开", colorClass: "neutral" },
      { key: "CLOSED", label: "进行中", colorClass: "good" },
      { key: "FULFILLED", label: "已完成", colorClass: "good" },
      { key: "PARTIALLY_FULFILLED", label: "部分完成", colorClass: "partial" },
      { key: "BREACHED", label: "已违约", colorClass: "bad" },
      { key: "TERMINATED", label: "已终止", colorClass: "bad" },
      { key: "CANCELLED", label: "已取消", colorClass: "bad" },
      { key: "REJECTED", label: "已拒绝", colorClass: "bad" },
      { key: "DEADLINE_EXCEEDED", label: "已逾期", colorClass: "bad" }
    ];
    const activeFilters = ref(
      /* @__PURE__ */ new Set(["OPEN", "CLOSED", "PARTIALLY_FULFILLED", "DEADLINE_EXCEEDED"])
    );
    const showFilters = ref(true);
    function toggleFilter(key) {
      const newSet = new Set(activeFilters.value);
      if (newSet.has(key)) {
        newSet.delete(key);
      } else {
        newSet.add(key);
      }
      activeFilters.value = newSet;
    }
    function selectAll() {
      activeFilters.value = new Set(STATUS_FILTERS.map((f) => f.key));
    }
    function selectNone() {
      activeFilters.value = /* @__PURE__ */ new Set();
    }
    const filtered = computed(
      () => (contractsStore.all.value ?? []).filter((c) => activeFilters.value.has(c.status)).sort(compareContracts)
    );
    function compareContracts(a, b) {
      if (canAcceptContract(a) && !canAcceptContract(b)) {
        return -1;
      }
      if (canAcceptContract(b) && !canAcceptContract(a)) {
        return 1;
      }
      return (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0);
    }
    const totals = computed(() => {
      let receivable = 0;
      let payable = 0;
      let currency = "";
      for (const contract of filtered.value) {
        for (const cond of contract.conditions) {
          if (cond.type === "PAYMENT" && cond.amount && cond.status !== "FULFILLED") {
            if (!currency) currency = cond.amount.currency;
            if (cond.party !== contract.party) {
              receivable += cond.amount.amount;
            } else {
              payable += cond.amount.amount;
            }
          }
        }
      }
      return { receivable, payable, currency };
    });
    function formatAmount(amount, currency) {
      if (!currency || amount === 0) return "-";
      return `${amount.toLocaleString()} ${currency}`;
    }
    return (_ctx, _cache) => {
      return !unref(contractsStore).fetched ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.container)
      }, [
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.filterBar)
        }, [
          createBaseVNode("span", {
            class: normalizeClass(_ctx.$style.filterIcon)
          }, "⚙", 2),
          createBaseVNode("button", {
            class: normalizeClass(_ctx.$style.filterAction),
            onClick: selectAll
          }, "全部", 2),
          createBaseVNode("button", {
            class: normalizeClass(_ctx.$style.filterAction),
            onClick: selectNone
          }, "无", 2),
          createBaseVNode("button", {
            class: normalizeClass(_ctx.$style.filterAction),
            onClick: _cache[0] || (_cache[0] = ($event) => showFilters.value = !unref(showFilters))
          }, toDisplayString(unref(showFilters) ? "隐藏过滤器" : "显示过滤器"), 3)
        ], 2),
        unref(showFilters) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(_ctx.$style.statusFilters)
        }, [
          (openBlock(), createElementBlock(Fragment, null, renderList(STATUS_FILTERS, (f) => {
            return createBaseVNode("button", {
              key: f.key,
              class: normalizeClass([
                _ctx.$style.statusBtn,
                _ctx.$style[f.colorClass],
                !unref(activeFilters).has(f.key) && _ctx.$style.inactive
              ]),
              onClick: ($event) => toggleFilter(f.key)
            }, toDisplayString(f.label), 11, _hoisted_1);
          }), 64))
        ], 2)) : createCommentVNode("", true),
        unref(totals).currency ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(_ctx.$style.totalsBar)
        }, [
          createBaseVNode("span", null, "共 " + toDisplayString(unref(filtered).length) + " 单", 1),
          unref(totals).receivable > 0 ? (openBlock(), createElementBlock("span", {
            key: 0,
            class: normalizeClass(_ctx.$style.receivableText)
          }, " 待收: " + toDisplayString(formatAmount(unref(totals).receivable, unref(totals).currency)), 3)) : createCommentVNode("", true),
          unref(totals).payable > 0 ? (openBlock(), createElementBlock("span", {
            key: 1,
            class: normalizeClass(_ctx.$style.payableText)
          }, " 应付: " + toDisplayString(formatAmount(unref(totals).payable, unref(totals).currency)), 3)) : createCommentVNode("", true)
        ], 2)) : createCommentVNode("", true),
        createBaseVNode("table", null, [
          _cache[1] || (_cache[1] = createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", null, "合同"),
              createBaseVNode("th", null, "物品"),
              createBaseVNode("th", null, "对方"),
              createBaseVNode("th", null, "待收款"),
              createBaseVNode("th", null, "应付款"),
              createBaseVNode("th", null, "进度"),
              createBaseVNode("th", null, "状态")
            ])
          ], -1)),
          createBaseVNode("tbody", null, [
            unref(isEmpty)(unref(filtered)) ? (openBlock(), createElementBlock("tr", _hoisted_2, [
              createBaseVNode("td", {
                colspan: "7",
                class: normalizeClass(_ctx.$style.empty)
              }, "没有活动合同", 2)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(unref(filtered), (contract) => {
              return openBlock(), createBlock(ContractOverviewRow, {
                key: contract.id,
                contract
              }, null, 8, ["contract"]);
            }), 128))
          ])
        ])
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
