import { $ } from "./select-dom.js";
import { C } from "./prun-css.js";
import { createFragmentApp } from "./vue-fragment-app.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import _sfc_main from "./GenerateBraRepairActButton.vue.js";
async function onTileReady(tile) {
  const repairBtn = await $(tile.anchor, C.Button.btn);
  createFragmentApp(_sfc_main, { planetNaturalId: tile.parameter }).after(
    repairBtn
  );
}
function init() {
  tiles.observe("BRA", onTileReady);
}
features.add(import.meta.url, init, "BRA：在维护按钮旁添加生成维修 ACT 包的按钮。");
