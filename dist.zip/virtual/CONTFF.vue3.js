const container = "rp-CONTFF__container___17a2ca8";
const totalsBar = "rp-CONTFF__totalsBar___0d09eb4";
const receivableText = "rp-CONTFF__receivableText___3f51212";
const warningText = "rp-CONTFF__warningText___ff3bae1";
const deadlineCell = "rp-CONTFF__deadlineCell___0b647c7";
const iconGrid = "rp-CONTFF__iconGrid___8c2776f";
const dimmed = "rp-CONTFF__dimmed___1acbfd2";
const receivable = "rp-CONTFF__receivable___ddc8157";
const fulfilled = "rp-CONTFF__fulfilled___95f84b5";
const active = "rp-CONTFF__active___0c82fb9";
const failed = "rp-CONTFF__failed___350cecc";
const pending = "rp-CONTFF__pending___69c2a36";
const empty = "rp-CONTFF__empty___f830193";
const style0 = {
  container,
  totalsBar,
  receivableText,
  warningText,
  deadlineCell,
  iconGrid,
  dimmed,
  receivable,
  fulfilled,
  active,
  failed,
  pending,
  empty
};
export {
  active,
  container,
  deadlineCell,
  style0 as default,
  dimmed,
  empty,
  failed,
  fulfilled,
  iconGrid,
  pending,
  receivable,
  receivableText,
  totalsBar,
  warningText
};
