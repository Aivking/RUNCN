import { shallowReactive } from "./reactivity.esm-bundler.js";
const fioBuildingsStore = shallowReactive({
  buildings: void 0,
  loading: false,
  error: false
});
let fetchStarted = false;
const FIO_URL = "https://rest.fnar.net/building/allbuildings";
async function loadFioBuildings() {
  if (fetchStarted) {
    return;
  }
  fetchStarted = true;
  fioBuildingsStore.loading = true;
  fioBuildingsStore.error = false;
  try {
    const response = await fetch(FIO_URL);
    if (!response.ok) {
      fioBuildingsStore.error = true;
      return;
    }
    fioBuildingsStore.buildings = await response.json();
  } catch {
    fioBuildingsStore.error = true;
  } finally {
    fioBuildingsStore.loading = false;
  }
}
function isHabitationBuilding(b) {
  if (b.Recipes.length > 0) {
    return false;
  }
  return b.Pioneers + b.Settlers + b.Technicians + b.Engineers + b.Scientists > 0;
}
function isProductionBuilding(b) {
  return b.Recipes.length > 0;
}
export {
  fioBuildingsStore,
  isHabitationBuilding,
  isProductionBuilding,
  loadFioBuildings
};
