import _sfc_main from "./CommandLists.vue.js";
export {
  _sfc_main as default
};
