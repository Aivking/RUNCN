import { C } from "./prun-css.js";
import _sfc_main$3 from "./PrunButton.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import _sfc_main$1 from "./Active.vue.js";
import _sfc_main$2 from "./RadioItem.vue.js";
import SelectInput from "./SelectInput.vue.js";
import _sfc_main$4 from "./Commands.vue.js";
import { sitesStore } from "./sites.js";
import { storagesStore } from "./storage.js";
import { userData } from "./user-data.js";
import { configurableValue } from "./shared-types.js";
import { showBuffer } from "./buffers.js";
import { defineComponent, computed, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const packageName = "JIANZHUWEIXIU";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GenerateBraRepairActDialog",
  props: {
    planetNaturalId: {}
  },
  setup(__props) {
    const site = computed(() => sitesStore.getByPlanetNaturalId(__props.planetNaturalId));
    const exchangeStationMap = {
      AI1: "Antares Station",
      CI1: "Benten Station",
      IC1: "Hortus Station",
      NC1: "Moria Station",
      CI2: "Arclight Station",
      NC2: "Hubur Station"
    };
    const exchanges = Object.keys(exchangeStationMap);
    const exchange = ref(exchanges[0]);
    const useBaseInv = ref(true);
    const warehouseName = computed(() => `${exchangeStationMap[exchange.value]} Warehouse`);
    function onGenerateClick() {
      if (!site.value) {
        return;
      }
      const baseInventory = {};
      if (useBaseInv.value) {
        const baseStore = storagesStore.all.value?.find(
          (x) => x.addressableId === site.value.siteId && x.type === "STORE"
        );
        if (baseStore) {
          for (const item of baseStore.items) {
            if (item.quantity) {
              baseInventory[item.quantity.material.ticker] = item.quantity.amount;
            }
          }
        }
      }
      const materials = {};
      for (const platform of site.value.platforms) {
        for (const { material, amount } of platform.repairMaterials) {
          materials[material.ticker] = (materials[material.ticker] ?? 0) + amount;
        }
      }
      if (useBaseInv.value) {
        for (const ticker of Object.keys(materials)) {
          const inBase = baseInventory[ticker] ?? 0;
          const need = Math.max(0, materials[ticker] - inBase);
          if (need > 0) {
            materials[ticker] = need;
          } else {
            delete materials[ticker];
          }
        }
      }
      const groupName = "Repair";
      const name = packageName;
      const pkg = {
        global: { name },
        groups: [
          {
            type: "Manual",
            name: groupName,
            materials
          }
        ],
        actions: [
          {
            type: "CX Buy",
            name: "CX Buy",
            group: groupName,
            exchange: exchange.value,
            buyPartial: false,
            allowUnfilled: false,
            useCXInv: true
          },
          {
            type: "MTRA",
            name: "Transfer to Base",
            group: groupName,
            origin: warehouseName.value,
            dest: configurableValue
          }
        ]
      };
      const existing = userData.actionPackages.find((x) => x.global.name === name);
      if (existing) {
        const index = userData.actionPackages.indexOf(existing);
        userData.actionPackages[index] = pkg;
      } else {
        userData.actionPackages.push(pkg);
      }
      showBuffer(`XIT ACT_${name}`);
    }
    return (_ctx, _cache) => {
      return !unref(site) ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).DraftConditionEditor.form)
      }, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[2] || (_cache[2] = [
            createTextVNode("生成维修 ACT 包", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.notice)
        }, "未找到星球基地数据。", 2)
      ], 2)) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).DraftConditionEditor.form)
      }, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[3] || (_cache[3] = [
            createTextVNode("生成维修 ACT 包", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, { label: "星球" }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(_ctx.planetNaturalId), 1)
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "交易所" }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(exchange),
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(exchange) ? exchange.value = $event : null),
                options: unref(exchanges)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "仓库" }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(unref(warehouseName)), 1)
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "扣除基地库存",
            tooltip: "扣除基地仓库中已有的材料后再计算采购量。"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$2, {
                modelValue: unref(useBaseInv),
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(useBaseInv) ? useBaseInv.value = $event : null)
              }, {
                default: withCtx(() => [..._cache[4] || (_cache[4] = [
                  createTextVNode("扣除基地库存", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$4, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$3, {
                primary: "",
                onClick: onGenerateClick
              }, {
                default: withCtx(() => [..._cache[5] || (_cache[5] = [
                  createTextVNode("生成", -1)
                ])]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
