import _sfc_main from "./GripChar.vue.js";
export {
  _sfc_main as default
};
