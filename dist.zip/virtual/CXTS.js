import xit from "./xit-registry.js";
import _sfc_main from "./CXTS.vue.js";
xit.add({
  command: ["CXTS"],
  name: "商品交易所交易记录",
  description: "所有商品交易所交易记录列表。",
  component: () => _sfc_main
});
