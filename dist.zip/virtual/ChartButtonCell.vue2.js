import fa from "./font-awesome.module.css.js";
import { showBuffer } from "./buffers.js";
import { defineComponent, openBlock, createElementBlock } from "./runtime-core.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ChartButtonCell",
  props: {
    chartId: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("td", {
        class: normalizeClass([unref(fa).solid, _ctx.$style.cell]),
        onClick: _cache[0] || (_cache[0] = ($event) => unref(showBuffer)(`XIT FINCH ${_ctx.chartId}`))
      }, toDisplayString(""), 2);
    };
  }
});
export {
  _sfc_main as default
};
