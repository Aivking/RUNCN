import { vModelText } from "./runtime-dom.esm-bundler.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import { fetchBulletins, FactionApiError, postBulletin } from "./use-faction-api.js";
import { userData } from "./user-data.js";
import $style from "./FactionPanel.module.css.js";
import { defineComponent, computed, onMounted, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, createCommentVNode, createBlock, withDirectives, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const _hoisted_1 = { style: { "display": "flex", "align-items": "center", "gap": "6px" } };
const _hoisted_2 = {
  key: 0,
  style: { "font-size": "10px", "opacity": "0.5" }
};
const _hoisted_3 = { style: { "display": "flex", "justify-content": "space-between", "align-items": "center" } };
const _hoisted_4 = { style: { "font-size": "12px", "color": "rgb(220, 220, 220)", "white-space": "pre-wrap", "padding": "2px 0 6px" } };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FactionBulletin",
  props: {
    myRole: {}
  },
  setup(__props) {
    const props = __props;
    const bulletins = ref([]);
    const loading = ref(false);
    const error = ref("");
    const fromCache = ref(false);
    const showForm = ref(false);
    const formTitle = ref("");
    const formContent = ref("");
    const isExecutive = computed(() => props.myRole === "executive");
    function notifyNewBulletins(incoming) {
      const lastSeen = userData.factionLastSeenBulletinAt;
      const newOnes = lastSeen ? incoming.filter((b) => b.createdAt > lastSeen) : incoming.slice(0, 1);
      if (newOnes.length === 0) return;
      if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted") {
        for (const b of newOnes) {
          new Notification(`[琉璃主权资本] 新公告：${b.title}`, {
            body: b.content.slice(0, 80),
            tag: `faction-bulletin-${b.id}`
          });
        }
      }
      userData.factionLastSeenBulletinAt = incoming[0]?.createdAt;
    }
    async function loadData() {
      loading.value = true;
      error.value = "";
      try {
        const result = await fetchBulletins();
        bulletins.value = result.bulletins;
        fromCache.value = result.fromCache ?? false;
        if (!result.fromCache) {
          notifyNewBulletins(result.bulletins);
        }
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        } else {
          error.value = "无法加载公告，请检查网络连接";
        }
      } finally {
        loading.value = false;
      }
    }
    async function handlePost() {
      if (!formTitle.value || !formContent.value) {
        return;
      }
      try {
        await postBulletin(formTitle.value, formContent.value);
        showForm.value = false;
        formTitle.value = "";
        formContent.value = "";
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        }
      }
    }
    function formatDate(iso) {
      const d = new Date(iso);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    }
    onMounted(() => {
      if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "default") {
        Notification.requestPermission();
      }
      loadData();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass(unref($style).membersToolbar)
        }, [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_sfc_main$1, {
              dark: "",
              onClick: loadData
            }, {
              default: withCtx(() => [..._cache[3] || (_cache[3] = [
                createTextVNode("刷新", -1)
              ])]),
              _: 1
            }),
            unref(fromCache) ? (openBlock(), createElementBlock("span", _hoisted_2, "（离线缓存）")) : createCommentVNode("", true)
          ]),
          unref(isExecutive) ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            dark: "",
            onClick: _cache[0] || (_cache[0] = ($event) => showForm.value = !unref(showForm))
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(unref(showForm) ? "取消" : "发布公告"), 1)
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ], 2),
        unref(showForm) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref($style).loginContainer)
        }, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "标题", 2),
            withDirectives(createBaseVNode("input", {
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(formTitle) ? formTitle.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              type: "text"
            }, null, 2), [
              [vModelText, unref(formTitle)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).field)
          }, [
            createBaseVNode("div", {
              class: normalizeClass(unref($style).fieldLabel)
            }, "内容", 2),
            withDirectives(createBaseVNode("textarea", {
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(formContent) ? formContent.value = $event : null),
              class: normalizeClass(unref($style).fieldInput),
              rows: "4",
              style: { "resize": "vertical", "font-family": "inherit", "width": "100%", "box-sizing": "border-box" }
            }, null, 2), [
              [vModelText, unref(formContent)]
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(unref($style).buttonRow)
          }, [
            createVNode(_sfc_main$1, {
              primary: "",
              disabled: !unref(formTitle) || !unref(formContent),
              onClick: handlePost
            }, {
              default: withCtx(() => [..._cache[4] || (_cache[4] = [
                createTextVNode("发布", -1)
              ])]),
              _: 1
            }, 8, ["disabled"])
          ], 2)
        ], 2)) : createCommentVNode("", true),
        unref(error) ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(unref($style).errorMessage)
        }, toDisplayString(unref(error)), 3)) : createCommentVNode("", true),
        unref(loading) ? (openBlock(), createElementBlock("div", {
          key: 2,
          class: normalizeClass(unref($style).loadingMessage)
        }, "加载中...", 2)) : (openBlock(), createElementBlock(Fragment, { key: 3 }, [
          unref(bulletins).length === 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(unref($style).emptyMessage)
          }, "暂无公告", 2)) : createCommentVNode("", true),
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(bulletins), (bulletin) => {
            return openBlock(), createElementBlock("div", {
              key: bulletin.id,
              class: normalizeClass(unref($style).memberRow),
              style: { "flex-direction": "column", "align-items": "stretch", "gap": "4px" }
            }, [
              createBaseVNode("div", _hoisted_3, [
                createVNode(SectionHeader, { style: { "color": "rgb(230, 200, 80)" } }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(bulletin.title), 1)
                  ]),
                  _: 2
                }, 1024),
                createBaseVNode("span", {
                  class: normalizeClass(unref($style).memberJoined)
                }, toDisplayString(bulletin.author) + " · " + toDisplayString(formatDate(bulletin.createdAt)), 3)
              ]),
              createBaseVNode("div", _hoisted_4, toDisplayString(bulletin.content), 1)
            ], 2);
          }), 128))
        ], 64))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
