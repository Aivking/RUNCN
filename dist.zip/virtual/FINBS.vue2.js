import BalanceSheetSection from "./BalanceSheetSection.vue.js";
import { calcTotalDeposits, calcTotalCashAndCashEquivalents, calcTotalLoansReceivable, calcTotalBaseInventory, calcTotalInventory, calcTotalCurrentAssets, calcTotalBuildingsMarketValue, calcTotalBuildings, calcTotalShips, calcTotalLongTermReceivables, calcTotalIntangibleAssets, calcTotalNonCurrentAssets, calcTotalLoansPayable, calcTotalCurrentLiabilities, calcTotalLongTermPayables, calcTotalNonCurrentLiabilities, calcTotalAssets, calcTotalLiabilities, calcEquity } from "./balance-sheet-summary.js";
import { liveBalanceSheet } from "./balance-sheet-live.js";
import { ddmmyyyy } from "./format.js";
import { lastBalance, previousBalance } from "./user-data-balance.js";
import { userData } from "./user-data.js";
import { defineComponent, computed, openBlock, createElementBlock, createElementVNode as createBaseVNode, Fragment, createTextVNode, renderList, createVNode } from "./runtime-core.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
import { toDisplayString } from "./shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FINBS",
  setup(__props) {
    const currentAssets = computed(() => ({
      name: "流动资产",
      chartId: "CURRENT ASSETS",
      value: calcTotalCurrentAssets,
      children: [
        {
          name: "现金及现金等价物",
          chartId: "CA CASH EQUIVALENTS",
          value: calcTotalCashAndCashEquivalents,
          children: [
            {
              name: "现金",
              chartId: "CA CASH",
              value: (x) => x.assets?.current?.cashAndCashEquivalents?.cash
            },
            {
              name: "存款",
              chartId: "CA DEPOSITS",
              value: calcTotalDeposits,
              children: [
                {
                  name: "CX",
                  chartId: "CA DEPOSITS CX",
                  value: (x) => x.assets?.current?.cashAndCashEquivalents?.deposits?.cx
                },
                {
                  name: "FX",
                  chartId: "CA DEPOSITS FX",
                  value: (x) => x.assets?.current?.cashAndCashEquivalents?.deposits?.fx
                }
              ]
            },
            {
              name: "MM 材料",
              chartId: "CA MM MATERIALS",
              tooltip: "当前存放在 CX 仓库中的做市商材料。你可以通过 XIT SET FIN 自定义这些材料的列表。由于这些材料可以立即转换为现金，因此被视为现金等价物。",
              value: (x) => x.assets?.current?.cashAndCashEquivalents?.mmMaterials
            }
          ]
        },
        {
          name: "应收账款",
          chartId: "CA ACCOUNTS RECEIVABLE",
          value: (x) => x.assets?.current?.accountsReceivable
        },
        {
          name: "应收贷款",
          chartId: "CA LOANS RECEIVABLE",
          value: calcTotalLoansReceivable,
          children: [
            {
              name: "本金",
              chartId: "CA LOANS PRINCIPAL",
              value: (x) => x.assets?.current?.loansReceivable?.principal
            },
            {
              name: "利息",
              chartId: "CA LOANS INTEREST",
              value: (x) => x.assets?.current?.loansReceivable?.interest
            }
          ]
        },
        {
          name: "库存",
          chartId: "CA INVENTORY",
          value: calcTotalInventory,
          children: [
            {
              name: "CX 上市材料",
              chartId: "CA CX LISTED MATERIALS",
              value: (x) => x.assets?.current?.inventory?.cxListedMaterials
            },
            {
              name: "CX 库存",
              chartId: "CA CX INVENTORY",
              value: (x) => x.assets?.current?.inventory?.cxInventory
            },
            {
              name: "在途材料",
              chartId: "CA MATERIALS IN TRANSIT",
              value: (x) => x.assets?.current?.inventory?.materialsInTransit
            },
            {
              name: "基地库存",
              chartId: "CA BASE INVENTORY",
              value: calcTotalBaseInventory,
              children: [
                {
                  name: "产成品",
                  chartId: "CA FINISHED GOODS",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.finishedGoods
                },
                {
                  name: "在制品 (WIP)",
                  chartId: "CA WORK IN PROGRESS",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.workInProgress
                },
                {
                  name: "原材料",
                  chartId: "CA RAW MATERIALS",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.rawMaterials
                },
                {
                  name: "劳动力消耗品",
                  chartId: "CA WORKFORCE CONSUMABLES",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.workforceConsumables
                },
                {
                  name: "其他物品",
                  chartId: "CA OTHER ITEMS",
                  value: (x) => x.assets?.current?.inventory?.baseInventory?.otherItems
                }
              ]
            },
            {
              name: "燃料箱",
              chartId: "CA FUEL TANKS",
              value: (x) => x.assets?.current?.inventory?.fuelTanks
            },
            {
              name: "应收材料",
              chartId: "CA MATERIALS RECEIVABLE",
              value: (x) => x.assets?.current?.inventory?.materialsReceivable
            }
          ]
        }
      ]
    }));
    const nonCurrentAssets = computed(() => ({
      name: "非流动资产",
      chartId: "NON CURRENT ASSETS",
      value: calcTotalNonCurrentAssets,
      children: [
        {
          name: "建筑物（净值）",
          chartId: "NCA BUILDINGS",
          value: calcTotalBuildings,
          children: [
            {
              name: "市场价值",
              chartId: "NCA BUILDINGS VALUE",
              value: calcTotalBuildingsMarketValue,
              children: [
                {
                  name: "基础设施",
                  chartId: "NCA BUILDINGS INFRASTRUCTURE",
                  value: (x) => x.assets?.nonCurrent?.buildings?.marketValue?.infrastructure
                },
                {
                  name: "资源开采",
                  chartId: "NCA BUILDINGS RESOURCE EXTRACTION",
                  value: (x) => x.assets?.nonCurrent?.buildings?.marketValue?.resourceExtraction
                },
                {
                  name: "生产",
                  chartId: "NCA BUILDINGS PRODUCTION",
                  value: (x) => x.assets?.nonCurrent?.buildings?.marketValue?.production
                }
              ]
            },
            {
              name: "累计折旧",
              chartId: "NCA BUILDINGS DEPRECIATION",
              less: true,
              value: (x) => x.assets?.nonCurrent?.buildings?.accumulatedDepreciation
            }
          ]
        },
        {
          name: "船舶（净值）",
          chartId: "NCA SHIPS",
          value: calcTotalShips,
          excluded: !userData.fullEquityMode,
          children: [
            {
              name: "市场价值",
              chartId: "NCA SHIPS VALUE",
              value: (x) => x.assets?.nonCurrent?.ships?.marketValue
            },
            {
              name: "累计折旧",
              chartId: "NCA SHIPS DEPRECIATION",
              less: true,
              value: (x) => x.assets?.nonCurrent?.ships?.accumulatedDepreciation
            }
          ]
        },
        {
          name: "长期应收款",
          chartId: "NCA LONG TERM RECEIVABLES",
          value: calcTotalLongTermReceivables,
          children: [
            {
              name: "应收账款",
              chartId: "NCA ACCOUNTS RECEIVABLE",
              value: (x) => x.assets?.nonCurrent?.longTermReceivables?.accountsReceivable
            },
            {
              name: "在途材料",
              chartId: "NCA MATERIALS IN TRANSIT",
              value: (x) => x.assets?.nonCurrent?.longTermReceivables?.materialsInTransit
            },
            {
              name: "应收材料",
              chartId: "NCA MATERIALS RECEIVABLE",
              value: (x) => x.assets?.nonCurrent?.longTermReceivables?.materialsReceivable
            },
            {
              name: "贷款本金",
              chartId: "NCA LOANS PRINCIPAL",
              value: (x) => x.assets?.nonCurrent?.longTermReceivables?.loansPrincipal
            }
          ]
        },
        {
          name: "无形资产",
          chartId: "NCA INTANGIBLE ASSETS",
          value: calcTotalIntangibleAssets,
          excluded: !userData.fullEquityMode,
          children: [
            {
              name: "总部升级",
              chartId: "NCA HQ UPGRADES",
              value: (x) => x.assets?.nonCurrent?.intangibleAssets?.hqUpgrades
            },
            {
              name: "APEX 代表中心",
              chartId: "NCA ARC",
              value: (x) => x.assets?.nonCurrent?.intangibleAssets?.arc
            }
          ]
        }
      ]
    }));
    const currentLiabilities = computed(() => ({
      name: "流动负债",
      chartId: "CURRENT LIABILITIES",
      value: calcTotalCurrentLiabilities,
      children: [
        {
          name: "应付账款",
          chartId: "CL ACCOUNTS PAYABLE",
          value: (x) => x.liabilities?.current?.accountsPayable
        },
        {
          name: "应付材料",
          chartId: "CL MATERIALS PAYABLE",
          value: (x) => x.liabilities?.current?.materialsPayable
        },
        {
          name: "应付贷款",
          chartId: "CL LOANS PAYABLE",
          value: calcTotalLoansPayable,
          children: [
            {
              name: "本金",
              chartId: "CL LOANS PRINCIPAL",
              value: (x) => x.liabilities?.current?.loansPayable?.principal
            },
            {
              name: "利息",
              chartId: "CL LOANS INTEREST",
              value: (x) => x.liabilities?.current?.loansPayable?.interest
            }
          ]
        }
      ]
    }));
    const nonCurrentLiabilities = computed(() => ({
      name: "非流动负债",
      chartId: "NON CURRENT LIABILITIES",
      value: calcTotalNonCurrentLiabilities,
      children: [
        {
          name: "长期应付款",
          chartId: "NCL LONG TERM PAYABLES",
          value: calcTotalLongTermPayables,
          children: [
            {
              name: "应付账款",
              chartId: "NCL ACCOUNTS PAYABLE",
              value: (x) => x.liabilities?.nonCurrent?.longTermPayables?.accountsPayable
            },
            {
              name: "应付材料",
              chartId: "NCL MATERIALS PAYABLE",
              value: (x) => x.liabilities?.nonCurrent?.longTermPayables?.materialsPayable
            },
            {
              name: "贷款本金",
              chartId: "NCL LOANS PRINCIPAL",
              value: (x) => x.liabilities?.nonCurrent?.longTermPayables?.loansPrincipal
            }
          ]
        }
      ]
    }));
    const equity = computed(() => ({
      name: "权益",
      chartId: "EQUITY",
      coloredChange: true,
      value: calcEquity,
      children: [
        {
          name: "总资产",
          chartId: "TOTAL ASSETS",
          value: calcTotalAssets
        },
        {
          name: "总负债",
          chartId: "TOTAL LIABILITIES",
          less: true,
          value: calcTotalLiabilities
        }
      ]
    }));
    const sections = [
      currentAssets,
      nonCurrentAssets,
      currentLiabilities,
      nonCurrentLiabilities,
      equity
    ];
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("table", null, [
        createBaseVNode("thead", null, [
          createBaseVNode("tr", null, [
            _cache[0] || (_cache[0] = createBaseVNode("th", null, " ", -1)),
            _cache[1] || (_cache[1] = createBaseVNode("th", null, "当前期间", -1)),
            createBaseVNode("th", null, [
              unref(lastBalance) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                createTextVNode(toDisplayString(unref(ddmmyyyy)(unref(lastBalance).timestamp)), 1)
              ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                createTextVNode("上一期间")
              ], 64))
            ]),
            createBaseVNode("th", null, [
              unref(previousBalance) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                createTextVNode(toDisplayString(unref(ddmmyyyy)(unref(previousBalance).timestamp)), 1)
              ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                createTextVNode("前一期间")
              ], 64))
            ]),
            _cache[2] || (_cache[2] = createBaseVNode("th", null, "变化", -1)),
            _cache[3] || (_cache[3] = createBaseVNode("th", null, null, -1))
          ])
        ]),
        (openBlock(), createElementBlock(Fragment, null, renderList(sections, (section) => {
          return createVNode(BalanceSheetSection, {
            key: section.value.name,
            current: unref(liveBalanceSheet),
            last: unref(lastBalance),
            previous: unref(previousBalance),
            section: section.value
          }, null, 8, ["current", "last", "previous", "section"]);
        }), 64))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
