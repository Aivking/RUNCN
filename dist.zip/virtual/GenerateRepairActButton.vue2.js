import _sfc_main from "./GenerateRepairActButton.vue.js";
export {
  _sfc_main as default
};
