import xit from "./xit-registry.js";
import FIN from "./FIN.vue.js";
xit.add({
  command: ["FIN"],
  name: "财务概览",
  description: "基本财务概览和库存明细。",
  contextItems: () => [
    { cmd: "XIT FINBS" },
    { cmd: "XIT FINPR" },
    { cmd: "XIT FINCH" },
    { cmd: "XIT SET FIN" }
  ],
  component: () => FIN
});
