import _sfc_main$1 from "./FinHeader.vue.js";
import HistoryChart from "./HistoryChart.vue.js";
import _sfc_main$2 from "./AssetPieChart.vue.js";
import _sfc_main$3 from "./LocationsPieChart.vue.js";
import { showBuffer } from "./buffers.js";
import { useXitParameters } from "./use-xit-parameters.js";
import SectionHeader from "./SectionHeader.vue.js";
import { charts } from "./charts.js";
import { defineComponent, computed, openBlock, createElementBlock, Fragment, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, createBlock } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { normalizeClass } from "./shared.esm-bundler.js";
const _hoisted_1 = { style: { marginTop: "5px" } };
const _hoisted_2 = { key: 2 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FINCH",
  setup(__props) {
    const parameters = useXitParameters();
    const parameter = parameters.join(" ");
    const finch = ref(Math.random() < 0.01);
    const chartDef = computed(() => charts.value.find((x) => x.value === parameter));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(_ctx.$style.root)
      }, [
        unref(finch) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
          createVNode(SectionHeader, null, {
            default: withCtx(() => [..._cache[3] || (_cache[3] = [
              createTextVNode("Finch", -1)
            ])]),
            _: 1
          }),
          createBaseVNode("img", {
            src: "https://refined-prun.github.io/assets/finch.jpeg",
            alt: "Finch",
            class: normalizeClass(_ctx.$style.clickable),
            onClick: _cache[0] || (_cache[0] = ($event) => finch.value = false)
          }, null, 2)
        ], 64)) : !unref(parameter) ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
          createBaseVNode("div", {
            style: { marginTop: "5px" },
            class: normalizeClass(_ctx.$style.clickable)
          }, [
            createVNode(HistoryChart)
          ], 2),
          createVNode(_sfc_main$1, null, {
            default: withCtx(() => [..._cache[4] || (_cache[4] = [
              createTextVNode("资产分布", -1)
            ])]),
            _: 1
          }),
          createBaseVNode("div", _hoisted_1, [
            createVNode(_sfc_main$2, {
              class: normalizeClass(_ctx.$style.clickable),
              onClick: _cache[1] || (_cache[1] = () => unref(showBuffer)("XIT FINCH ASSETS"))
            }, null, 8, ["class"]),
            createVNode(_sfc_main$3, {
              class: normalizeClass(_ctx.$style.clickable),
              onClick: _cache[2] || (_cache[2] = () => unref(showBuffer)("XIT FINCH LOCATIONS"))
            }, null, 8, ["class"])
          ])
        ], 64)) : unref(chartDef) ? (openBlock(), createBlock(HistoryChart, {
          key: 2,
          "chart-def": unref(chartDef)
        }, null, 8, ["chart-def"])) : (openBlock(), createElementBlock(Fragment, { key: 3 }, [
          unref(parameter) === "ASSETS" ? (openBlock(), createBlock(_sfc_main$2, { key: 0 })) : unref(parameter) === "LOCATIONS" ? (openBlock(), createBlock(_sfc_main$3, { key: 1 })) : (openBlock(), createElementBlock("span", _hoisted_2, "错误：无效的图表类型"))
        ], 64))
      ], 2);
    };
  }
});
export {
  _sfc_main as default
};
