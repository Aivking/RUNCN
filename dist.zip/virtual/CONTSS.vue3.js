const container = "rp-CONTSS__container___bc4c49a";
const totalsBar = "rp-CONTSS__totalsBar___9c171a7";
const receivableText = "rp-CONTSS__receivableText___10b763b";
const payableText = "rp-CONTSS__payableText___70185e7";
const warningText = "rp-CONTSS__warningText___e59c87b";
const empty = "rp-CONTSS__empty___1839012";
const style0 = {
  container,
  totalsBar,
  receivableText,
  payableText,
  warningText,
  empty
};
export {
  container,
  style0 as default,
  empty,
  payableText,
  receivableText,
  totalsBar,
  warningText
};
