import { C } from "./prun-css.js";
import _sfc_main$4 from "./PrunButton.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import _sfc_main$1 from "./Active.vue.js";
import _sfc_main$2 from "./NumberInput.vue.js";
import SelectInput from "./SelectInput.vue.js";
import _sfc_main$3 from "./RadioItem.vue.js";
import _sfc_main$5 from "./Commands.vue.js";
import { userData } from "./user-data.js";
import { calculatePlanetBurn } from "./burn2.js";
import { configurableValue } from "./shared-types.js";
import { useXitParameters } from "./use-xit-parameters.js";
import { sitesStore } from "./sites.js";
import { workforcesStore } from "./workforces.js";
import { productionStore } from "./production.js";
import { storagesStore } from "./storage.js";
import { materialsStore } from "./materials.js";
import { shipsStore } from "./ships.js";
import { getEntityNameFromAddress } from "./addresses.js";
import { fixed2 } from "./format.js";
import { showBuffer } from "./buffers.js";
import { defineComponent, computed, watch, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, Fragment, createCommentVNode } from "./runtime-core.esm-bundler.js";
import { ref, unref, isRef } from "./reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GenerateActDialog",
  setup(__props) {
    const parameters = useXitParameters();
    const planetName = computed(() => parameters.join(" "));
    const site = computed(() => sitesStore.getByPlanetNaturalIdOrName(planetName.value));
    const burn = computed(() => {
      if (!site.value) {
        return void 0;
      }
      const id = site.value.siteId;
      const workforce = workforcesStore.getById(id)?.workforces;
      const production = productionStore.getBySiteId(id);
      const storage = storagesStore.getByAddressableId(id);
      if (!workforce || !production) {
        return void 0;
      }
      return {
        planetName: getEntityNameFromAddress(site.value.address) ?? planetName.value,
        burn: calculatePlanetBurn(production, workforce, storage ?? [])
      };
    });
    const days = ref(7);
    const daysError = ref(false);
    const includeConsumables = ref(true);
    const includeInputs = ref(false);
    const useBaseInv = ref(true);
    const exchangeStationMap = {
      AI1: "Antares Station",
      CI1: "Benten Station",
      IC1: "Hortus Station",
      NC1: "Moria Station",
      CI2: "Arclight Station",
      NC2: "Hubur Station"
    };
    const exchanges = Object.keys(exchangeStationMap);
    const exchange = ref(exchanges[0]);
    const warehouseName = computed(() => `${exchangeStationMap[exchange.value]} Warehouse`);
    const selectedShip = ref("");
    const shipSelectOptions = computed(() => {
      const ships = shipsStore.all.value;
      if (!ships) return ["不限制"];
      const opts = ["不限制"];
      for (const ship of ships) {
        const store = storagesStore.getById(ship.idShipStore);
        const wCap = store?.weightCapacity ?? 0;
        const vCap = store?.volumeCapacity ?? 0;
        const label = ship.name ? `${ship.registration} (${ship.name}) ${fixed2(wCap)}t/${fixed2(vCap)}m³` : `${ship.registration} ${fixed2(wCap)}t/${fixed2(vCap)}m³`;
        opts.push(label);
      }
      return opts;
    });
    function getSelectedShip() {
      if (!selectedShip.value || selectedShip.value === "不限制") return void 0;
      const reg = selectedShip.value.split(" ")[0];
      return shipsStore.getByRegistration(reg);
    }
    function calcBillWeightVolume(d) {
      if (!burn.value || d <= 0) return { weight: 0, volume: 0 };
      const consumablesOnly = includeConsumables.value && !includeInputs.value;
      let burnData = burn.value.burn;
      if (!useBaseInv.value && site.value) {
        const id = site.value.siteId;
        const wf = workforcesStore.getById(id)?.workforces;
        const prod = productionStore.getBySiteId(id);
        burnData = calculatePlanetBurn(consumablesOnly ? void 0 : prod, wf, void 0);
      }
      let weight = 0;
      let volume = 0;
      for (const ticker of Object.keys(burnData)) {
        const matBurn = burnData[ticker];
        if (matBurn.dailyAmount >= 0) continue;
        if (consumablesOnly && matBurn.type !== "workforce") continue;
        if (!consumablesOnly && !includeConsumables.value && matBurn.type === "workforce") continue;
        const need = useBaseInv.value ? Math.ceil((matBurn.daysLeft - d) * matBurn.dailyAmount) : Math.ceil(-d * matBurn.dailyAmount);
        if (need > 0) {
          const mat = materialsStore.getByTicker(ticker);
          if (mat) {
            weight += mat.weight * need;
            volume += mat.volume * need;
          }
        }
      }
      return { weight, volume };
    }
    watch([selectedShip, includeConsumables, includeInputs, useBaseInv], () => {
      const ship = getSelectedShip();
      if (!ship) return;
      const store = storagesStore.getById(ship.idShipStore);
      if (!store) return;
      const wCap = store.weightCapacity;
      const vCap = store.volumeCapacity;
      let lo = 1;
      let hi = 9999;
      let best = 1;
      while (lo <= hi) {
        const mid = Math.floor((lo + hi) / 2);
        const { weight, volume } = calcBillWeightVolume(mid);
        if (weight <= wCap && volume <= vCap) {
          best = mid;
          lo = mid + 1;
        } else {
          hi = mid - 1;
        }
      }
      days.value = best;
    });
    const packageName = computed(() => {
      const name = burn.value?.planetName ?? planetName.value;
      return `${name} Resupply ${days.value}d`;
    });
    const materialBill = computed(() => {
      if (!burn.value || days.value <= 0) {
        return void 0;
      }
      const consumablesOnly = includeConsumables.value && !includeInputs.value;
      const planetBurn = burn.value.burn;
      let burnData = planetBurn;
      if (!useBaseInv.value && site.value) {
        const id = site.value.siteId;
        const workforce = workforcesStore.getById(id)?.workforces;
        const production = productionStore.getBySiteId(id);
        burnData = calculatePlanetBurn(consumablesOnly ? void 0 : production, workforce, void 0);
      }
      const result = {};
      for (const ticker of Object.keys(burnData)) {
        const matBurn = burnData[ticker];
        if (matBurn.dailyAmount >= 0) {
          continue;
        }
        if (consumablesOnly && matBurn.type !== "workforce") {
          continue;
        }
        if (!consumablesOnly && !includeConsumables.value && matBurn.type === "workforce") {
          continue;
        }
        const need = useBaseInv.value ? Math.ceil((matBurn.daysLeft - days.value) * matBurn.dailyAmount) : Math.ceil(-days.value * matBurn.dailyAmount);
        if (need > 0) {
          result[ticker] = need;
        }
      }
      return result;
    });
    const showPreview = ref(false);
    const previewTotalWeight = computed(() => {
      if (!materialBill.value) {
        return 0;
      }
      let total = 0;
      for (const [ticker, amount] of Object.entries(materialBill.value)) {
        const mat = materialsStore.getByTicker(ticker);
        if (mat) {
          total += mat.weight * amount;
        }
      }
      return total;
    });
    const previewTotalVolume = computed(() => {
      if (!materialBill.value) {
        return 0;
      }
      let total = 0;
      for (const [ticker, amount] of Object.entries(materialBill.value)) {
        const mat = materialsStore.getByTicker(ticker);
        if (mat) {
          total += mat.volume * amount;
        }
      }
      return total;
    });
    function onPreviewClick() {
      if (days.value <= 0) {
        daysError.value = true;
        return;
      }
      daysError.value = false;
      showPreview.value = !showPreview.value;
    }
    function onGenerateClick() {
      if (days.value <= 0) {
        daysError.value = true;
        return;
      }
      const name = burn.value?.planetName ?? planetName.value;
      const groupName = "Resupply";
      const consumablesOnly = includeConsumables.value && !includeInputs.value;
      const pkg = {
        global: { name: packageName.value },
        groups: [
          {
            type: "Resupply",
            name: groupName,
            planet: name,
            days: days.value,
            useBaseInv: useBaseInv.value,
            consumablesOnly,
            includeConsumables: includeConsumables.value,
            includeInputs: includeInputs.value,
            exclusions: []
          }
        ],
        actions: [
          {
            type: "CX Buy",
            name: "CX Buy",
            group: groupName,
            exchange: exchange.value,
            buyPartial: false,
            allowUnfilled: false,
            useCXInv: true
          },
          {
            type: "MTRA",
            name: "Transfer to Ship",
            group: groupName,
            origin: warehouseName.value,
            dest: configurableValue
          }
        ]
      };
      const existing = userData.actionPackages.find((x) => x.global.name === packageName.value);
      if (existing) {
        const index = userData.actionPackages.indexOf(existing);
        userData.actionPackages[index] = pkg;
      } else {
        userData.actionPackages.push(pkg);
      }
      showBuffer(`XIT ACT_${packageName.value.split(" ").join("_")}`);
    }
    return (_ctx, _cache) => {
      return !unref(burn) ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).DraftConditionEditor.form)
      }, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[6] || (_cache[6] = [
            createTextVNode("生成 ACT 补充包", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.$style.notice)
        }, "在 " + toDisplayString(unref(planetName)) + " 上没有找到基地。", 3)
      ], 2)) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).DraftConditionEditor.form)
      }, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [..._cache[7] || (_cache[7] = [
            createTextVNode("生成 ACT 补充包", -1)
          ])]),
          _: 1
        }),
        createBaseVNode("form", null, [
          createVNode(_sfc_main$1, { label: "星球" }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(unref(burn).planetName), 1)
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "补充天数",
            error: unref(daysError)
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$2, {
                modelValue: unref(days),
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(days) ? days.value = $event : null)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }, 8, ["error"]),
          createVNode(_sfc_main$1, {
            label: "消耗品",
            tooltip: "包含劳动力消耗品（食物、饮料等）。"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$3, {
                modelValue: unref(includeConsumables),
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(includeConsumables) ? includeConsumables.value = $event : null)
              }, {
                default: withCtx(() => [..._cache[8] || (_cache[8] = [
                  createTextVNode("消耗品", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "生产原料",
            tooltip: "包含生产线所需的输入原料。"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$3, {
                modelValue: unref(includeInputs),
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(includeInputs) ? includeInputs.value = $event : null)
              }, {
                default: withCtx(() => [..._cache[9] || (_cache[9] = [
                  createTextVNode("生产原料", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "使用基地库存",
            tooltip: "计算补充量时是否将基地中现有材料计入。"
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$3, {
                modelValue: unref(useBaseInv),
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(useBaseInv) ? useBaseInv.value = $event : null)
              }, {
                default: withCtx(() => [..._cache[10] || (_cache[10] = [
                  createTextVNode("使用基地库存", -1)
                ])]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "交易所",
            tooltip: "选择交易所，仓库自动绑定对应空间站。"
          }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(exchange),
                "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(exchange) ? exchange.value = $event : null),
                options: unref(exchanges)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, {
            label: "飞船填满",
            tooltip: "选择飞船后自动计算能装多少天补给，填满飞船。"
          }, {
            default: withCtx(() => [
              createVNode(SelectInput, {
                modelValue: unref(selectedShip),
                "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => isRef(selectedShip) ? selectedShip.value = $event : null),
                options: unref(shipSelectOptions)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "仓库" }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(unref(warehouseName)), 1)
            ]),
            _: 1
          }),
          createVNode(_sfc_main$1, { label: "包名称" }, {
            default: withCtx(() => [
              createBaseVNode("span", null, toDisplayString(unref(packageName)), 1)
            ]),
            _: 1
          }),
          createVNode(_sfc_main$5, null, {
            default: withCtx(() => [
              createVNode(_sfc_main$4, {
                primary: "",
                onClick: onGenerateClick
              }, {
                default: withCtx(() => [..._cache[11] || (_cache[11] = [
                  createTextVNode("生成", -1)
                ])]),
                _: 1
              }),
              createVNode(_sfc_main$4, {
                primary: "",
                onClick: onPreviewClick
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(showPreview) ? "隐藏预览" : "预览"), 1)
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        unref(showPreview) && unref(materialBill) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
          createVNode(SectionHeader, null, {
            default: withCtx(() => [..._cache[12] || (_cache[12] = [
              createTextVNode("预览", -1)
            ])]),
            _: 1
          }),
          createBaseVNode("div", {
            class: normalizeClass(_ctx.$style.preview)
          }, [
            createVNode(_sfc_main$1, { label: "总体积" }, {
              default: withCtx(() => [
                createBaseVNode("span", null, toDisplayString(unref(fixed2)(unref(previewTotalVolume))) + " m³", 1)
              ]),
              _: 1
            }),
            createVNode(_sfc_main$1, { label: "总重量" }, {
              default: withCtx(() => [
                createBaseVNode("span", null, toDisplayString(unref(fixed2)(unref(previewTotalWeight))) + " t", 1)
              ]),
              _: 1
            }),
            createVNode(_sfc_main$1, { label: "材料种类" }, {
              default: withCtx(() => [
                createBaseVNode("span", null, toDisplayString(Object.keys(unref(materialBill)).length), 1)
              ]),
              _: 1
            })
          ], 2)
        ], 64)) : createCommentVNode("", true)
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
