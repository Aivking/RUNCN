const iconBoost = "rp-funny-materials__iconBoost___234d6d6";
const hideIcon = "rp-funny-materials__hideIcon___40c61b0";
const $style = {
  iconBoost,
  hideIcon
};
export {
  $style as default,
  hideIcon,
  iconBoost
};
