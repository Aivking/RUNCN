import _sfc_main from "./GenerateBraRepairActDialog.vue2.js";
import style0 from "./GenerateBraRepairActDialog.vue3.js";
import _export_sfc from "./plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const GenerateBraRepairActDialog = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  GenerateBraRepairActDialog as default
};
