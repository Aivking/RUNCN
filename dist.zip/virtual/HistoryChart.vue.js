import _sfc_main from "./HistoryChart.vue2.js";
import style0 from "./HistoryChart.vue3.js";
import _export_sfc from "./plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const HistoryChart = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  HistoryChart as default
};
