import "./config.js";
import { C } from "./prun-css.js";
import { act } from "./act-registry.js";
import { deepToRaw } from "./deep-to-raw.js";
import { TileAllocator } from "./tile-allocator.js";
import { StepMachine } from "./step-machine.js";
import { StepGenerator } from "./step-generator.js";
import { showBuffer } from "./buffers.js";
import { sleep } from "./sleep.js";
import { cxobStore } from "./cxob.js";
import { fixed0, fixed2 } from "./format.js";
class ActionRunner {
  constructor(options) {
    this.options = options;
    this.tileAllocator = new TileAllocator(options);
    this.stepGenerator = new StepGenerator(options);
  }
  tileAllocator;
  stepGenerator;
  stepMachine;
  preOpenedWindows = [];
  get log() {
    return this.options.log;
  }
  get isRunning() {
    return this.stepMachine?.isRunning ?? false;
  }
  async preview(pkg, config) {
    if (this.isRunning) {
      this.log.error("操作包已在运行中");
      return;
    }
    const copy = structuredClone(deepToRaw(pkg));
    const { steps, fail } = await this.stepGenerator.generateSteps(copy, config);
    if (steps.length === 0) {
      return;
    }
    await this.preloadPriceData(steps);
    if (fail) {
      this.log.info("已为有效操作生成步骤：");
    }
    let totalCost = 0;
    let missingPriceCount = 0;
    let totalWeight = 0;
    let totalVolume = 0;
    const seenTickers = /* @__PURE__ */ new Set();
    for (const step of steps) {
      const stepInfo = act.getActionStepInfo(step.type);
      if (stepInfo.cost) {
        const cost = stepInfo.cost(step);
        if (cost !== void 0) {
          totalCost += cost;
        } else {
          missingPriceCount++;
        }
      }
      const ticker = step.ticker;
      const isNewTicker = !!ticker && !seenTickers.has(ticker);
      if (stepInfo.weight !== void 0 && isNewTicker) {
        totalWeight += stepInfo.weight(step) ?? 0;
      }
      if (stepInfo.volume !== void 0 && isNewTicker) {
        totalVolume += stepInfo.volume(step) ?? 0;
      }
      if (ticker) {
        seenTickers.add(ticker);
      }
    }
    if (totalCost > 0 || totalWeight > 0 || totalVolume > 0) {
      const parts = [];
      if (totalCost > 0 || missingPriceCount > 0) {
        let costStr = `花费 ${fixed0(totalCost)} ICA`;
        if (missingPriceCount > 0) {
          costStr += `（${missingPriceCount} 项暂无数据）`;
        }
        parts.push(costStr);
      }
      if (totalWeight > 0) {
        parts.push(`重量 ${fixed2(totalWeight)} t`);
      }
      if (totalVolume > 0) {
        parts.push(`体积 ${fixed2(totalVolume)} m3`);
      }
      this.log.summary(`总计：${parts.join("，")}`);
    }
    for (const step of steps) {
      const stepInfo = act.getActionStepInfo(step.type);
      this.log.action(stepInfo.description(step));
    }
  }
  async execute(pkg, config) {
    if (this.isRunning) {
      this.log.error("操作包已在运行中");
      return;
    }
    const copy = structuredClone(deepToRaw(pkg));
    const { steps, fail } = await this.stepGenerator.generateSteps(copy, config);
    if (fail) {
      this.log.error("操作包执行失败");
      return;
    }
    this.log.info("操作包开始执行");
    if (this.options.isAutoAct()) {
      await this.preOpenTiles(steps);
    }
    this.stepMachine = new StepMachine(steps, {
      ...this.options,
      tileAllocator: this.tileAllocator,
      onEnd: () => {
        this.closePreOpenedWindows();
        this.options.onEnd();
      }
    });
    this.stepMachine.start();
  }
  act() {
    this.stepMachine?.act();
    if (!this.stepMachine?.isRunning) {
      this.stepMachine = void 0;
    }
  }
  skip() {
    this.stepMachine?.skip();
    if (!this.stepMachine?.isRunning) {
      this.stepMachine = void 0;
    }
  }
  cancel() {
    this.stepMachine?.cancel();
    this.stepMachine = void 0;
    this.closePreOpenedWindows();
  }
  async preloadPriceData(steps) {
    const cxTickers = steps.filter((s) => s.type === "CXPO_BUY").map((s) => {
      const data = s;
      return {
        cxTicker: `${data.ticker}.${data.exchange}`,
        command: `CXPO ${data.ticker}.${data.exchange}`
      };
    }).filter(({ cxTicker }) => !cxobStore.getByTicker(cxTicker));
    if (cxTickers.length === 0) return;
    const opened = [];
    for (const { command } of cxTickers) {
      const win = await showBuffer(command, { force: true, autoSubmit: true });
      if (win !== void 0) opened.push(win);
    }
    const deadline = Date.now() + 5e3;
    while (Date.now() < deadline) {
      const allReady = cxTickers.every(({ cxTicker }) => !!cxobStore.getByTicker(cxTicker));
      if (allReady) break;
      await sleep(200);
    }
    for (const win of opened) {
      const buttons = win.getElementsByClassName(C.Window.button);
      const closeBtn = Array.from(buttons).find((x) => x.textContent === "x");
      closeBtn?.click();
    }
  }
  async preOpenTiles(steps) {
    const commands = /* @__PURE__ */ new Set();
    for (const step of steps) {
      if (step.type === "CXPO_BUY") {
        const data = step;
        commands.add(`CXPO ${data.ticker}.${data.exchange}`);
      }
    }
    if (commands.size === 0) {
      return;
    }
    this.log.info(`正在预加载 ${commands.size} 个交易所窗口...`);
    for (const command of commands) {
      this.options.onStatusChanged(`正在打开 ${command}...`);
      const window = await showBuffer(command, { force: true, autoSubmit: true });
      if (window !== void 0) {
        this.preOpenedWindows.push(window);
      }
    }
    this.options.onStatusChanged("等待订单簿数据加载...");
    await sleep(1e3);
    this.log.info("交易所窗口预加载完成");
  }
  closePreOpenedWindows() {
    for (const win of this.preOpenedWindows) {
      const buttons = win.getElementsByClassName(C.Window.button);
      const closeButton = Array.from(buttons).find((x) => x.textContent === "x");
      closeButton?.click();
    }
    this.preOpenedWindows = [];
  }
}
export {
  ActionRunner
};
