import LoadingSpinner from "./LoadingSpinner.vue.js";
import StatusFilter from "./StatusFilter.vue.js";
import { contractsStore } from "./contracts.js";
import HaulRow from "./HaulRow.vue.js";
import { isTransportContract, formatAmount } from "./utils4.js";
import { isEmpty } from "./is-empty.js";
import { defineComponent, computed, openBlock, createBlock, createElementBlock, createVNode, createElementVNode as createBaseVNode, createTextVNode, createCommentVNode, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { normalizeClass, toDisplayString } from "./shared.esm-bundler.js";
const _hoisted_1 = { key: 0 };
const _hoisted_2 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "HAUL",
  setup(__props) {
    const activeFilters = ref(
      /* @__PURE__ */ new Set(["OPEN", "CLOSED", "PARTIALLY_FULFILLED", "DEADLINE_EXCEEDED"])
    );
    const showFilters = ref(true);
    function isCarrier(contract) {
      const pickup = contract.conditions.find((c) => c.type === "PICKUP_SHIPMENT");
      if (pickup) return pickup.party === contract.party;
      const delivery = contract.conditions.find((c) => c.type === "DELIVERY_SHIPMENT");
      if (delivery) return delivery.party === contract.party;
      return false;
    }
    const transportContracts = computed(
      () => (contractsStore.all.value ?? []).filter(
        (c) => isTransportContract(c) && activeFilters.value.has(c.status)
      )
    );
    const carrying = computed(
      () => transportContracts.value.filter(isCarrier).sort((a, b) => (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0))
    );
    const shipping = computed(
      () => transportContracts.value.filter((c) => !isCarrier(c)).sort((a, b) => (b.date?.timestamp ?? 0) - (a.date?.timestamp ?? 0))
    );
    function getTransportSummary(contracts) {
      let totalPayment = 0;
      let currency = "";
      let totalContracts = contracts.length;
      let completedContracts = 0;
      for (const contract of contracts) {
        if (contract.status === "FULFILLED") completedContracts++;
        for (const cond of contract.conditions) {
          if (cond.type === "PAYMENT" && cond.amount) {
            totalPayment += cond.amount.amount;
            if (!currency) currency = cond.amount.currency;
          }
        }
      }
      return { totalPayment, currency, totalContracts, completedContracts };
    }
    const carryingSummary = computed(() => getTransportSummary(carrying.value));
    const shippingSummary = computed(() => getTransportSummary(shipping.value));
    return (_ctx, _cache) => {
      return !unref(contractsStore).fetched ? (openBlock(), createBlock(LoadingSpinner, { key: 0 })) : (openBlock(), createElementBlock("div", {
        key: 1,
        class: normalizeClass(_ctx.$style.container)
      }, [
        createVNode(StatusFilter, {
          modelValue: activeFilters.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => activeFilters.value = $event),
          "show-filters": showFilters.value,
          "onUpdate:showFilters": _cache[1] || (_cache[1] = ($event) => showFilters.value = $event)
        }, null, 8, ["modelValue", "show-filters"]),
        createBaseVNode("table", null, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", {
                colspan: "8",
                class: normalizeClass(_ctx.$style.sectionHeader)
              }, [
                _cache[2] || (_cache[2] = createTextVNode(" 🚀 承运合同 ", -1)),
                !unref(isEmpty)(carrying.value) ? (openBlock(), createElementBlock("span", {
                  key: 0,
                  class: normalizeClass(_ctx.$style.summary)
                }, " 共 " + toDisplayString(carryingSummary.value.totalContracts) + " 单 | 已完成 " + toDisplayString(carryingSummary.value.completedContracts) + " 单 | 运费合计: " + toDisplayString(unref(formatAmount)(carryingSummary.value.totalPayment, carryingSummary.value.currency)), 3)) : createCommentVNode("", true)
              ], 2)
            ]),
            _cache[3] || (_cache[3] = createBaseVNode("tr", null, [
              createBaseVNode("th", null, "合同"),
              createBaseVNode("th", null, "对方"),
              createBaseVNode("th", null, "起点"),
              createBaseVNode("th", null, "终点"),
              createBaseVNode("th", null, "货物"),
              createBaseVNode("th", null, "运费"),
              createBaseVNode("th", null, "进度"),
              createBaseVNode("th", null, "状态")
            ], -1))
          ]),
          createBaseVNode("tbody", null, [
            unref(isEmpty)(carrying.value) ? (openBlock(), createElementBlock("tr", _hoisted_1, [
              createBaseVNode("td", {
                colspan: "8",
                class: normalizeClass(_ctx.$style.empty)
              }, "暂无承运合同", 2)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(carrying.value, (contract) => {
              return openBlock(), createBlock(HaulRow, {
                key: contract.id,
                contract,
                type: "carrier"
              }, null, 8, ["contract"]);
            }), 128))
          ])
        ]),
        createBaseVNode("table", {
          class: normalizeClass(_ctx.$style.secondTable)
        }, [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", {
                colspan: "8",
                class: normalizeClass(_ctx.$style.sectionHeader)
              }, [
                _cache[4] || (_cache[4] = createTextVNode(" 📦 委托运输 ", -1)),
                !unref(isEmpty)(shipping.value) ? (openBlock(), createElementBlock("span", {
                  key: 0,
                  class: normalizeClass(_ctx.$style.summary)
                }, " 共 " + toDisplayString(shippingSummary.value.totalContracts) + " 单 | 已完成 " + toDisplayString(shippingSummary.value.completedContracts) + " 单 | 运费合计: " + toDisplayString(unref(formatAmount)(shippingSummary.value.totalPayment, shippingSummary.value.currency)), 3)) : createCommentVNode("", true)
              ], 2)
            ]),
            _cache[5] || (_cache[5] = createBaseVNode("tr", null, [
              createBaseVNode("th", null, "合同"),
              createBaseVNode("th", null, "对方"),
              createBaseVNode("th", null, "起点"),
              createBaseVNode("th", null, "终点"),
              createBaseVNode("th", null, "货物"),
              createBaseVNode("th", null, "运费"),
              createBaseVNode("th", null, "进度"),
              createBaseVNode("th", null, "状态")
            ], -1))
          ]),
          createBaseVNode("tbody", null, [
            unref(isEmpty)(shipping.value) ? (openBlock(), createElementBlock("tr", _hoisted_2, [
              createBaseVNode("td", {
                colspan: "8",
                class: normalizeClass(_ctx.$style.empty)
              }, "暂无委托运输", 2)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(shipping.value, (contract) => {
              return openBlock(), createBlock(HaulRow, {
                key: contract.id,
                contract,
                type: "shipper"
              }, null, 8, ["contract"]);
            }), 128))
          ])
        ], 2)
      ], 2));
    };
  }
});
export {
  _sfc_main as default
};
