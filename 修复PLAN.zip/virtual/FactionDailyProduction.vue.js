import { C } from "./prun-css.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import MaterialIcon from "./MaterialIcon.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import { fetchProductionSummary, FactionApiError, reportProduction } from "./use-faction-api.js";
import { getPlanetBurn } from "./burn2.js";
import { sitesStore } from "./sites.js";
import { materialsStore } from "./materials.js";
import { sortMaterials } from "./sort-materials.js";
import { fixed0, fixed1, fixed2 } from "./format.js";
import $style from "./FactionPanel.module.css.js";
import { defineComponent, onMounted, openBlock, createElementBlock, createElementVNode as createBaseVNode, createVNode, withCtx, createTextVNode, Fragment, createCommentVNode, renderList } from "./runtime-core.esm-bundler.js";
import { ref, unref } from "./reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const _hoisted_1 = { style: { "display": "flex", "align-items": "center", "gap": "6px" } };
const _hoisted_2 = { style: { "font-size": "10px", "opacity": "0.5" } };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FactionDailyProduction",
  props: {
    myRole: {}
  },
  setup(__props) {
    const members = ref([]);
    const loading = ref(false);
    const error = ref("");
    const submitStatus = ref("idle");
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    function sortedItems(items) {
      const mats = items.map((i) => materialsStore.getByTicker(i.ticker)).filter((m) => m !== void 0);
      const sorted = sortMaterials(mats);
      return sorted.map((m) => items.find((i) => i.ticker === m.ticker));
    }
    function formatQty(n) {
      const abs = Math.abs(n);
      return abs >= 1e3 ? fixed0(abs) : abs >= 100 ? fixed1(abs) : fixed2(abs);
    }
    async function loadData() {
      loading.value = true;
      error.value = "";
      try {
        const result = await fetchProductionSummary();
        members.value = result.members;
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        } else {
          error.value = "无法加载产出数据";
        }
      } finally {
        loading.value = false;
      }
    }
    async function handleSubmitMyProduction() {
      if (submitStatus.value === "submitting") return;
      submitStatus.value = "submitting";
      error.value = "";
      if (!sitesStore.fetched.value) {
        error.value = "游戏数据未就绪，请稍后再试";
        submitStatus.value = "idle";
        return;
      }
      try {
        const aggregated = {};
        for (const site of sitesStore.all.value ?? []) {
          const planetBurn = getPlanetBurn(site);
          if (!planetBurn) continue;
          for (const [ticker, mat] of Object.entries(planetBurn.burn)) {
            if (mat.output > 0) {
              aggregated[ticker] = (aggregated[ticker] ?? 0) + mat.output;
            }
          }
        }
        const items = Object.entries(aggregated).map(([ticker, quantity]) => ({
          ticker,
          quantity: Math.round(quantity)
        }));
        if (items.length === 0) {
          error.value = "未检测到产出数据（确认游戏已完全加载且有生产订单）";
          submitStatus.value = "idle";
          return;
        }
        await reportProduction(items);
        submitStatus.value = "ok";
        await loadData();
      } catch (e) {
        if (e instanceof FactionApiError) {
          error.value = e.response.message;
        } else {
          error.value = "提交失败，请检查网络连接";
        }
        submitStatus.value = "idle";
      }
    }
    onMounted(loadData);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass(unref($style).membersToolbar)
        }, [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_sfc_main$1, {
              dark: "",
              onClick: loadData
            }, {
              default: withCtx(() => [..._cache[0] || (_cache[0] = [
                createTextVNode("刷新", -1)
              ])]),
              _: 1
            }),
            createBaseVNode("span", _hoisted_2, toDisplayString(unref(today)), 1)
          ]),
          createVNode(_sfc_main$1, {
            dark: "",
            disabled: unref(submitStatus) === "submitting",
            onClick: handleSubmitMyProduction
          }, {
            default: withCtx(() => [
              unref(submitStatus) === "submitting" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                createTextVNode("上报中...")
              ], 64)) : unref(submitStatus) === "ok" ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                createTextVNode("✓ 已上报")
              ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [
                createTextVNode("上报我的产出")
              ], 64))
            ]),
            _: 1
          }, 8, ["disabled"])
        ], 2),
        unref(error) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref($style).errorMessage)
        }, toDisplayString(unref(error)), 3)) : createCommentVNode("", true),
        unref(loading) ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(unref($style).loadingMessage)
        }, "加载中...", 2)) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [
          unref(members).length === 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(unref($style).emptyMessage)
          }, " 暂无产出数据 — 点击「上报我的产出」提交 ", 2)) : createCommentVNode("", true),
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(members), (member) => {
            return openBlock(), createElementBlock(Fragment, {
              key: member.companyName
            }, [
              createVNode(SectionHeader, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(member.companyName), 1)
                ]),
                _: 2
              }, 1024),
              createBaseVNode("table", null, [
                createBaseVNode("tbody", null, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(sortedItems(member.items), (item) => {
                    return openBlock(), createElementBlock("tr", {
                      key: item.ticker
                    }, [
                      createBaseVNode("td", {
                        class: normalizeClass(unref($style).burnIconCell)
                      }, [
                        createVNode(MaterialIcon, {
                          size: "inline-table",
                          ticker: item.ticker
                        }, null, 8, ["ticker"])
                      ], 2),
                      createBaseVNode("td", {
                        class: normalizeClass(unref($style).burnTickerCell)
                      }, toDisplayString(item.ticker), 3),
                      createBaseVNode("td", null, [
                        createBaseVNode("span", {
                          class: normalizeClass(("C" in _ctx ? _ctx.C : unref(C)).ColoredValue.positive)
                        }, " +" + toDisplayString(formatQty(item.quantity)) + "/天 ", 3)
                      ])
                    ]);
                  }), 128))
                ])
              ])
            ], 64);
          }), 128))
        ], 64))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
