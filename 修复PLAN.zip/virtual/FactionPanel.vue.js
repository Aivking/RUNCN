import { vModelText, withKeys } from "./runtime-dom.esm-bundler.js";
import { companyStore } from "./company.js";
import { useXitParameters } from "./use-xit-parameters.js";
import _sfc_main$2 from "./Tabs.vue.js";
import _sfc_main$1 from "./PrunButton.vue.js";
import SectionHeader from "./SectionHeader.vue.js";
import _sfc_main$3 from "./FactionTreasury.vue.js";
import _sfc_main$4 from "./FactionLogistics.vue.js";
import _sfc_main$5 from "./FactionTasks.vue.js";
import _sfc_main$6 from "./FactionBulletin.vue.js";
import _sfc_main$7 from "./FactionDailyProduction.vue.js";
import { isAuthenticated, login, FactionApiError, register, fetchMembers, logout, removeMember, createInviteCode, updateMemberRole } from "./use-faction-api.js";
import { ROLE_LABELS, ROLE_ORDER } from "./types.js";
import $style from "./FactionPanel.module.css.js";
import { defineComponent, watchEffect, computed, onMounted, openBlock, createElementBlock, createVNode, withCtx, createTextVNode, createElementVNode as createBaseVNode, withDirectives, createCommentVNode, createBlock, Fragment, renderList } from "./runtime-core.esm-bundler.js";
import { ref, shallowRef, unref, isRef } from "./reactivity.esm-bundler.js";
import { toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
const _hoisted_1 = { key: 1 };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = {
  key: 0,
  style: { "display": "flex", "gap": "4px" }
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FactionPanel",
  setup(__props) {
    const authenticated = ref(isAuthenticated());
    const authMode = ref("login");
    const authCompanyName = ref("");
    const authPin = ref("");
    const authInviteCode = ref("");
    const authError = ref("");
    const authLoading = ref(false);
    const members = ref([]);
    const myRole = ref("member");
    const membersLoading = ref(false);
    const membersError = ref("");
    const generatedInviteCode = ref("");
    watchEffect(() => {
      const company = companyStore.value;
      if (company && !authCompanyName.value) {
        authCompanyName.value = company.name;
      }
    });
    async function handleLogin() {
      authError.value = "";
      authLoading.value = true;
      try {
        await login(authCompanyName.value, authPin.value);
        authenticated.value = true;
        authPin.value = "";
        await loadMembers();
      } catch (e) {
        if (e instanceof FactionApiError) {
          authError.value = e.response.message;
        } else {
          authError.value = "网络错误，请稍后重试";
        }
      } finally {
        authLoading.value = false;
      }
    }
    async function handleRegister() {
      authError.value = "";
      authLoading.value = true;
      try {
        await register(authCompanyName.value, authPin.value, authInviteCode.value);
        authenticated.value = true;
        authPin.value = "";
        authInviteCode.value = "";
        await loadMembers();
      } catch (e) {
        if (e instanceof FactionApiError) {
          authError.value = e.response.message;
        } else {
          authError.value = "网络错误，请稍后重试";
        }
      } finally {
        authLoading.value = false;
      }
    }
    function handleLogout() {
      logout();
      authenticated.value = false;
      members.value = [];
      myRole.value = "member";
    }
    async function loadMembers() {
      membersLoading.value = true;
      membersError.value = "";
      try {
        const result = await fetchMembers();
        members.value = result.members;
        myRole.value = result.myRole;
      } catch (e) {
        if (e instanceof FactionApiError) {
          if (e.code === "UNAUTHORIZED") {
            handleLogout();
            authError.value = "Token 已过期，请重新登录";
            return;
          }
          membersError.value = e.response.message;
        } else {
          membersError.value = "无法加载成员列表";
        }
      } finally {
        membersLoading.value = false;
      }
    }
    async function handleRoleChange(member, newRole) {
      try {
        await updateMemberRole(member.id, newRole);
        await loadMembers();
      } catch (e) {
        if (e instanceof FactionApiError) {
          membersError.value = e.response.message;
        }
      }
    }
    async function handleRemoveMember(member) {
      try {
        await removeMember(member.id);
        await loadMembers();
      } catch (e) {
        if (e instanceof FactionApiError) {
          membersError.value = e.response.message;
        }
      }
    }
    async function handleCreateInvite() {
      try {
        const result = await createInviteCode();
        generatedInviteCode.value = result.code;
      } catch (e) {
        if (e instanceof FactionApiError) {
          membersError.value = e.response.message;
        }
      }
    }
    function roleBadgeClass(role) {
      switch (role) {
        case "executive":
          return $style.roleExecutive;
        case "partner":
          return $style.rolePartner;
        default:
          return $style.roleMember;
      }
    }
    function availableRoles(currentRole) {
      return ROLE_ORDER.filter((r) => r !== currentRole);
    }
    function formatDate(iso) {
      const d = new Date(iso);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    }
    const Placeholder = defineComponent({ setup: () => () => null });
    const tabs = [
      { id: "MEMBERS", label: "成员", component: Placeholder },
      { id: "TREASURY", label: "基金", component: Placeholder },
      { id: "LOGISTICS", label: "物资", component: Placeholder },
      { id: "TASKS", label: "任务", component: Placeholder },
      { id: "BULLETIN", label: "公告", component: Placeholder },
      { id: "PRODUCTION", label: "产出", component: Placeholder }
    ];
    const parameters = useXitParameters();
    const parameter = parameters[0];
    const activeTab = shallowRef(tabs.find((x) => x.id === parameter?.toUpperCase()) ?? tabs[0]);
    const isExecutive = computed(() => myRole.value === "executive");
    onMounted(() => {
      if (authenticated.value) {
        loadMembers();
      }
    });
    return (_ctx, _cache) => {
      return !unref(authenticated) ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass(unref($style).loginContainer)
      }, [
        createVNode(SectionHeader, null, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(unref(authMode) === "login" ? "登录组织面板" : "注册新成员"), 1)
          ]),
          _: 1
        }),
        createBaseVNode("div", {
          class: normalizeClass(unref($style).field)
        }, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).fieldLabel)
          }, "公司名", 2),
          withDirectives(createBaseVNode("input", {
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(authCompanyName) ? authCompanyName.value = $event : null),
            class: normalizeClass(unref($style).fieldInput),
            type: "text",
            autocomplete: "off"
          }, null, 2), [
            [vModelText, unref(authCompanyName)]
          ])
        ], 2),
        createBaseVNode("div", {
          class: normalizeClass(unref($style).field)
        }, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).fieldLabel)
          }, "PIN", 2),
          withDirectives(createBaseVNode("input", {
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(authPin) ? authPin.value = $event : null),
            class: normalizeClass(unref($style).fieldInput),
            type: "password",
            autocomplete: "off",
            onKeyup: _cache[2] || (_cache[2] = withKeys(($event) => unref(authMode) === "login" ? handleLogin() : handleRegister(), ["enter"]))
          }, null, 34), [
            [vModelText, unref(authPin)]
          ])
        ], 2),
        unref(authMode) === "register" ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(unref($style).field)
        }, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).fieldLabel)
          }, "邀请码", 2),
          withDirectives(createBaseVNode("input", {
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(authInviteCode) ? authInviteCode.value = $event : null),
            class: normalizeClass(unref($style).fieldInput),
            type: "text",
            autocomplete: "off",
            onKeyup: _cache[4] || (_cache[4] = withKeys(($event) => handleRegister(), ["enter"]))
          }, null, 34), [
            [vModelText, unref(authInviteCode)]
          ])
        ], 2)) : createCommentVNode("", true),
        unref(authError) ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(unref($style).errorMessage)
        }, toDisplayString(unref(authError)), 3)) : createCommentVNode("", true),
        createBaseVNode("div", {
          class: normalizeClass(unref($style).buttonRow)
        }, [
          unref(authMode) === "login" ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            primary: "",
            disabled: unref(authLoading) || !unref(authCompanyName) || !unref(authPin),
            onClick: handleLogin
          }, {
            default: withCtx(() => [..._cache[7] || (_cache[7] = [
              createTextVNode(" 登录 ", -1)
            ])]),
            _: 1
          }, 8, ["disabled"])) : (openBlock(), createBlock(_sfc_main$1, {
            key: 1,
            primary: "",
            disabled: unref(authLoading) || !unref(authCompanyName) || !unref(authPin) || !unref(authInviteCode),
            onClick: handleRegister
          }, {
            default: withCtx(() => [..._cache[8] || (_cache[8] = [
              createTextVNode(" 注册 ", -1)
            ])]),
            _: 1
          }, 8, ["disabled"]))
        ], 2),
        createBaseVNode("div", {
          class: normalizeClass(unref($style).modeSwitch),
          onClick: _cache[5] || (_cache[5] = ($event) => authMode.value = unref(authMode) === "login" ? "register" : "login")
        }, toDisplayString(unref(authMode) === "login" ? "没有账号？点击注册" : "已有账号？点击登录"), 3)
      ], 2)) : (openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", {
          class: normalizeClass(unref($style).logoutBar)
        }, [
          createBaseVNode("span", {
            class: normalizeClass(unref($style).userInfo)
          }, toDisplayString(unref(authCompanyName)) + " · " + toDisplayString(unref(ROLE_LABELS)[unref(myRole)]), 3),
          createVNode(_sfc_main$1, {
            dark: "",
            onClick: handleLogout
          }, {
            default: withCtx(() => [..._cache[9] || (_cache[9] = [
              createTextVNode("登出", -1)
            ])]),
            _: 1
          })
        ], 2),
        createVNode(_sfc_main$2, {
          modelValue: unref(activeTab),
          "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => isRef(activeTab) ? activeTab.value = $event : null),
          tabs
        }, null, 8, ["modelValue"]),
        unref(activeTab).id === "MEMBERS" ? (openBlock(), createElementBlock("div", _hoisted_2, [
          createBaseVNode("div", {
            class: normalizeClass(unref($style).membersToolbar)
          }, [
            createVNode(_sfc_main$1, {
              dark: "",
              onClick: loadMembers
            }, {
              default: withCtx(() => [..._cache[10] || (_cache[10] = [
                createTextVNode("刷新", -1)
              ])]),
              _: 1
            }),
            unref(isExecutive) ? (openBlock(), createElementBlock("div", _hoisted_3, [
              createVNode(_sfc_main$1, {
                dark: "",
                onClick: handleCreateInvite
              }, {
                default: withCtx(() => [..._cache[11] || (_cache[11] = [
                  createTextVNode("生成邀请码", -1)
                ])]),
                _: 1
              })
            ])) : createCommentVNode("", true)
          ], 2),
          unref(generatedInviteCode) ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(unref($style).inviteCodeDisplay)
          }, " 邀请码：" + toDisplayString(unref(generatedInviteCode)), 3)) : createCommentVNode("", true),
          unref(membersError) ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass(unref($style).errorMessage)
          }, toDisplayString(unref(membersError)), 3)) : createCommentVNode("", true),
          unref(membersLoading) ? (openBlock(), createElementBlock("div", {
            key: 2,
            class: normalizeClass(unref($style).loadingMessage)
          }, "加载中...", 2)) : (openBlock(), createElementBlock(Fragment, { key: 3 }, [
            unref(members).length === 0 ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: normalizeClass(unref($style).emptyMessage)
            }, "暂无成员", 2)) : createCommentVNode("", true),
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(members), (member) => {
              return openBlock(), createElementBlock("div", {
                key: member.id,
                class: normalizeClass(unref($style).memberRow)
              }, [
                createBaseVNode("div", {
                  class: normalizeClass(unref($style).memberInfo)
                }, [
                  createBaseVNode("span", {
                    class: normalizeClass(unref($style).memberName)
                  }, toDisplayString(member.companyName), 3),
                  createBaseVNode("span", {
                    class: normalizeClass([unref($style).roleBadge, roleBadgeClass(member.role)])
                  }, toDisplayString(unref(ROLE_LABELS)[member.role]), 3),
                  createBaseVNode("span", {
                    class: normalizeClass(unref($style).memberJoined)
                  }, toDisplayString(formatDate(member.joinedAt)), 3)
                ], 2),
                unref(isExecutive) ? (openBlock(), createElementBlock("div", {
                  key: 0,
                  class: normalizeClass(unref($style).memberActions)
                }, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(availableRoles(member.role), (role) => {
                    return openBlock(), createBlock(_sfc_main$1, {
                      key: role,
                      dark: "",
                      onClick: ($event) => handleRoleChange(member, role)
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" → " + toDisplayString(unref(ROLE_LABELS)[role]), 1)
                      ]),
                      _: 2
                    }, 1032, ["onClick"]);
                  }), 128)),
                  createVNode(_sfc_main$1, {
                    danger: "",
                    onClick: ($event) => handleRemoveMember(member)
                  }, {
                    default: withCtx(() => [..._cache[12] || (_cache[12] = [
                      createTextVNode("移除", -1)
                    ])]),
                    _: 2
                  }, 1032, ["onClick"])
                ], 2)) : createCommentVNode("", true)
              ], 2);
            }), 128))
          ], 64))
        ])) : unref(activeTab).id === "TREASURY" ? (openBlock(), createBlock(_sfc_main$3, {
          key: 1,
          "my-role": unref(myRole)
        }, null, 8, ["my-role"])) : unref(activeTab).id === "LOGISTICS" ? (openBlock(), createBlock(_sfc_main$4, {
          key: 2,
          "my-role": unref(myRole)
        }, null, 8, ["my-role"])) : unref(activeTab).id === "TASKS" ? (openBlock(), createBlock(_sfc_main$5, {
          key: 3,
          "my-role": unref(myRole)
        }, null, 8, ["my-role"])) : unref(activeTab).id === "BULLETIN" ? (openBlock(), createBlock(_sfc_main$6, {
          key: 4,
          "my-role": unref(myRole)
        }, null, 8, ["my-role"])) : unref(activeTab).id === "PRODUCTION" ? (openBlock(), createBlock(_sfc_main$7, {
          key: 5,
          "my-role": unref(myRole)
        }, null, 8, ["my-role"])) : createCommentVNode("", true)
      ]));
    };
  }
});
export {
  _sfc_main as default
};
