import { subscribe } from "./subscribe-async-generator.js";
import { _$$, $$ } from "./select-dom.js";
import { C } from "./prun-css.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import { refPrunId } from "./attributes.js";
import { storagesStore } from "./storage.js";
import { watchEffectWhileNodeAlive } from "./watch.js";
import { PrunI18N } from "./i18n.js";
import { computed } from "./runtime-core.esm-bundler.js";
const storeTypes = [
  "STORE",
  "SHIP_STORE",
  "STL_FUEL_STORE",
  "FTL_FUEL_STORE",
  "WAREHOUSE_STORE",
  "CONSTRUCTION_STORE",
  "UPKEEP_STORE",
  "VORTEX_FUEL_STORE"
];
function onTileReady(tile) {
  shortenFilterLabels(tile);
  shortenTableLabels(tile);
}
function shortenFilterLabels(tile) {
  const map = /* @__PURE__ */ new Map();
  for (const type of storeTypes) {
    map.set(getFullName(type), getShortName(type));
  }
  subscribe($$(tile.anchor, C.InventoriesListContainer.filter), async (filter) => {
    for (const label of _$$(filter, C.RadioItem.value)) {
      const type = label.textContent;
      if (type) {
        label.textContent = map.get(type) ?? type;
      }
    }
  });
}
function shortenTableLabels(tile) {
  const map = /* @__PURE__ */ new Map();
  for (const type of storeTypes) {
    map.set(type, getShortName(type));
  }
  subscribe($$(tile.anchor, "tr"), (row) => {
    const id = refPrunId(row);
    const name = computed(() => {
      const storage = storagesStore.getById(id.value);
      return storage ? map.get(storage?.type) : void 0;
    });
    watchEffectWhileNodeAlive(row, () => {
      const typeLabel = row.firstChild?.firstChild;
      if (typeLabel && name.value !== void 0) {
        typeLabel.textContent = name.value;
      }
    });
  });
}
function getFullName(type) {
  return PrunI18N[`StoreTypeLabel.${type}`]?.[0]?.value ?? type;
}
function getShortName(type) {
  return PrunI18N[`StoreTypeLabel.${type}_SHORT`]?.[0]?.value ?? type;
}
function init() {
  tiles.observe("INV", onTileReady);
}
features.add(import.meta.url, init, "INV：缩短表格和过滤器中的存储类型名称。");
