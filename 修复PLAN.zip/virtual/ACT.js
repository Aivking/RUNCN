import xit from "./xit-registry.js";
import "./cx-buy.js";
import "./mtra.js";
import "./refuel.js";
import "./repair.js";
import "./resupply.js";
import "./manual.js";
import _sfc_main from "./ACT.vue.js";
xit.add({
  command: ["ACT", "ACTION"],
  name: (parameters) => {
    if (parameters.length === 0) {
      return "操作包列表";
    }
    if (parameters[0].toUpperCase() == "GEN" || parameters[0].toUpperCase() == "EDIT") {
      return "编辑操作包";
    }
    return "执行操作包";
  },
  description: "允许自动化某些任务。",
  optionalParameters: "GEN 和/或操作名称",
  contextItems: (parameters) => parameters.length > 0 ? [{ cmd: "XIT ACT" }] : [],
  component: () => _sfc_main
});
