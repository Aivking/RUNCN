import { subscribe } from "./subscribe-async-generator.js";
import { _$$, $$ } from "./select-dom.js";
import { C } from "./prun-css.js";
import { applyCssRule } from "./refined-prun-css.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import $style from "./inv-compress-inventory-info.module.css.js";
async function onTileReady(tile) {
  subscribe($$(tile.anchor, C.StoreView.column), (column) => {
    const capacities = _$$(column, C.StoreView.capacity);
    if (capacities.length < 3) {
      return;
    }
    const container = document.createElement("div");
    container.classList.add($style.capacityContainer);
    container.appendChild(capacities[1]);
    container.appendChild(capacities[2]);
    capacities[0].after(container);
  });
}
function init() {
  applyCssRule(["INV", "SHPI"], `.${C.StoreView.column}`, $style.storeViewColumn);
  applyCssRule(["INV", "SHPI"], `.${C.StoreView.container}`, $style.storeViewContainer);
  applyCssRule(["INV", "SHPI"], `.${C.InventorySortControls.controls}`, $style.sortControls);
  applyCssRule(["INV", "SHPI"], `.${C.StoreView.centered}`, $style.storeViewCentered);
  tiles.observe(["INV", "SHPI"], onTileReady);
}
features.add(import.meta.url, init, "INV/SHPI：将特定库存信息压缩到一行内。");
