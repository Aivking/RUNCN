const container = "rp-CONTFF__container___17a2ca8";
const filterBar = "rp-CONTFF__filterBar___bc6301c";
const filterIcon = "rp-CONTFF__filterIcon___d0a0e62";
const filterAction = "rp-CONTFF__filterAction___cee1379";
const statusFilters = "rp-CONTFF__statusFilters___a9a2ab4";
const statusBtn = "rp-CONTFF__statusBtn___b243cd9";
const inactive = "rp-CONTFF__inactive___c5a7af3";
const good = "rp-CONTFF__good___222e544";
const bad = "rp-CONTFF__bad___1d66dba";
const neutral = "rp-CONTFF__neutral___beac6f4";
const partial = "rp-CONTFF__partial___c4e85d0";
const totalsBar = "rp-CONTFF__totalsBar___0d09eb4";
const receivableText = "rp-CONTFF__receivableText___3f51212";
const payableText = "rp-CONTFF__payableText___2891d3c";
const empty = "rp-CONTFF__empty___f830193";
const style0 = {
  container,
  filterBar,
  filterIcon,
  filterAction,
  statusFilters,
  statusBtn,
  inactive,
  good,
  bad,
  neutral,
  partial,
  totalsBar,
  receivableText,
  payableText,
  empty
};
export {
  bad,
  container,
  style0 as default,
  empty,
  filterAction,
  filterBar,
  filterIcon,
  good,
  inactive,
  neutral,
  partial,
  payableText,
  receivableText,
  statusBtn,
  statusFilters,
  totalsBar
};
